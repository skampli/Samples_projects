package com.cisco.csv.exceltest;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class UploadToDB {

    public static void main(String[] args) throws Exception , IOException {

      
        	try {
				Class.forName("com.mysql.jdbc.Driver");
				Connection con = (Connection) DriverManager.getConnection("jdbc:mysql://localhost/sample","root","cisco123");
				con.setAutoCommit(false);
				PreparedStatement pstm = null;                     
        //  FileInputStream file = new FileInputStream("C:/reports/user.xlsx");
				//InputStream ExcelFileToRead = new FileInputStream("C:/user.xlsx");
				String fileName="C:\\Users\\djhalani\\user.xlsx";
				File myFile = new File(fileName); 
				FileInputStream fis = new FileInputStream(myFile);
				
				
				//Get the workbook instance for XLSx file 
				XSSFWorkbook workbook = new XSSFWorkbook (fis);
				//Get first sheet from the workbook
				XSSFSheet sheet = workbook.getSheetAt(0);
				Row row;
				for (int i = 1; i <= sheet.getLastRowNum(); i++) {
				    row = (Row) sheet.getRow(i);
				    String userId = row.getCell(0).getStringCellValue();
				    String firstname = row.getCell(1).getStringCellValue();
				    String lastName = row.getCell(2).getStringCellValue();
				    String directoryNumber = row.getCell(3).getStringCellValue();
				    String department = row.getCell(4).getStringCellValue();
				    String ciscoServicesFramework= row.getCell(5).getStringCellValue();
				    String macAddress = row.getCell(6).getStringCellValue();
				    String lineCss = row.getCell(7).getStringCellValue();
				    String routePartition = row.getCell(8).getStringCellValue();
				    String deviceType = row.getCell(9).getStringCellValue();
				    String devicePool = row.getCell(10).getStringCellValue();
				    String extensionMobility = row.getCell(11).getStringCellValue();
				    String non_did_number = row.getCell(12).getStringCellValue();
				    String voicemailProfile = row.getCell(13).getStringCellValue();
				    String softkeyTemplate = row.getCell(14).getStringCellValue();
				    String maxnumcalss = row.getCell(15).getStringCellValue();
				    String busyTrigger = row.getCell(16).getStringCellValue();
				    String alwaysUsePrimeLineForVoiceMessages = row.getCell(17).getStringCellValue();
				    String privacySettings =row.getCell(18).getStringCellValue();
				    String managerUserId = row.getCell(19).getStringCellValue();
				    String dummy = row.getCell(20).getStringCellValue();
				    String test1 = row.getCell(21).getStringCellValue();
				    String test2 = row.getCell(22).getStringCellValue();
					
				    String sql = "INSERT INTO USER (userId, firstname, lastName, directoryNumber, department, ciscoServicesFramework, macAddress, lineCss, routePartition, deviceType, devicePool, extensionMobility, non_did_number, voicemailProfile, softkeyTemplate, maxnumcalss, busyTrigger, alwaysUsePrimeLineForVoiceMessages , privacySettings, managerUserId, dummy, test1, test2)"
				    		+ " VALUES('"+ userId +"','" + firstname + "','" + lastName + "','" + directoryNumber + "','" + department + "','" + ciscoServicesFramework 
				    		+"','" + macAddress +"','" + lineCss +"','" + routePartition +"','" + deviceType +"','" + devicePool +"','" + extensionMobility +"','" + non_did_number +"','" + voicemailProfile +"','" + softkeyTemplate +"','" + maxnumcalss +"','" + busyTrigger +"','" + alwaysUsePrimeLineForVoiceMessages +"','" + privacySettings +"','" + managerUserId +"','" + dummy +"','" + test1 +"','" + test2 + "')";
				    pstm = (PreparedStatement) con.prepareStatement(sql);
				    pstm.execute();
				    System.out.println("Imported Records to matser table " + i);
				}
				con.commit();
				pstm.close();
				con.close();
				System.out.println("Success import excel to mysql table");
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
       
    }

}