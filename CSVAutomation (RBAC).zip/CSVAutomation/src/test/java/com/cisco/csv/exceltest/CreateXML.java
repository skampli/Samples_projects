package com.cisco.csv.exceltest;

import java.io.StringWriter;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerConfigurationException;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.TransformerFactoryConfigurationError;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.w3c.dom.DOMException;
import org.w3c.dom.Document;
import org.w3c.dom.Element;

public class CreateXML {

	public static void main(String[] args) {

		try {
			DocumentBuilderFactory docFactory = DocumentBuilderFactory.newInstance();
			DocumentBuilder docBuilder = docFactory.newDocumentBuilder();

			// messages elements
			Document doc = docBuilder.newDocument();
			Element rootElement = doc.createElement("messages");
			doc.appendChild(rootElement);

			// staff elements
			Element message = doc.createElement("message");
			rootElement.appendChild(message);

			// set attribute to staff element
			/*Attr attr = doc.createAttribute("id");
			attr.setValue("1");
			staff.setAttributeNode(attr);*/

			// errorMsg elements
			Element errorMsg = doc.createElement("errorMsg");
			errorMsg.appendChild(doc.createTextNode("ssssssss"));
			message.appendChild(errorMsg);

			// errorCode elements
			Element errorCode = doc.createElement("errorCode");
			errorCode.appendChild(doc.createTextNode("403"));
			message.appendChild(errorCode);

			// errorCode elements
			Element rawData = doc.createElement("rawData");
			rawData.appendChild(doc.createTextNode("....."));
			message.appendChild(rawData);

			// write the content into xml file
			TransformerFactory transformerFactory = TransformerFactory.newInstance();
			Transformer transformer = transformerFactory.newTransformer();

			StreamResult result = new StreamResult(new StringWriter());
			DOMSource source = new DOMSource(doc);
			transformer.transform(source, result);
			
			String xmlString = result.getWriter().toString().replaceAll("\\<\\?xml(.+?)\\?\\>", "").trim();			
			System.out.println(xmlString);

		} catch (DOMException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (TransformerConfigurationException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ParserConfigurationException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (TransformerFactoryConfigurationError e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (TransformerException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
