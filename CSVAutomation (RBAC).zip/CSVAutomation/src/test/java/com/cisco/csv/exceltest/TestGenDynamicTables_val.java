package com.cisco.csv.exceltest;

import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import com.mysql.jdbc.Connection;
import com.mysql.jdbc.DatabaseMetaData;
import com.mysql.jdbc.PreparedStatement;

public class TestGenDynamicTables_val {
	public static void main(String[] args) throws Exception {
		Class.forName("com.mysql.jdbc.Driver");
		Connection con = (Connection) DriverManager.getConnection("jdbc:mysql://localhost:3306/sample","root","cisco123");
		con.setAutoCommit(true);
		PreparedStatement pstm = null;
		
		try {

			String sessionUser ="sk";

			//create database sample 	
			try {
				StringBuilder sql_dbase = new StringBuilder();
				sql_dbase.append("create database sample");
				pstm = (PreparedStatement) con.prepareStatement(sql_dbase.toString());
				pstm.execute();
				//con.close();
			} catch (Exception e1) {
				System.out.println(e1.getMessage());
			}

			// get tables and delete those tables of logged in user
			try {
				DatabaseMetaData md = (DatabaseMetaData) con.getMetaData();
				ResultSet rs = md.getTables(null, null,sessionUser+"%", null);
				List<String> tblNames = new ArrayList<>();
				while (rs.next()) {
					System.out.println(rs.getString(3));
					if(rs.getString(3).startsWith(sessionUser)){
						tblNames.add(rs.getString(3));
					}

				} 

				for(String tn:tblNames){
					try {
						StringBuilder sql_drop = new StringBuilder();
						sql_drop.append("drop table "+tn);
						pstm = (PreparedStatement) con.prepareStatement(sql_drop.toString());
						pstm.execute();
					} catch (Exception e2) {
						// TODO Auto-generated catch block
						System.out.println("table doesnot exits to delete:"+e2.getMessage());
					}
				}

			} catch (Exception e) {
				System.out.println(""+e.getMessage());
			}



			File mastersheets = new File("C:\\Users\\skampli\\MyData\\workspace\\others\\TestData\\master_sheet_info.xml");
			DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
			DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
			Document doc = dBuilder.parse(mastersheets);
			doc.getDocumentElement().normalize();
			
			//get substringOverider form  sheets main tag
			String substror="";
			try {
				NodeList sList = doc.getElementsByTagName("Sheets");
				for (int s = 0; s<sList.getLength(); s++) {
					Node nodes = sList.item(s);
					if (nodes.getNodeType() == Node.ELEMENT_NODE) {
						Element ele = (Element) nodes;
						NodeList subor = ele.getElementsByTagName("substringOverider");
						substror =subor.item(0).getChildNodes().item(0).getNodeValue();
						//System.out.println(""+substror);
						}
					}
			} catch (Exception e2) {
				System.out.println("xml tag substringOverider undefined:"+e2.getMessage());
			}
			

			//get all sheets info
			NodeList nList = doc.getElementsByTagName("SheetInfo");
			Map<String, List<String>> xmlmap = new HashMap<String, List<String>>();
			for (int i = 0; i <nList.getLength(); i++) {

				Node node = nList.item(i);
				if (node.getNodeType() == Node.ELEMENT_NODE) {
					Element element = (Element) node;
					List<String> dnodeList = new ArrayList<>();
					NodeList nlsn = element.getElementsByTagName("SheetName");
					dnodeList.add(nlsn.item(0).getChildNodes().item(0).getNodeValue());
					//System.out.println("SheetName: "	+ nlsn.item(0).getChildNodes().item(0).getNodeValue());
					NodeList nlsr = element.getElementsByTagName("StartingRow");
					dnodeList.add(nlsr.item(0).getChildNodes().item(0).getNodeValue());
					//System.out.println("StartingRow: "	+ nlsr.item(0).getChildNodes().item(0).getNodeValue());
					NodeList cNames = element.getElementsByTagName("ColumnName");
					for (int j = 0; j < cNames.getLength(); j++) {
						//System.out.println("ColumnName : " + cNames.item(j).getTextContent());
						dnodeList.add(cNames.item(j).getTextContent().replaceAll("[^a-zA-Z0-9]", ""));
					}
					xmlmap.put(nlsn.item(0).getChildNodes().item(0).getNodeValue(), dnodeList);
				}

			}

			//iterate xmlmap items..
			for (Map.Entry<String, List<String>> me : xmlmap.entrySet()) {
				String k = me.getKey();
				List<String> valueList = me.getValue();
				//System.out.println("Key: " + k +"  "+ "Value: " +valueList);
			}

			
			//prepare data for sheetname table
			Map<String, List<String>> snMap = new HashMap<String, List<String>>();			
			for (Map.Entry<String, List<String>> me : xmlmap.entrySet()) {
				ArrayList<String> snList = new ArrayList<String>();
				String k = me.getKey();
				List<String> valueList = me.getValue();
				String [] vl = valueList.toString().split(",");
				snList.add(vl[0].replaceAll("[^\\w]", ""));
				snList.add(String.valueOf(vl[1].replaceAll("[^0-9]", "")));
				snList.add(sessionUser+"_"+vl[0].toLowerCase().replaceAll("[^\\w]", ""));
				
				//add values to snMap
				snMap.put(vl[0].toLowerCase().replaceAll("[^a-zA-Z0-9]", ""), snList);
			}

			// iteration dmap data 
			for(String k : snMap.keySet()){
				System.out.println("Key = " + k + " Values = " + snMap.get(k).toString());
			}
			
			
			//create sheetname table
			try {
				StringBuilder sql_crttbl = new StringBuilder();
				sql_crttbl.append("create table sample."+sessionUser+"_sheetnames").append("(\n");
				sql_crttbl.append(" `id` integer NOT NULL AUTO_INCREMENT,");
				sql_crttbl.append(" `sheetname` VARCHAR(250) NOT NULL,");
				sql_crttbl.append(" `startingrow` integer NOT NULL,");
				sql_crttbl.append(" `sheetnametables` VARCHAR(250) NOT NULL,");
				sql_crttbl.append("PRIMARY KEY (id)").append(");");
				//	System.out.println("create query: "+sql_crttbl);
				pstm = (PreparedStatement) con.prepareStatement(sql_crttbl.toString());
				pstm.execute();
				System.out.println("sheet table created");
				//con.close();
			} catch (Exception e1) {
				// TODO Auto-generated catch block
				System.out.println(" Error in creating sheetnames table:"+e1.getMessage());
			}	

			ArrayList<String> sheetnames = new ArrayList<String>();

			for (Map.Entry<String, List<String>> me : xmlmap.entrySet()) {
				ArrayList<String> cnxml = new ArrayList<String>();
				List<String> valueList = me.getValue();
				String[] mtnks = valueList.toString().split(",");

				String sheetName = mtnks[0].replace("[", "");
				sheetnames.add(sheetName);

				int StartingRow = Integer.parseInt(mtnks[1].replace(" ", ""));

				List<String> subStrings =new ArrayList<String>();

				// adding colummns to arraylist
				for(int c=2; c<mtnks.length;c++){
					cnxml.add(mtnks[c].replaceAll("[^a-zA-Z0-9]", ""));
				}
				
			//find Dulplicates columnnames in xml mappinf file and throw error
				Map<String, Integer> counts = new HashMap<String, Integer>();
				ArrayList<String> dupList = new ArrayList<String>();
				for (String str : cnxml) {
				    if (counts.containsKey(str)) {
				        counts.put(str, counts.get(str) + 1);
				    } else {
				        counts.put(str, 1);
				    }
				}
				
				for (Map.Entry<String, Integer> entry : counts.entrySet()) {
					if(entry.getValue() >1){
				   // System.out.println(entry.getKey());
				    dupList.add(entry.getKey());
					}
				}

			//find substring  in columnnames 
				ArrayList<String> carray = new ArrayList<String>();
				carray.addAll(cnxml);
			
				ArrayList<String> subVal = new ArrayList<String>();
				for(int i=0;i<cnxml.size();i++)
				{
					String cnxmlValue=cnxml.get(i);
					for(int j=0;j<carray.size();j++)
						{
							String carrayValue=carray.get(j);
							if(carrayValue.contains(cnxmlValue) || cnxmlValue.contains(carrayValue))
							{
								if(!(carrayValue.equalsIgnoreCase(cnxmlValue)))
								{
									if(subStrings.contains(carrayValue)||subStrings.contains(cnxmlValue)){
										//subVal.add(carrayValue);
										if(subVal.contains(carrayValue)){
											//do nothing
										}else{
											subVal.add(carrayValue);
										}
									}
									subStrings.add(carrayValue);
								}
							}
						}
				}
				
				for(String  sv :subVal){
					System.out.println("subVal : "+sv);
				}
				
				//rename  substring columnnames with substringOverider 	
				ArrayList<String> ccnList = new ArrayList<String>();
				ccnList.addAll(cnxml);
				
				for(int i=0;i<ccnList.size();i++)
				{
					String ccnVal=ccnList.get(i);
					for(int j=0;j<subVal.size();j++){
						String sbval = subVal.get(j);
						if(ccnVal.equals(sbval)){
							String rname = ccnVal + substror;
							ccnList.remove(ccnList.get(i));
							ccnList.add(i, rname);
						}
					}
				}
				
				/*for(String  ccnl :ccnList){
					System.out.println("ccnList : "+ccnl);
				}*/
				
				
				
				/*read xlsx file*/ 
				File file = new File("C:\\Users\\skampli\\MyData\\workspace\\others\\TestData\\HKICC_Migration 5_Morgan Stanley_Station Review_110416WTv2.xlsx");
				InputStream inputStream = new FileInputStream(file);
				XSSFWorkbook  wb = new XSSFWorkbook(inputStream);
				XSSFSheet sheet = wb.getSheet(sheetName);

				// get index of the columns and read 	
				ArrayList<String> cindex = new ArrayList<String>();				
				Iterator<Row> rowIterator = sheet.iterator();
				Row r = sheet.getRow(StartingRow-1);

				int patchColumn = -1;
				String text="";

				ArrayList<String> rcname = new ArrayList<String>();	

				HashMap<String, Integer> cimap = new HashMap<String,Integer>();

				for(String s :cnxml){
					for (int cn=0; cn<r.getLastCellNum(); cn++) {
						Cell c = r.getCell(cn);
						if (c == null || c.getCellType() == Cell.CELL_TYPE_BLANK) {
							// Can't be this cell - it's empty
							continue;
						}

						if (c.getCellType() == Cell.CELL_TYPE_STRING) {
							text = c.getStringCellValue();
							String cval = text.replaceAll("[^a-zA-Z0-9]", "");
							//text.replaceAll("[^a-zA-Z0-9]", "").equalsIgnoreCase(s)
							rcname.add(cval);
							if (cval.equals(s)) {
								patchColumn = cn;
								cindex.add(String.valueOf(patchColumn));
								cimap.put(cval, cn);
							}

						}

					}
				}


			//check for mismatched column names
				/*ArrayList<String> mismatchedlist = new ArrayList<String>();
				for (int i=0;i<cnxml.size();i++) {
					if(rcname.contains(cnxml.get(i))){
						//matched do nothing
					}else{
						//add to  mismatchedlist
						mismatchedlist.add(cnxml.get(i));
					}
				}

				//remove unmatched list from cnxml list
				for(String mm :mismatchedlist ){
					cnxml.remove(mm);
				}
*/
				//check for mismatched column names
				ArrayList<String> mismatchedlist = new ArrayList<String>();
				for (int i=0;i<ccnList.size();i++) {
					if(rcname.contains(cnxml.get(i))){
						//matched do nothing
					}else{
						//add to  mismatchedlist
						mismatchedlist.add(ccnList.get(i));
					}
				}

				//remove unmatched list from cnxml list
				for(String mm :mismatchedlist ){
					ccnList.remove(mm);
				}

				if(dupList.size() ==0){
					/*create dynamic tables with cnxml array from  xml/hrow ..*/
					try {
						StringBuilder sql = new StringBuilder();
						sql.append("CREATE TABLE sample."+ sessionUser+"_"+sheetName.replaceAll("[^\\w]", "")+"(\n");
						sql.append(" `SerialNumber` integer NOT NULL AUTO_INCREMENT,");

						for (String hclmns : ccnList) // or sArray
						{
							//System.out.println( hclmns );
							sql.append(hclmns).append(" ").append("VARCHAR(250) NOT NULL,");
						}

						sql.append("PRIMARY KEY (SerialNumber)");
						String withoutLastComma = sql.substring( 0, sql.length( )-1);
						String sqlcreate = withoutLastComma + "));";
						pstm = (PreparedStatement) con.prepareStatement(sqlcreate.toString());
						pstm.execute();
						//con.close();
						System.out.println("table created successfully");
					} catch (Exception e1) {
						System.out.println("Error in table creation:"+e1.getMessage());
						break;
					}

					for (int rowNumber = StartingRow;rowNumber <= sheet.getLastRowNum(); rowNumber++) {
						List<String> dynamiclist = new ArrayList<>();
						Map<String, List<String>> dmap = new HashMap<String, List<String>>();

						Row drow = sheet.getRow(rowNumber);

						//read cells from row if black set blank value
						Row frow = sheet.getRow(StartingRow-1);
						for (int cn = 0; cn < frow.getLastCellNum(); cn++) {
							String vcheck = frow.getCell(cn).toString();
							if(cnxml.contains(vcheck.replaceAll("[^a-zA-Z0-9]", ""))){
								Cell dcell = drow.getCell(cn, Row.CREATE_NULL_AS_BLANK);
							}

						}

						Iterator cellIterator = drow.cellIterator();					
						while (cellIterator.hasNext()) {
							Cell dcell = (Cell) cellIterator.next();
							if(drow.getRowNum() > 0){ //To filter column headings
								//for(String ci :cindex){
								for(String cikey : cimap.keySet()){
									dcell.setCellType(Cell.CELL_TYPE_STRING);
									if(dcell.getColumnIndex() == cimap.get(cikey)){// To match column index
										if(dcell == null || dcell.getCellType() == Cell.CELL_TYPE_BLANK){
											// This cell is empty
											dynamiclist.add("");
										}else if (dcell.getCellType() == Cell.CELL_TYPE_STRING)
										{
											dynamiclist.add(dcell.getStringCellValue().replaceAll("'", ""));
										}
									}
								}
								if(cimap.size() == dynamiclist.size()){
									dmap.put("#", dynamiclist);
								}	
							}
						}

						/*// iteration dmap data 
							for(String k : dmap.keySet()){
								System.out.println("Key = " + k + " Values = " + dmap.get(k).toString());
							}*/				


				//insert row data into tables
				if(dmap.size() !=0 ){
							try {
								for(String k : dmap.keySet()){
									StringBuilder sqlinsert = new StringBuilder();
									StringBuilder in_sql = new StringBuilder();
									sqlinsert.append("INSERT INTO sample."+ sessionUser+"_"+sheetName.replaceAll("[^\\w]", "")+" (");					
									for (String hclmns : ccnList) // or sArray
									{
										sqlinsert.append(hclmns).append(",");
									}
									String rcomma = sqlinsert.substring(0, sqlinsert.length( )-1);
									String insert_sql = rcomma + ")" +" "+"VALUES(";
									in_sql.append(insert_sql);

									/*String [] mval = dmap.get(k).toString().split(",");
											for(String mv: mval){
												in_sql.append("'").append(mv.toString().replaceAll("[^\\s-_:+;*&a-zA-Z0-9]", "")).append("'").append(",");
											}*/

									for(String key : dmap.keySet()){
										for(String v :dmap.get(key)){
											in_sql.append("'").append(v).append("'").append(",");
										}
									}

									String removecomma = in_sql.substring(0, in_sql.length()-1);
									String sqlinserts = removecomma.replace("+", "\\\\+").concat(");");
									System.out.println("final insert query:"+sqlinserts);
									pstm = (PreparedStatement) con.prepareStatement(sqlinserts);
									pstm.execute();
								}

							} catch (Exception e) {
								System.err.println("Error in insert records:"+e.getMessage());
							}
						}else{
							//String aryMMlist = mismatchedlist.toString().replace("[", "").replace("]", "").replace(", ", ",");
							System.err.println("Error in mapping xml please check ColumnNames");
						}
					} 
					
					/*if(mismatchedlist.size() !=0){
						String mmlist = mismatchedlist.toString().replace("[", "").replace("]", "").replace(", ", ",");
						System.out.println("Mismatched ColumnNames: "+mmlist);
					}*/
					
					if(subVal.size() !=0 && mismatchedlist.size() !=0){
						String substr = subVal.toString().replace("[", "").replace("]", "").replace(", ", ",");
						System.out.println("The following columns names has been automatically renamed by the tool "+substr+" Kindly use the new names in the mapping xml ");
						String mmlist = mismatchedlist.toString().replace("[", "").replace("]", "").replace(", ", ",");
						System.out.println("Mismatched ColumnNames: "+mmlist);
					}else if(subVal.size() !=0 && mismatchedlist.size() ==0 ){
						String substr = subVal.toString().replace("[", "").replace("]", "").replace(", ", ",");						
						System.out.println("The following columns names has been automatically renamed by the tool "+substr+" Kindly use the new names in the mapping xml ");
					}else if(mismatchedlist.size() !=0 && subVal.size() ==0){
						String mmlist = mismatchedlist.toString().replace("[", "").replace("]", "").replace(", ", ",");
						System.out.println("Mismatched ColumnNames: "+mmlist);
					} 
					
				}else{
					String duplist = dupList.toString().replace("[", "").replace("]", "").replace(", ", ",");
					System.err.println("The column names "+duplist+" are duplicates please check mapping xml \n");
				}
			}
			
			
			
			//finally insert sheet names values to sheetnames table			
			try {
				for(String key : snMap.keySet()){
					StringBuilder sqlinsert = new StringBuilder();
					sqlinsert.append("INSERT INTO sample."+sessionUser+"_sheetnames(sheetname,startingrow,sheetnametables) VALUES(");
					//sqlinsert.append("'").append(sheetnms).append("'");	

					for(String v :snMap.get(key)){
						sqlinsert.append("'").append(v).append("'").append(",");
					}
					String removecomma = sqlinsert.substring(0, sqlinsert.length()-1);
					String iSN_sql = removecomma + ")";
					System.out.println("final insert query:"+iSN_sql);
					pstm = (PreparedStatement) con.prepareStatement(iSN_sql.toString());
					pstm.execute();
					//System.out.println("sheetnames Records inserted");
				}	
			} catch (Exception e) {
				// TODO Auto-generated catch block
				System.err.println("Error in  inserting:"+e.getMessage());
			}

			pstm.close();
			con.close();

		} catch (Exception e) {
			System.err.println("error in reading excel sheet: "+e.getMessage());
		}finally {
		    if (pstm!= null) {
		        try {
		        	pstm.close();
		        	System.out.println("closing pstm connections");
		        } catch (SQLException e) { }
		    }
		    if (con != null) {
		        try {
		            con.close();
		            System.out.println("closing all opened connections");
		        } catch (SQLException e) { }
		    }
		}


	}

}
