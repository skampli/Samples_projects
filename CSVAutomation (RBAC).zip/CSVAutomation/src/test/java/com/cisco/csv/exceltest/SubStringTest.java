package com.cisco.csv.exceltest;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
public class SubStringTest {

	public static void main(String[] args) {

		List<String> cnxml =new ArrayList<String>();
		List<String> carray =new ArrayList<String>();

		Set<String> subStrings =new LinkedHashSet<>();

		//Set<String> subStrings =new LinkedHashSet<>();

		cnxml.add("Userid");
		cnxml.add("MACAddresses");
		cnxml.add("Directorynumber"); 
		cnxml.add("Mobility(SNR)");
		cnxml.add("User12");
		cnxml.add("ProductType");
		cnxml.add("PhoneButtonTemplate");
		cnxml.add("Firstname");
		cnxml.add("UserProfile");
		cnxml.add("ProductType123");

		carray.addAll(cnxml);

		for(int i=0;i<cnxml.size();i++)
		{
			String cnxmlValue=cnxml.get(i);

			//System.out.println("cnxmlValue: "+cnxmlValue);

			for(int j=0;j<carray.size();j++)
			{
				String carrayValue=carray.get(j);

				//System.out.println("carrayValue: "+carrayValue);

				if(carrayValue.contains(cnxmlValue) || cnxmlValue.contains(carrayValue))
				{
					if(!(carrayValue.equalsIgnoreCase(cnxmlValue)))
					{
						//System.out.println("not added in the substring");
						subStrings.add(carrayValue);
					}
				}
			}
		}

		for(String s: subStrings) 
		{
			System.out.println("subStrings : "+s);
		}
		
		
/*		//find dulipcates
		List<String> strings = new ArrayList<String>();
		strings.add("stack");
		strings.add("overflow");
		strings.add("all");
		strings.add("stack");
		strings.add("overflow");

		Map<String, Integer> counts = new HashMap<String, Integer>();

		for (String str : strings) {
		    if (counts.containsKey(str)) {
		        counts.put(str, counts.get(str) + 1);
		    } else {
		        counts.put(str, 1);
		    }
		}

		for (Map.Entry<String, Integer> entry : counts.entrySet()) {
			if(entry.getValue() >1){
		    System.out.println(entry.getKey());
			}
		}*/
		
		

	}

}
