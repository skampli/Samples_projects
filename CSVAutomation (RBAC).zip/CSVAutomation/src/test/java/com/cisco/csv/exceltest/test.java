package com.cisco.csv.exceltest;

import java.io.File;
import java.io.IOException;

import org.apache.commons.io.FileUtils;

public class test {
	public static void main(String[] args) throws IOException {
		//String parentDestination = "/usr/tomcat/apache-tomcat-7.0.52/webapps/csv/";
		String parentDestination = "C:\\csv";
		String temp = "C:\\temp";
		File sourceFile = new File(temp+ "\\Demo1.txt"); 
		String destination = parentDestination+"\\classes\\";
		File destinationDirectory = new File(destination);
		test.copyFileUsingApacheCommonsIO(sourceFile, destinationDirectory);
	}

	private static void copyFileUsingApacheCommonsIO(File source, File dest) throws IOException {
		FileUtils.copyFileToDirectory(source, dest);
		System.out.println("file moved to dir...");
	}
}