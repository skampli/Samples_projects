package com.cisco.csv.exceltest;

import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.util.NumberToTextConverter;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class GenTable {
	public static void main(String[] args) throws Exception {

		try {
			Class.forName("com.mysql.jdbc.Driver");
			Connection con = (Connection) DriverManager.getConnection("jdbc:mysql://localhost/sample","root","cisco123");
			con.setAutoCommit(true);
			PreparedStatement pstm = null;
			/*read xlsx file*/ 
			//InputStream ExcelFileToRead = new FileInputStream("D:\\reports\\user.xlsx");
			File file = new File("D:\\reports\\user.xlsx");
			InputStream inputStream = new FileInputStream(file);
			String fileName = file.getName().replace(".", "");
			String sessionUser ="admin";

			XSSFWorkbook  wb = new XSSFWorkbook(inputStream);
			XSSFWorkbook test = new XSSFWorkbook(); 
			XSSFSheet sheet = wb.getSheetAt(0);
			XSSFRow row = null ; 
			XSSFCell cell;

			Iterator<Row> rows = sheet.rowIterator();
			boolean skiprow =true;
			List<String> hrow= new ArrayList<String>();
			while (rows.hasNext() && skiprow )
			{
				row=(XSSFRow) rows.next();
				Iterator<Cell> cells = row.cellIterator();

				while (cells.hasNext())
				{
					cell=(XSSFCell) cells.next();
					hrow.add(cell.getStringCellValue().replaceAll("\\s+",""));
				}
				skiprow = false;
				//System.out.println();
			}
			//System.out.println("header columns:"+hrow);		

			/*create dynamic table with header row ..*/
			try {
				StringBuilder sql = new StringBuilder();
				sql.append("CREATE TABLE IF NOT EXISTS sample."+ sessionUser+"_"+ fileName +"(\n");
				//sql.append("CREATE TABLE IF NOT EXISTS sample.user (\n");
				for (String hclmns : hrow) // or sArray
				{
					//System.out.println( hclmns );
					sql.append(hclmns).append(" ").append("VARCHAR(250) NOT NULL,");
				}
				//sql.append("PRIMARY KEY (").append(hrow.get(0)).append(")");
				String withoutLastComma = sql.substring( 0, sql.length( )-1);
				String sqlcreate = withoutLastComma + ");";
				pstm = (PreparedStatement) con.prepareStatement(sqlcreate.toString());
				pstm.execute();
				//con.close();
				System.out.println("table created successfully");
			} catch (Exception e1) {
				e1.printStackTrace();
			}

			/*Read data records*/
			Map<String, List<String>> map = new HashMap<String, List<String>>();

			String key="#";
			while(rows.hasNext()) {
				List<String> dynamiclist = new ArrayList<>();
				Row drow = rows.next(); //Read Rows from Excel document       
				Iterator<Cell> cellIterator = drow.cellIterator();
				while(cellIterator.hasNext()) {
					Cell dcell = cellIterator.next(); //Fetch CELL
					dcell.setCellType(Cell.CELL_TYPE_STRING);
					switch(dcell.getCellType()) { //Identify CELL type
					case Cell.CELL_TYPE_NUMERIC:
						dcell.getNumericCellValue();
						break;
					case Cell.CELL_TYPE_STRING:
						dcell.getStringCellValue();
						break;
					case Cell.CELL_TYPE_BLANK:
						dcell.toString();
						break;
					}
					dynamiclist.add(dcell.getStringCellValue());
					map.put(key, new ArrayList<String>());
				}					
				map.put(key,dynamiclist);
				//print to check row data
				/*for(String k : map.keySet()){
					        System.out.println("Key = " + k + " Values = " + map.get(k).toString());
						}*/
				try {
					StringBuilder sqlinsert = new StringBuilder();
					StringBuilder in_sql = new StringBuilder();
					sqlinsert.append("INSERT INTO sample."+ sessionUser+"_"+ fileName +" (");					
					for (String hclmns : hrow) // or sArray
					{
						sqlinsert.append(hclmns).append(",");
					}
					String rcomma = sqlinsert.substring(0, sqlinsert.length( )-1);
					String insert_sql = rcomma + ")" +" "+"VALUES(";
					in_sql.append(insert_sql);
					for(String k : map.keySet()){
						// in_sql.append(map.get(k).toString());
						for(String v :map.get(k)){
							//System.out.println(""+v);
							in_sql.append("'").append(v).append("'").append(",");
						}
					}
					String removecomma = in_sql.substring(0, in_sql.length()-1);
					String sqlinserts = removecomma.concat(");");
					System.out.println("final insert query:"+sqlinserts);
					pstm = (PreparedStatement) con.prepareStatement(sqlinserts);
					pstm.execute();
					//con.close();
					System.out.println("Records inserted");
				} catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}


			con.close();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}
}
