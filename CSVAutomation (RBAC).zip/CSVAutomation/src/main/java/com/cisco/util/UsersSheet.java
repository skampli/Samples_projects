package com.cisco.util;

import java.util.Properties;



public class UsersSheet {
	
	private String userId;
	private String password;
	private int pin;
	private String firstName;
	private String lastName;
	private String telephoneNumber;
	private String mailId;
	private String managerUserId;
	private String department;
	private String controlDevice1;
	private String controlDevice2;
	private String defaultProfile;
	private String primaryExtension;
	private String controlledProfile1;
	
	

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public void setPin(int pin) {
		this.pin = pin;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public void setTelephoneNumber(String telephoneNumber) {
		this.telephoneNumber = telephoneNumber;
	}

	public void setMailId(String mailId) {
		this.mailId = mailId;
	}

	public void setManagerUserId(String managerUserId) {
		this.managerUserId = managerUserId;
	}

	public void setDepartment(String department) {
		this.department = department;
	}

	public void setControlDevice1(String controlDevice1) {
		this.controlDevice1 = controlDevice1;
	}

	public void setControlDevice2(String controlDevice2) {
		this.controlDevice2 = controlDevice2;
	}

	public void setDefaultProfile(String defaultProfile) {
		this.defaultProfile = defaultProfile;
	}

	public void setPrimaryExtension(String primaryExtension) {
		this.primaryExtension = primaryExtension;
	}

	public void setControlledProfile1(String controlledProfile1) {
		this.controlledProfile1 = controlledProfile1;
	}

	public String getUserId() {
		return userId;
	}

	public String getPassword() {
		return password;
	}

	public int getPin() {
		return pin;
	}

	public String getFirstName() {
		return firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public String getTelephoneNumber() {
		return telephoneNumber;
	}

	public String getMailId() {
		return mailId;
	}

	public String getManagerUserId() {
		return managerUserId;
	}

	public String getDepartment() {
		return department;
	}

	public String getControlDevice1() {
		return controlDevice1;
	}

	public String getControlDevice2() {
		return controlDevice2;
	}

	public String getDefaultProfile() {
		return defaultProfile;
	}

	public String getPrimaryExtension() {
		return primaryExtension;
	}

	public String getControlledProfile1() {
		return controlledProfile1;
	}
	
	
	

	
}
