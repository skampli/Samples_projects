package com.cisco.csv.writer;

import java.io.File;
import java.io.FileWriter;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.servlet.ServletOutputStream;

import org.apache.log4j.Logger;

public class ErrorWriter {

	private final static Logger logger = Logger.getLogger(ErrorWriter.class);





	public void createErrFile(List<Map<String, String>> listMapGetValues, ServletOutputStream out, String fileName)
	{
		File file=null;

		StringBuffer sb=new StringBuffer();

		String osname=System.getProperty("os.name").toLowerCase();


		try
		{

			file=new File(fileName);

			if(!(file.exists()))
			{
				file.createNewFile();

			}
			FileWriter fileWriter=new FileWriter(file);

			logger.info("Writing in the error file");

			for(Map<String, String> mapCsvWrite : listMapGetValues)
			{
				Set<String> keysWrite=mapCsvWrite.keySet();
				for(String keyWrite : keysWrite)
				{

					sb.append(mapCsvWrite.get(keyWrite));

				}

				if(osname.contains("windows"))
				{
					sb.append("\r\n");
				}
				else if(osname.contains("linux"))
				{
					sb.append("\n");
				}
			}

			logger.info("Error file is created");
			out.print(sb.toString());
			fileWriter.close();



		}
		catch(Exception e)
		{
			logger.error(e.getMessage());

			//e.printStackTrace();
		}





	}

	public void createErrorFileSave(List<Map<String, String>> listMapGetValues, String ErrorFileName)
	{
		File file=null;

		FileWriter fileWriter =null;
		
		String message="";
		try
		{
			file=new File(ErrorFileName);

			String osname=System.getProperty("os.name").toLowerCase();

			if (!file.exists()) {
				file.createNewFile();
			}
			else
			{
				if(file.delete())
				{
					file.createNewFile();
				}
				else
				{
					//logger.info("the file with the name "+fileNameUser+" was not deleted");
					logger.debug("the file with the name "+ErrorFileName+" was not deleted");
					//System.out.println("the file with the name "+fileNameUser+" was not deleted");
				}
			}

			fileWriter = new FileWriter(file);
			
			logger.info("Writing in the error log for saving");

			for(Map<String, String> mapCsvWrite : listMapGetValues)
			{
				Set<String> keysWrite=mapCsvWrite.keySet();
				for(String keyWrite : keysWrite)
				{

					fileWriter.write(mapCsvWrite.get(keyWrite));

				}

				if(osname.contains("windows"))
				{
					fileWriter.write("\r\n");
				}
				else if(osname.contains("linux"))
				{
					fileWriter.write("\n");
				}
			}

			logger.info("Error log is created and saved");
			
			fileWriter.flush();

			fileWriter.close();
			
			//message="The Error file got processed and is saved at:"+ErrorFileName;
			
			//message="The Error file got processed and is saved";
			
			
		}
		catch(Exception e)
		{
			logger.error(e.getMessage());
		}
		finally
		{
			try {
				if (fileWriter != null)
				{
					fileWriter.close();
				}
			} catch (Exception e) 
			{
				logger.error(e.getMessage());
			}

		}
		
		//return message;
	}
}
