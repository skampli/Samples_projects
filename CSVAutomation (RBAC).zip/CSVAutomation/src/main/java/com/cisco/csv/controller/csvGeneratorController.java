package com.cisco.csv.controller;



import java.io.File;
import java.io.InputStream;
import java.net.InetAddress;
import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.Set;
import java.util.concurrent.Executor;

import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.xpath.XPath;
import javax.xml.xpath.XPathConstants;
import javax.xml.xpath.XPathFactory;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;
import org.springframework.scheduling.annotation.AsyncConfigurer;
import org.springframework.scheduling.annotation.EnableAsync;
import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;
import org.w3c.dom.Document;
import org.w3c.dom.NodeList;

import com.cisco.csv.services.GenerateCsvService;
import com.cisco.csv.services.UserDaoImpl;
import com.cisco.csv.writer.CsvWriter;
import com.cisco.csv.writer.ErrorWriter;
import com.cisco.csv.writer.HeaderWriter;
import com.cisco.csv.writer.TarWriter;



@Controller
public class csvGeneratorController {

	private final static Logger logger = Logger.getLogger(csvGeneratorController.class);


	@Autowired
	UserDaoImpl userDAO;
	
	@Autowired
	CsvWriter csvWriter;
	
	@Autowired
	ErrorWriter errorWriter;
	
	@Autowired
	HeaderWriter headerWriter;
	
	@Autowired
	TarWriter tarWriter;
	

	


	@RequestMapping(value="/typeCsvGen" , params="downloadFile", method=RequestMethod.GET)
	public void users(HttpServletRequest request , HttpServletResponse response,final RedirectAttributes redirectAttributes) 
	{
		Authentication auth = SecurityContextHolder.getContext().getAuthentication();
		
		
		
		String sessionUser = auth.getName(); //get logged in username
		
		String type=request.getParameter("type");
		
		String fileName="";
		
		String errorFileName="";
		
		String headerFileName="";
		
		String absolutePathHeader="";
		
		String tarCsvFileName="";
		
		String absolutePathCsv="";
		
		String tarFileName="";
		
		List<String> message=new ArrayList<>();
		
		Document documentCommon=null;
		
		Document document=null;
		
		List<String> csvNames=new ArrayList<>();
		
		List<String> configNames=new ArrayList<>();
		
		List<Map<String, String>> listMapGet=null;
		
		Properties props=new Properties();
		
		Properties props1=new Properties();
		
		String headerMessage="";
		
		String fileNameTar="";
		
		String xmlConfigFilePath="";
		
		String xmlConfig="xml-configs";
		try
		{	
			/*Getting the hostName*/
			InetAddress ip;
			String hostname;
			ip = InetAddress.getLocalHost();
			hostname = ip.getHostName();
			
		/*For reading the config properties*/
			String propsName="/config.properties";
			InputStream inputStr = this.getClass().getResourceAsStream(propsName);
			props.load(inputStr);
			
			
			if(hostname.equalsIgnoreCase("DJHALANI-4L37L"))
			{
				Set<Object> configKeys=props.keySet();

				for(Object obj:configKeys)
				{
					String configKey=(String)obj;

					if(configKey.equalsIgnoreCase("filePath_local"))
					{

						String pathName=props.getProperty(configKey);

						xmlConfigFilePath=pathName+"xml-configs";

					}

				}
			}
			else
			{
				xmlConfigFilePath=props.getProperty("filePath_server")+xmlConfig;
				
			}
		/*For getting all the xml files from the xml-configs folder*/
			File folder = new File(xmlConfigFilePath);
			
			File[] listOfFiles = folder.listFiles();
			
			for(int i = 0; i < listOfFiles.length; i++)
			{
				String configName = listOfFiles[i].getName();
				
				if(configName.endsWith(".xml")||configName.endsWith(".XML"))
				{
					configNames.add(configName);
					
					if(configName.contains(sessionUser))
					{

						if(!(configName.contains("CommonConfig"))  )
						{
							
							
							if(!(configName.contains("master_sheet_info")   ))
							{
							
							
							
							int sizeOfUnderScore=configName.indexOf('_')+1;

							int xmlIndex1=configName.indexOf("xml")-1;

							String csvName=configName.substring(sizeOfUnderScore, xmlIndex1);
							//System.out.println("csv file name is*************"+csvName);
							logger.debug("csv file name is*************"+csvName);
							
							csvNames.add(csvName);
							
							}

						}

					}
				}
			}
			
			
			
			
			
/*			
			 for getting all the xml names in list
			PathMatchingResourcePatternResolver loader = new PathMatchingResourcePatternResolver();
			Resource[] resources;
			resources = loader.getResources("classpath:/*.xml");
			for (Resource resource : resources) 
			{
				//System.out.println("file names in resources is*******"+resource.getFile().getName());
				
				logger.debug("file names in resources is*******"+resource.getFile().getName());
				
				

				String configName=resource.getFile().getName();
				configNames.add(configName);
				if(configName.contains(sessionUser))
				{

					if(!(configName.contains("CommonConfig"))  )
					{
						
						
						if(!(configName.contains("master_sheet_info")   ))
						{
						
						
						
						int sizeOfUnderScore=configName.indexOf('_')+1;

						int xmlIndex1=configName.indexOf("xml")-1;

						String csvName=configName.substring(sizeOfUnderScore, xmlIndex1);
						//System.out.println("csv file name is*************"+csvName);
						logger.debug("csv file name is*************"+csvName);
						
						csvNames.add(csvName);
						
						}

					}

				}
			}
			
			*/
			
			
			/*	for getting the object for commonConfig*/
			for(String ConfigFileCommon:configNames)
			{
				if(ConfigFileCommon.contains(sessionUser)&& ConfigFileCommon.contains("CommonConfig"))
				{
					
					
					DocumentBuilderFactory builderFactoryCommon = DocumentBuilderFactory.newInstance();
					DocumentBuilder builderCommon = builderFactoryCommon.newDocumentBuilder();
					XPath xPathCommon =  XPathFactory.newInstance().newXPath();
					/*ClassLoader classLoaderCommon = getClass().getClassLoader();
					File fileCommon = new File(classLoaderCommon.getResource(ConfigFileCommon).getFile());*/
					
					String filePathCommon=xmlConfigFilePath+"/"+ConfigFileCommon;
					
					File fileCommon = new File(filePathCommon);
					
					
					if(fileCommon.exists())
					{
					documentCommon = builderCommon.parse(fileCommon);
					
					String expressionCommonName="/Configs/ColumnMapping/Column/Name";
					String expressionCommonValue="/Configs/ColumnMapping/Column/Value";
					
					NodeList nodeListCommonName=(NodeList)xPathCommon.compile(expressionCommonName).evaluate(documentCommon, XPathConstants.NODESET);
					NodeList nodeListCommonValue=(NodeList)xPathCommon.compile(expressionCommonValue).evaluate(documentCommon, XPathConstants.NODESET);
					for (int i = 0; i < nodeListCommonName.getLength(); i++)
					{
						
						logger.debug("Nodes Name and values "+nodeListCommonName.item(i).getFirstChild().getNodeValue() +"  :  "+nodeListCommonValue.item(i).getFirstChild().getNodeValue());
						


					}
				
					break;
				
					}
				}
			}
			
			/*for getting the object for the CSV to be generated*/
			
			logger.debug("for getting the object for the CSV to be generated");
			
			for(String configFile:configNames)
			{	
					for(String csvNameType:csvNames)
				{

				if(csvNameType.equalsIgnoreCase(type))
					{
						DocumentBuilderFactory builderFactory = DocumentBuilderFactory.newInstance();
						DocumentBuilder builder = builderFactory.newDocumentBuilder();
						
						String configFileLower=configFile.toLowerCase();
						int sizeOfUnderScore=configFileLower.indexOf('_')+1;

						int xmlIndex1=configFileLower.indexOf("xml")-1;

						String xmlConfigName=configFileLower.substring(sizeOfUnderScore, xmlIndex1);
						String sessionUserLower=sessionUser.toLowerCase();
						if(configFileLower.contains(sessionUserLower)&& xmlConfigName.equalsIgnoreCase(csvNameType))

						{

							
							
							logger.debug("config file is ********"+configFile);

							/*ClassLoader classLoader = getClass().getClassLoader();
							File file = new File(classLoader.getResource(configFile).getFile());*/
							
							String filePathCsv=xmlConfigFilePath+"/"+configFile;
							
							File file = new File(filePathCsv);


							if(file.exists())
							{

								
								
								logger.debug("the xml file name is **********"+file.getName());

								 document = builder.parse(file);
								 
								 logger.debug("file is present*************");
								// logger.info("file is present*************");
								

								break;
							}
							else
							{
								logger.debug("file is not present***************");
								//logger.info("file is not present***************");
								
							}


						}


					}


				}

			}
			
			request.getSession().setAttribute("type", type);
			fileName=type+".csv";
			
			tarFileName=type+".tar";
			
			//errorFileName="Error.log";
			
			errorFileName=type+"_"+"error.log";
			
			headerFileName="header.txt";
			
			//tarCsvFileName=sessionUser+"_"+type+".csv";
			

			
			
			listMapGet=userDAO.UserCsvGen(document,fileName,documentCommon,sessionUser);
			
			headerMessage=userDAO.generateHeader(document,documentCommon);
			
			fileNameTar=userDAO.generateFileName(document);
			
			String fullFileNameTar= fileNameTar+".csv";
			
			if(!(headerMessage.isEmpty()) &&  !(fileNameTar.isEmpty())   )
			{
				if(hostname.equalsIgnoreCase("DJHALANI-4L37L"))
				{
					Set<Object> configKeys=props.keySet();

					for(Object obj:configKeys)
					{
						String configKey=(String)obj;

						if(configKey.equalsIgnoreCase("filePath_local"))
						{

							String pathName=props.getProperty(configKey);

							//absolutePathHeader=pathName+headerFileName;
							
							absolutePathHeader=pathName+sessionUser+"/"+headerFileName;
							
							absolutePathCsv=pathName+sessionUser+"/"+fileNameTar+".csv";


						}

					}
				}
				else
				{
					//absolutePathHeader=props.getProperty("filePath_server")+headerFileName;
					
					absolutePathHeader=props.getProperty("filePath_server")+sessionUser+"/"+headerFileName;
					
					absolutePathCsv=props.getProperty("filePath_server")+sessionUser+"/"+fileNameTar+".csv";
				}
				
				headerWriter.createHeaderFile(headerMessage,absolutePathHeader);
				
				
			}
			
			
			
			
			
			
			for(Map<String, String> messageValue: listMapGet)
			{
				Set<String> keysMessageValue= new LinkedHashSet<>();
				keysMessageValue=messageValue.keySet();
			
				for(String key:keysMessageValue)
				{
					if(key.matches("[0-9]+"))
					{
						message.add(messageValue.get(key));
					}
				}
			}
			
			if(!(message.isEmpty() ))
			{
				//redirectAttributes.addFlashAttribute("messageDisplayed",message);
				//return "redirect:/csvGen";
				//response.sendRedirect("csvGen?messageDisplayed="+message);	
				
				response.setContentType("text/csv");
				
				response.setHeader("Content-Disposition","attachment;filename="+errorFileName);
				
				ServletOutputStream out=response.getOutputStream();
				
				errorWriter.createErrFile(listMapGet,out,errorFileName);
				
				out.close();
				
				
					
			}
			else
			{
				/*logger.info("writing in csv");
				response.setContentType("text/csv");
				//response.setHeader("Content-Disposition","attachment;filename="+csvWriter.getFileName());
				response.setHeader("Content-Disposition","attachment;filename="+fileName);
				ServletOutputStream out=response.getOutputStream();
				csvWriter.createCsv(listMapGet,out,fileName);
				out.close();*/
				
				if(!(headerMessage.isEmpty()) &&  !(fileNameTar.isEmpty()) )
				{
					csvWriter.createCsvtar(listMapGet, absolutePathCsv);
				}
				else
				{
					logger.info("writing in csv");
					response.setContentType("text/csv");
					//response.setHeader("Content-Disposition","attachment;filename="+csvWriter.getFileName());
					response.setHeader("Content-Disposition","attachment;filename="+fileName);
					ServletOutputStream out=response.getOutputStream();
					csvWriter.createCsv(listMapGet,out,fileName);
					out.close();
				}
				
				
			}
			
			if(!(headerMessage.isEmpty())  &&  !(fileNameTar.isEmpty())   )
			{
				logger.info("taring the files");
				response.setContentType("application/octet-stream");
				response.setHeader("Content-Disposition","attachment;filename="+tarFileName);
				ServletOutputStream out=response.getOutputStream();
				
				tarWriter.createTar(absolutePathHeader, headerFileName,absolutePathCsv,fullFileNameTar, out, tarFileName);
				
				
				
			
				out.close();
				
				
				
				
			}
			
			
			
			for(Map<String, String> mapGet:listMapGet)
			{
				Set<String> keys=mapGet.keySet();

				for(String key:keys)
				{


					//System.out.println(key+":"+mapGet.get(key));
					//logger.info(key+":"+mapGet.get(key));
					logger.debug(key+":"+mapGet.get(key));
				}
				//System.out.println("------------------------");
				//logger.info("------------------------------");
				logger.debug("------------------------------");
				
			}
			
			//message=validateAttribute(document,listMapGet);
			
			
			
			//logger.debug("the value of message for the validation of attribute is************"+message);
			
		
			
			
		}
		catch(Exception ex)
		{
			logger.error(ex.getMessage());
			
			//ex.printStackTrace();
		}

		//String ValueTest=props.getProperty("USER ID");
		
		
		
	}
	
	
	
	@RequestMapping(value="/typeCsvGen" , params="saveFile", method=RequestMethod.GET)
	public String saveCsvFile(HttpServletRequest request , HttpServletResponse response,final RedirectAttributes redirectAttributes)
	{
		Authentication auth = SecurityContextHolder.getContext().getAuthentication();
		
		String sessionUser = auth.getName(); //get logged in username
		
		String type=request.getParameter("type");
		
	String fileName="";
		
		String errorFileName="";
		
		 String absolutePathError="";
		
			String absolutePathCsv="";
		
		 List<String> message=new ArrayList<>();
		
		 	Document documentCommon=null;
		
		 Document document=null;
		
		List<String> csvNames=new ArrayList<>();
		
		List<String> configNames=new ArrayList<>();
		
			List<Map<String, String>> listMapGet=null;
		
		Properties props=new Properties();
	
		String xmlConfigFilePath="";
		
		String xmlConfig="xml-configs";
		
		final String messageSaved="";
		
		try
		{
			/*Getting the hostName*/
			InetAddress ip;
			String hostname;
			ip = InetAddress.getLocalHost();
			hostname = ip.getHostName();
			
		/*For reading the config properties*/
			String propsName="/config.properties";
			InputStream inputStr = this.getClass().getResourceAsStream(propsName);
			props.load(inputStr);
			
			fileName=type+".csv";
			
			errorFileName=type+"_"+"error.log";
			
			
			if(hostname.equalsIgnoreCase("DJHALANI-4L37L"))
			{
				Set<Object> configKeys=props.keySet();

				for(Object obj:configKeys)
				{
					String configKey=(String)obj;

					if(configKey.equalsIgnoreCase("filePath_local"))
					{

						String pathName=props.getProperty(configKey);

						xmlConfigFilePath=pathName+"xml-configs";
						
						absolutePathCsv=pathName+sessionUser+"/"+fileName;
						
						absolutePathError=pathName+sessionUser+"/"+errorFileName;

					}

				}
			}
			else
			{
				xmlConfigFilePath=props.getProperty("filePath_server")+xmlConfig;
				
				absolutePathCsv=props.getProperty("filePath_server")+sessionUser+"/"+fileName;
				
				absolutePathError=props.getProperty("filePath_server")+sessionUser+"/"+errorFileName;
				
			}
			
			
			/*For getting all the xml files from the xml-configs folder*/
			File folder = new File(xmlConfigFilePath);
			
			File[] listOfFiles = folder.listFiles();
			
			for(int i = 0; i < listOfFiles.length; i++)
			{
				String configName = listOfFiles[i].getName();
				
				if(configName.endsWith(".xml")||configName.endsWith(".XML"))
				{
					configNames.add(configName);
					
					if(configName.contains(sessionUser))
					{

						if(!(configName.contains("CommonConfig"))  )
						{
							
							
							if(!(configName.contains("master_sheet_info")   ))
							{
							
							
							
							int sizeOfUnderScore=configName.indexOf('_')+1;

							int xmlIndex1=configName.indexOf("xml")-1;

							String csvName=configName.substring(sizeOfUnderScore, xmlIndex1);
							//System.out.println("csv file name is*************"+csvName);
							logger.debug("csv file name is*************"+csvName);
							
							csvNames.add(csvName);
							
							}

						}

					}
				}
			}
			
			
			/*	for getting the object for commonConfig*/
			for(String ConfigFileCommon:configNames)
			{
				if(ConfigFileCommon.contains(sessionUser)&& ConfigFileCommon.contains("CommonConfig"))
				{
					
					
					DocumentBuilderFactory builderFactoryCommon = DocumentBuilderFactory.newInstance();
					DocumentBuilder builderCommon = builderFactoryCommon.newDocumentBuilder();
					XPath xPathCommon =  XPathFactory.newInstance().newXPath();
					/*ClassLoader classLoaderCommon = getClass().getClassLoader();
					File fileCommon = new File(classLoaderCommon.getResource(ConfigFileCommon).getFile());*/
					
					String filePathCommon=xmlConfigFilePath+"/"+ConfigFileCommon;
					
					File fileCommon = new File(filePathCommon);
					
					
					if(fileCommon.exists())
					{
					documentCommon = builderCommon.parse(fileCommon);
					
					String expressionCommonName="/Configs/ColumnMapping/Column/Name";
					String expressionCommonValue="/Configs/ColumnMapping/Column/Value";
					
					NodeList nodeListCommonName=(NodeList)xPathCommon.compile(expressionCommonName).evaluate(documentCommon, XPathConstants.NODESET);
					NodeList nodeListCommonValue=(NodeList)xPathCommon.compile(expressionCommonValue).evaluate(documentCommon, XPathConstants.NODESET);
					for (int i = 0; i < nodeListCommonName.getLength(); i++)
					{
						
						logger.debug("Nodes Name and values "+nodeListCommonName.item(i).getFirstChild().getNodeValue() +"  :  "+nodeListCommonValue.item(i).getFirstChild().getNodeValue());
						


					}
				
					break;
				
					}
				}
			}
			
			
			/*for getting the object for the CSV to be generated*/
			
			logger.debug("for getting the object for the CSV to be generated");
			
			for(String configFile:configNames)
			{	
					for(String csvNameType:csvNames)
				{

				if(csvNameType.equalsIgnoreCase(type))
					{
						DocumentBuilderFactory builderFactory = DocumentBuilderFactory.newInstance();
						DocumentBuilder builder = builderFactory.newDocumentBuilder();
						
						String configFileLower=configFile.toLowerCase();
						int sizeOfUnderScore=configFileLower.indexOf('_')+1;

						int xmlIndex1=configFileLower.indexOf("xml")-1;

						String xmlConfigName=configFileLower.substring(sizeOfUnderScore, xmlIndex1);
						String sessionUserLower=sessionUser.toLowerCase();
						if(configFileLower.contains(sessionUserLower)&& xmlConfigName.equalsIgnoreCase(csvNameType))

						{

							
							
							logger.debug("config file is ********"+configFile);

							/*ClassLoader classLoader = getClass().getClassLoader();
							File file = new File(classLoader.getResource(configFile).getFile());*/
							
							String filePathCsv=xmlConfigFilePath+"/"+configFile;
							
							File file = new File(filePathCsv);


							if(file.exists())
							{

								
								
								logger.debug("the xml file name is **********"+file.getName());

								 document = builder.parse(file);
								 
								 logger.debug("file is present*************");
								// logger.info("file is present*************");
								

								break;
							}
							else
							{
								logger.debug("file is not present***************");
								//logger.info("file is not present***************");
								
							}


						}


					}


				}

			}
			
			
			Thread thread = new Thread(new GenerateCsvService(document, fileName,  documentCommon ,  absolutePathError ,  absolutePathCsv,sessionUser));
			
			thread.start();
			
	String messageDisplayed="The processing started in the background, please download the file from home page";
			
	redirectAttributes.addFlashAttribute("messageDisplayed",messageDisplayed);
			
		}
		catch(Exception e)
		{
			logger.error(e.getMessage());
		}
		
	return 	"redirect:/csvGen";
		
	}
	






}
