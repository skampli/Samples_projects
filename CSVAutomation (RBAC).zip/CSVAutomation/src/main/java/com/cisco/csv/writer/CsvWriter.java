package com.cisco.csv.writer;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;


import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;



public class CsvWriter {
	
	private final static Logger logger = Logger.getLogger(CsvWriter.class);

	
	//String fileName="Users.csv";
	
	
	
	
	

	/*public String getFileName() {
		return fileName;
	}*/




	




	public void createCsv(List<Map<String, String>> listMapGetValues, ServletOutputStream out, String fileName) throws IOException{
		File file=null;
		
		List<String> fileHeader=null;
		
		fileHeader=new ArrayList<>();
		//fileName=request.getParameter("type")+"."+"csv";
	//	System.out.println("File name is"+fileName);
		//logger.info("File name is"+fileName);
		logger.debug("File name is"+fileName);
		
		file=new File(fileName);
		
		int count=0;
		int countContent=0;
		if(!(file.exists()))
		{
			file.createNewFile();

		}
		FileWriter fileWriter=new FileWriter(file);
		//PrintWriter pw=response.getWriter();
		
		for(Map<String, String> mapCsvValues:listMapGetValues)
		{
			Set<String> keys=mapCsvValues.keySet();

			for(String key:keys)
			{
				fileHeader.add(key);
			}
			break;
		}

		/*for writing the file header*/

		StringBuffer sb=new StringBuffer();

		for(String header:fileHeader)
		{

			sb.append(header);

			while(count<(fileHeader.size()-1))
			{

				sb.append(",");
				
				count=count+1;
				break;
			}

		}
		sb.append("\n");
		
	//	System.out.println(sb.toString());
		//fileWriter.write(sb.toString());
		//response.getOutputStream().w
		//pw.write(sb.toString());
		//response.getWriter();
		out.print(sb.toString());
		sb.delete(0, sb.length());
		
		
		//StringBuffer sbContent=new StringBuffer();
		
		/*for writing the content of the file*/
		
	for(Map<String, String> mapCsvWrite : listMapGetValues)
	{
		Set<String> keysWrite=mapCsvWrite.keySet();
		for(String keyWrite : keysWrite)
		{
			for(String fileHeadKey: fileHeader)
			{
				if(fileHeadKey.equalsIgnoreCase(keyWrite))
				{
					if(mapCsvWrite.get(fileHeadKey).contains(",")) 
					{
						
					sb.append("\"" + mapCsvWrite.get(fileHeadKey) + "\"");
					}
					else
					{
				sb.append(mapCsvWrite.get(fileHeadKey));
					}
					while(countContent<(fileHeader.size()-1))
					{

						sb.append(",");
						
						countContent=countContent+1;
						break;
					}
				}
			}
			
		}
		countContent=0;
		sb.append("\n");
	}
	
	//System.out.println(sb.toString());
	//fileWriter.write(sb.toString());
	//pw.write(sb.toString());
	//pw.close();
	out.print(sb.toString());
	//fileHeader.clear();
	fileWriter.close();
	
	logger.info("csv created");
	
	
	
	}
	
	public void createCsvtar(List<Map<String, String>> listMapGetValues, String tarFileName)
	{
		File file=null;
		
		FileWriter fr = null;
		
        BufferedWriter br = null;
		
		List<String> fileHeader=null;
		
		int count=0;
		
		int countContent=0;
		
		fileHeader=new ArrayList<>();
		
		
		
		try
		{
			file=new File(tarFileName);
			
			if(!(file.exists()))
			{
				file.createNewFile();

			}
			
			logger.info("Writing in the csv for tar");
			
			fr = new FileWriter(file);
			
            br = new BufferedWriter(fr);
			
			for(Map<String, String> mapCsvValues:listMapGetValues)
			{
				Set<String> keys=mapCsvValues.keySet();

				for(String key:keys)
				{
					fileHeader.add(key);
				}
				break;
			}
			
			/*for writing the file header*/

			StringBuffer sb=new StringBuffer();

			for(String header:fileHeader)
			{

				sb.append(header);

				while(count<(fileHeader.size()-1))
				{

					sb.append(",");
					
					count=count+1;
					break;
				}

			}
			sb.append("\n");
			
			br.write(sb.toString());
			
			sb.delete(0, sb.length());
			
			for(Map<String, String> mapCsvWrite : listMapGetValues)
			{
				Set<String> keysWrite=mapCsvWrite.keySet();
				for(String keyWrite : keysWrite)
				{
					for(String fileHeadKey: fileHeader)
					{
						if(fileHeadKey.equalsIgnoreCase(keyWrite))
						{
							if(mapCsvWrite.get(fileHeadKey).contains(",")) 
							{
								
							sb.append("\"" + mapCsvWrite.get(fileHeadKey) + "\"");
							}
							else
							{
						sb.append(mapCsvWrite.get(fileHeadKey));
							}
							while(countContent<(fileHeader.size()-1))
							{

								sb.append(",");
								
								countContent=countContent+1;
								break;
							}
						}
					}
					
				}
				countContent=0;
				sb.append("\n");
			}
			
			logger.info("Csv tar is created");
			
			br.write(sb.toString());
		}
		catch(Exception e)
		{
			logger.error(e.getMessage());
		}
		
		finally
		{
			try
			{
				br.close();
				fr.close();
			}
			catch(Exception e)
			{
				logger.error(e.getMessage());
			}
		}
		
		
	}
	
	public void createCsvSave(List<Map<String, String>> listMapGetValues, String csvrFileName)
	{
		File file=null;
		
		FileWriter fr = null;
		
        BufferedWriter br = null;
		
		List<String> fileHeader=null;
		
		int count=0;
		
		int countContent=0;
		
		fileHeader=new ArrayList<>();
		
		String message="";
		
		try
		{
			file=new File(csvrFileName);
			
			if(!(file.exists()))
			{
				file.createNewFile();

			}
			
			logger.info("Writing in the csv for saving");
			
			fr = new FileWriter(file);
			
            br = new BufferedWriter(fr);
			
			for(Map<String, String> mapCsvValues:listMapGetValues)
			{
				Set<String> keys=mapCsvValues.keySet();

				for(String key:keys)
				{
					fileHeader.add(key);
				}
				break;
			}
			
			/*for writing the file header*/

			StringBuffer sb=new StringBuffer();

			for(String header:fileHeader)
			{

				sb.append(header);

				while(count<(fileHeader.size()-1))
				{

					sb.append(",");
					
					count=count+1;
					break;
				}

			}
			sb.append("\n");
			
			br.write(sb.toString());
			
			sb.delete(0, sb.length());
			
			for(Map<String, String> mapCsvWrite : listMapGetValues)
			{
				Set<String> keysWrite=mapCsvWrite.keySet();
				for(String keyWrite : keysWrite)
				{
					for(String fileHeadKey: fileHeader)
					{
						if(fileHeadKey.equalsIgnoreCase(keyWrite))
						{
							if(mapCsvWrite.get(fileHeadKey).contains(",")) 
							{
								
							sb.append("\"" + mapCsvWrite.get(fileHeadKey) + "\"");
							}
							else
							{
						sb.append(mapCsvWrite.get(fileHeadKey));
							}
							while(countContent<(fileHeader.size()-1))
							{

								sb.append(",");
								
								countContent=countContent+1;
								break;
							}
						}
					}
					
				}
				countContent=0;
				sb.append("\n");
			}
			
			logger.info("Csv is created and saved");
			
			//message="The Csv file got processed and is saved at:"+csvrFileName;
			
			//message="The Csv file got processed and is saved";
			
			br.write(sb.toString());
		}
		catch(Exception e)
		{
			logger.error(e.getMessage());
		}
		
		finally
		{
			try
			{
				br.close();
				fr.close();
			}
			catch(Exception e)
			{
				logger.error(e.getMessage());
			}
		}
		
		
		//return message;
		
	}


}
