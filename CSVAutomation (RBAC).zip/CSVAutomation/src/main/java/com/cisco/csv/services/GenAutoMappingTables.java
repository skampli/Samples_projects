package com.cisco.csv.services;

import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.net.InetAddress;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.Set;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

import org.apache.log4j.Logger;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import com.mysql.jdbc.Connection;
import com.mysql.jdbc.DatabaseMetaData;
import com.mysql.jdbc.PreparedStatement;






public class GenAutoMappingTables {

	private final static Logger logger = Logger.getLogger(GenAutoMappingTables.class);


	//public String excuteMethod( String fileNameUser) throws ClassNotFoundException, SQLException
	public List<Map<String, String>> excuteMethod( String fileNameUser) throws ClassNotFoundException, SQLException
	{
		Authentication auth = SecurityContextHolder.getContext().getAuthentication();
		String sessionUser = auth.getName();
		String absolutePath="";
		String message="";
		Class.forName("com.mysql.jdbc.Driver");
		Connection con = (Connection) DriverManager.getConnection("jdbc:mysql://localhost:3306/sample","root","cisco123");
		con.setAutoCommit(true);
		PreparedStatement pstm = null;
		
		List<Map<String, String>>  msgMapList= new ArrayList<>();
		
		Map<String, String> colNamesMapGet = new LinkedHashMap<>();
		
		Map<String, String> msgMap=  new LinkedHashMap<>();
		
		Properties props=new Properties();
		String xmlConfigFilePath="";

		try
		{
			/*Getting the hostName*/
			InetAddress ip;
			String hostname;
			ip = InetAddress.getLocalHost();
			hostname = ip.getHostName();
			
		/*For reading the config properties*/
			String propsName="/config.properties";
			InputStream inputStr = this.getClass().getResourceAsStream(propsName);
			props.load(inputStr);
			
			if(hostname.equalsIgnoreCase("SKAMPLI-80MHF"))
			{
				Set<Object> configKeys=props.keySet();

				for(Object obj:configKeys)
				{
					String configKey=(String)obj;

					if(configKey.equalsIgnoreCase("filePath_local"))
					{

						String pathName=props.getProperty(configKey);

						xmlConfigFilePath=pathName+"xml-configs";

					}

				}
			}
			else
			{
				xmlConfigFilePath=props.getProperty("filePath_server")+"xml-configs";
				
			}

			//File mastersheets = new File(getClass().getClassLoader().getResource(sessionUser+"_"+"master_sheet_info.xml").getFile());
			
			File mastersheets = new File(xmlConfigFilePath+"/"+sessionUser+"_"+"master_sheet_info.xml");

			DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
			DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
			Document doc = dBuilder.parse(mastersheets);
			doc.getDocumentElement().normalize();

			//get substringOverider form  sheets main tag
			String substror="";
			String dbSuffix="";
			String dbMaxCols="";
			try {
				NodeList sList = doc.getElementsByTagName("Sheets");
				for (int s = 0; s<sList.getLength(); s++) {
					Node nodes = sList.item(s);
					if (nodes.getNodeType() == Node.ELEMENT_NODE) {
						Element ele = (Element) nodes;
						NodeList subor = ele.getElementsByTagName("substringOverider");
						substror =subor.item(0).getChildNodes().item(0).getNodeValue();
						
						NodeList dbSub = ele.getElementsByTagName("dbSuffix");
						dbSuffix =dbSub.item(0).getChildNodes().item(0).getNodeValue();
						
						NodeList maxColumn = ele.getElementsByTagName("dbMaxColumns");
						dbMaxCols =maxColumn.item(0).getChildNodes().item(0).getNodeValue();
						
						//System.out.println("max db column:"+dbMaxCols);
						//System.out.println("db suffix:"+dbSuffix);
						
						
						
						
						
						//System.out.println(""+substror);
					}
				}
			} catch (Exception e2) {
				logger.error("xml tag substringOverider undefined: "+e2.getMessage());
			}

		/*	Properties props=new Properties();
			String propsName="/config.properties";
			InputStream inputStr = this.getClass().getResourceAsStream(propsName);
			props.load(inputStr);
			InetAddress ip;
			String hostname;
			ip = InetAddress.getLocalHost();
			hostname = ip.getHostName();*/
			if(hostname.equalsIgnoreCase("SKAMPLI-80MHF"))
			{
				Set<Object> configKeys=props.keySet();

				for(Object obj:configKeys)
				{
					String configKey=(String)obj;

					if(configKey.equalsIgnoreCase("filePath_local"))
					{
						String pathName=props.getProperty(configKey);
						absolutePath=pathName+fileNameUser;
					}
				}
			}
			else
			{
				absolutePath=props.getProperty("filePath_server")+fileNameUser;
			}

			File file = new File(absolutePath);   
			//File file = new File(fileNameUser);
			String fileName1=file.getName();
			if(!(fileName1.endsWith(".xlsx")))
			{
				message="Please upload the file with the .xlsx extension";
				
				msgMap.put("0", message);
				
				msgMapList.add(msgMap);
				
				msgMapList.add(colNamesMapGet);
				
				return msgMapList;
				//return message;
			}
			else
			{
				InputStream inputStream = new FileInputStream(file);
				XSSFWorkbook  wb = new XSSFWorkbook(inputStream);
				//XSSFSheet sheet = wb.getSheetAt(0);


				//create database sample 	
				try {
					StringBuilder sql_dbase = new StringBuilder();
					sql_dbase.append("create database sample");
					pstm = (PreparedStatement) con.prepareStatement(sql_dbase.toString());
					pstm.execute();
					//con.close();
					//System.out.println("c");
					logger.info("Database created successfully");
				} 
				catch (Exception e1) 
				{
					logger.error(e1.getMessage());
				}

				// get tables and delete those tables of logged in user
				try {
					DatabaseMetaData md = (DatabaseMetaData) con.getMetaData();
					ResultSet rs = md.getTables(null, null,sessionUser+"%", null);
					List<String> tblNames = new ArrayList<>();
					while (rs.next()) {
						//System.out.println(rs.getString(3));
						if(rs.getString(3).startsWith(sessionUser)){
							tblNames.add(rs.getString(3));
						}

					} 

					for(String tn:tblNames){
						try {
							StringBuilder sql_drop = new StringBuilder();
							sql_drop.append("drop table "+tn);
							pstm = (PreparedStatement) con.prepareStatement(sql_drop.toString());
							pstm.execute();
						} catch (Exception e2) {
							// TODO Auto-generated catch block
							//System.out.println("table doesnot exits to delete:"+e2.getMessage());
							logger.error("table doesnot exits to delete:"+e2.getMessage());
						}
					}

				} 
				catch (Exception e) 
				{
					//System.out.println(""+e.getMessage());
					logger.error(e.getMessage());
				}

				//read xlsx sheet header row
				ArrayList<String> sNames = new ArrayList<String>();

				for(int j = wb.getNumberOfSheets() - 1; j >= 0; j--)
				{
					List<String> columnNames=new ArrayList<>();
					List<String> orginalColNames= new ArrayList<>();
					
					XSSFSheet sheet = wb.getSheetAt(j);
					sNames.add(sheet.getSheetName());
					
					String sheetName= sheet.getSheetName();

					/*//prepare data for sheetname table
					Map<String, List<String>> snMap = new HashMap<String, List<String>>();
					ArrayList<String> snList = new ArrayList<String>();
					snList.add(sheet.getSheetName().replaceAll("[^\\w]", ""));
					snList.add("1");
					snList.add(sessionUser+"_"+sheet.getSheetName().replaceAll("[^\\w]", "").toLowerCase());
					snMap.put(sheet.getSheetName().replaceAll("[^a-zA-Z0-9]", ""), snList);*/

					XSSFRow row; 
					XSSFCell cell;
					Iterator<Row> rows = sheet.rowIterator();
					boolean skiprow =true;
					List<String> hrow= new ArrayList<String>();

					List<String> errorMessages=new ArrayList<String>();

					while (rows.hasNext() && skiprow )
					{
						row=(XSSFRow) rows.next();
						Iterator<Cell> cells = row.cellIterator();
						while (cells.hasNext())
						{
							cell=(XSSFCell) cells.next();

							// adding colummns to arraylist 
							
							orginalColNames.add(cell.getStringCellValue());

							columnNames.add(cell.getStringCellValue().trim().replaceAll("[^a-zA-Z0-9]", "")     );

						}
						skiprow = false;
					}


					Collections.sort(sNames, String.CASE_INSENSITIVE_ORDER);

					//find Duplicates columnnames and throw error
					Map<String, Integer> counts = new HashMap<String, Integer>();
					ArrayList<String> dupList = new ArrayList<String>();
					for (String str : columnNames)
					{
						if (counts.containsKey(str)) {
							counts.put(str, counts.get(str) + 1);
						} else {
							counts.put(str, 1);
						}
					}

					for (Map.Entry<String, Integer> entry : counts.entrySet())
					{
						if(entry.getValue() >1){
							// System.out.println(entry.getKey());
							dupList.add(entry.getKey());
						}
					}


					//find substring  in columnnames 
					ArrayList<String> carray = new ArrayList<String>();

					List<String> subStrings =new ArrayList<String>();

					carray.addAll(columnNames);

					ArrayList<String> subVal = new ArrayList<String>();
					/*for(int i=0;i<columnNames.size();i++)
					{
						String cnxmlValue=columnNames.get(i);
						for(int k=0;k<carray.size();k++)
						{
							String carrayValue=carray.get(k);
							if(carrayValue.contains(cnxmlValue) || cnxmlValue.contains(carrayValue))
							{
								if(!(carrayValue.equalsIgnoreCase(cnxmlValue)))
								{
									//System.out.println("not added in the substring");
									if(subStrings.contains(carrayValue)||subStrings.contains(cnxmlValue)){
										//subVal.add(carrayValue);
										if(subVal.contains(carrayValue)){
											//do nothing
										}
										else{
											subVal.add(carrayValue);
										}
									}
									subStrings.add(carrayValue);
								}
							}
						}
					}*/
					
					
					
					for(int i=0;i<columnNames.size();i++)
					{
						String stringToAdd = columnNames.get(i);
						
						for(int k=0;k<carray.size();k++)
						{
							String stringToCompare =carray.get(k);
							
							if(stringToCompare.contains(stringToAdd))
							{
								if(!(stringToAdd.equalsIgnoreCase(stringToCompare)))
								{
									subVal.add(stringToAdd);
									break;
								}
							}
							
						}
						
					}
					

					//rename  substring columnnames with substringOverider 	
					ArrayList<String> ccnList = new ArrayList<String>();
					
					int count=1;
					
					ccnList.addAll(columnNames);

					for(int i=0;i<ccnList.size();i++)
					{
						String ccnVal=ccnList.get(i);
						
						for(int r=0;r<subVal.size();r++)
						{
							String sbval = subVal.get(r);
							if(ccnVal.equals(sbval))
							{
								String rname = ccnVal+"_"+count + substror;
								
								ccnList.remove(ccnList.get(i));
								
								ccnList.add(i, rname);
								
								count=count+1;
							}
						}
					}
					
				
					
					
		


					//create sheet table
					try {
						StringBuilder sql_crttbl = new StringBuilder();
						sql_crttbl.append("create table sample."+sessionUser+"_sheetnames").append("(\n");
						sql_crttbl.append(" `id` integer NOT NULL AUTO_INCREMENT,");
						sql_crttbl.append(" `sheetname` VARCHAR(250) NOT NULL,");
						sql_crttbl.append(" `startingrow` integer NOT NULL,");
						sql_crttbl.append(" `sheetnametables` VARCHAR(250) NOT NULL,");
						sql_crttbl.append("PRIMARY KEY (id)").append(");");
						logger.info("create query: "+sql_crttbl);
						pstm = (PreparedStatement) con.prepareStatement(sql_crttbl.toString());
						pstm.execute();
					} 
					catch (Exception e1)
					{
						logger.error(" Error in creating sheetnames table:"+e1.getMessage());
					}

					if(dupList.size() ==0)
					{
						String key="#";

						Row frow = sheet.getRow(0);
						
						 Short shortObject = new Short(((Short)frow.getLastCellNum()).toString());
						
						int lastCellNumberInExcel=shortObject.intValue();
						
						int lastCellInLoop=lastCellNumberInExcel;
						
						int maxColsInSheet= Integer.parseInt(dbMaxCols);
						
						int startingColumn=0;
						
						//System.out.println("max cols in one sheet:"+maxColsInSheet);
						
						//System.out.println("column in the excel is: "+lastCellNumberInExcel);
						
						List<String> ccnListLimit= null;
						
						List<String> originalListGet=null;
						
						List<String> cnnListGet=null;
						
						int countDbSuffixNo=0;
						
						/*DB Suffix functionality*/
						if(maxColsInSheet<lastCellNumberInExcel)
						{
							//int countDbSuffixNo=0;
							
							int methodCount= 0;
							
							while(lastCellNumberInExcel>=maxColsInSheet)
							{
							 cnnListGet = new ArrayList<>();
								
								if(countDbSuffixNo==0)
								{
									String dbTableName= sheet.getSheetName();
									
									/*create dynamic tables with cnxml array from  xml/hrow ..*/
									try {
										StringBuilder sql = new StringBuilder();
										sql.append("CREATE TABLE sample."+ sessionUser+"_"+dbTableName.replaceAll("[^\\w]", "")+"(\n");
										sql.append(" `SerialNumber` integer NOT NULL AUTO_INCREMENT,");
										

										
									
									cnnListGet=getUpdatedList(ccnList, maxColsInSheet, countDbSuffixNo);
									
									//System.out.println(cnnListGet);
										
									ccnListLimit= new ArrayList<>(ccnList);
									
									originalListGet=getRemovedList(ccnListLimit, cnnListGet);
									
									//System.out.println(originalListGet);
									
										for (String hclmns : cnnListGet) // or sArray
										{
											sql.append(hclmns).append(" ").append("TEXT NOT NULL,");
											//sql.append(hclmns).append(" ").append("VARCHAR(250) NOT NULL,");
										}

										sql.append("PRIMARY KEY (SerialNumber)");
										String withoutLastComma = sql.substring( 0, sql.length( )-1);
										String sqlcreate = withoutLastComma + "));";
										//String sc = sqlcreate.concat("ROW_FORMAT=DYNAMIC;");
										pstm = (PreparedStatement) con.prepareStatement(sqlcreate.toString());
										pstm.execute();
										//con.close();
										//System.out.println("table created successfully");
										logger.info("table created successfully");
									} 
									catch (Exception e1) {
										//System.out.println("Error in table creation:"+e1.getMessage());
										logger.error("Error in table creation:"+e1.getMessage());
										break;
									}
									
									/*Read data records*/
									for (int rowNumber = 1;rowNumber <= sheet.getLastRowNum(); rowNumber++)
									{
										Row drow = sheet.getRow(rowNumber);
										
										List<String> dynamiclist = new ArrayList<>();
										
										Map<String, List<String>> map = new HashMap<String, List<String>>();
										if (drow == null)
										{
											// This row is completely empty
										}
										else
										{
											// The row has data
											int countColumn=1;
											for(int cellNumber = startingColumn;cellNumber < lastCellInLoop; cellNumber++)
											{
											
												if(countColumn<=maxColsInSheet)
												{
													Cell dcell = drow.getCell(cellNumber);
													if (dcell == null || dcell.getCellType() == Cell.CELL_TYPE_BLANK) {
														// This cell is empty
														dynamiclist.add("");
													}else {
														// This cell has data in it
														dcell.setCellType(Cell.CELL_TYPE_STRING);
														dynamiclist.add(dcell.getStringCellValue().replace("'", ""));
													}
													
													countColumn=countColumn+1;
												}
												
												else
												{
													
													
													break;
												}
											}
											
											map.put(key,dynamiclist);
											//print to check row data
											for(String k : map.keySet()){
												//System.out.println("Key = " + k + " Values = " + map.get(k).toString());

												logger.debug("Key = " + k + " Values = " + map.get(k).toString());
											}	
											
											
										}
										
										
										try {
											StringBuilder sqlinsert = new StringBuilder();
											StringBuilder in_sql = new StringBuilder();
											sqlinsert.append("INSERT INTO sample."+ sessionUser+"_"+dbTableName.replaceAll("[^\\w]", "")+" (");					
											for (String hclmns : cnnListGet) // or sArray
											{
												sqlinsert.append(hclmns).append(",");
											}
											String rcomma = sqlinsert.substring(0, sqlinsert.length( )-1);
											String insert_sql = rcomma + ")" +" "+"VALUES(";
											in_sql.append(insert_sql);
											for(String k : map.keySet()){
												for(String v :map.get(k)){
													in_sql.append("'").append(v).append("'").append(",");
												}
											}
											String removecomma = in_sql.substring(0, in_sql.length()-1);
											//String sqlinserts = removecomma.concat(");");
											String sqlinserts = removecomma.replace("+", "\\+").concat(");");
											//System.out.println("final insert query:"+sqlinserts);
											logger.debug("final insert query:"+sqlinserts);
											pstm = (PreparedStatement) con.prepareStatement(sqlinserts);
											pstm.execute();
											//con.close();
											//System.out.println("Records inserted");
											//	logger.info("Records inserted");
											logger.info("Records inserted");
										} catch (Exception e) {
											//System.out.println("Error in insertinig Records:"+e.getMessage());
											logger.error("Error in insertinig Records:"+e.getMessage());
										}
										
										
										
										
									}
									
																	
									
									
								}
								else
								{
									String countDBSuffix=countDbSuffixNo+"";
									String dbTableName= sheet.getSheetName()+dbSuffix+countDBSuffix;
									
									/*create dynamic tables with cnxml array from  xml/hrow ..*/
									try {
										StringBuilder sql = new StringBuilder();
										sql.append("CREATE TABLE sample."+ sessionUser+"_"+dbTableName.replaceAll("[^\\w]", "")+"(\n");
										sql.append(" `SerialNumber` integer NOT NULL AUTO_INCREMENT,");
										
										cnnListGet=getUpdatedList(originalListGet, maxColsInSheet, countDbSuffixNo);
										
										originalListGet=getRemovedList(originalListGet, cnnListGet);
								
										for (String hclmns : cnnListGet) // or sArray
										{
											sql.append(hclmns).append(" ").append("TEXT NOT NULL,");
											
											//sql.append(hclmns).append(" ").append("VARCHAR(250) NOT NULL,");
										}

										sql.append("PRIMARY KEY (SerialNumber)");
										String withoutLastComma = sql.substring( 0, sql.length( )-1);
									String sqlcreate = withoutLastComma + "));";
										
										//String sc = sqlcreate.concat("ROW_FORMAT=DYNAMIC;");
										pstm = (PreparedStatement) con.prepareStatement(sqlcreate.toString());
										pstm.execute();
										//con.close();
										//System.out.println("table created successfully");
										logger.info("table created successfully");
									} 
									catch (Exception e1) {
										//System.out.println("Error in table creation:"+e1.getMessage());
										logger.error("Error in table creation:"+e1.getMessage());
										break;
									}
									
									/*Read data records*/
									for (int rowNumber = 1;rowNumber <= sheet.getLastRowNum(); rowNumber++)
									{
										Row drow = sheet.getRow(rowNumber);
										
										List<String> dynamiclist = new ArrayList<>();
										
										Map<String, List<String>> map = new HashMap<String, List<String>>();
										if (drow == null)
										{
											// This row is completely empty
										}
										else
										{
											// The row has data
											int countColumn=1;
											for(int cellNumber = startingColumn;cellNumber < lastCellInLoop; cellNumber++)
											{
											
												if(countColumn<=maxColsInSheet)
												{
													Cell dcell = drow.getCell(cellNumber);
													if (dcell == null || dcell.getCellType() == Cell.CELL_TYPE_BLANK) {
														// This cell is empty
														dynamiclist.add("");
													}else {
														// This cell has data in it
														dcell.setCellType(Cell.CELL_TYPE_STRING);
														dynamiclist.add(dcell.getStringCellValue().replace("'", ""));
													}
													
													countColumn=countColumn+1;
												}
												
												else
												{
													
													
													break;
												}
											}
											
											map.put(key,dynamiclist);
											//print to check row data
											for(String k : map.keySet()){
												//System.out.println("Key = " + k + " Values = " + map.get(k).toString());

												logger.debug("Key = " + k + " Values = " + map.get(k).toString());
											}	
										}
										
										
										try {
											StringBuilder sqlinsert = new StringBuilder();
											StringBuilder in_sql = new StringBuilder();
											sqlinsert.append("INSERT INTO sample."+ sessionUser+"_"+dbTableName.replaceAll("[^\\w]", "")+" (");					
											for (String hclmns : cnnListGet) // or sArray
											{
												sqlinsert.append(hclmns).append(",");
											}
											String rcomma = sqlinsert.substring(0, sqlinsert.length( )-1);
											String insert_sql = rcomma + ")" +" "+"VALUES(";
											in_sql.append(insert_sql);
											for(String k : map.keySet()){
												for(String v :map.get(k)){
													in_sql.append("'").append(v).append("'").append(",");
												}
											}
											String removecomma = in_sql.substring(0, in_sql.length()-1);
											//String sqlinserts = removecomma.concat(");");
											String sqlinserts = removecomma.replace("+", "\\+").concat(");");
											//System.out.println("final insert query:"+sqlinserts);
											logger.debug("final insert query:"+sqlinserts);
											pstm = (PreparedStatement) con.prepareStatement(sqlinserts);
											pstm.execute();
											//con.close();
											//System.out.println("Records inserted");
											//	logger.info("Records inserted");
											logger.info("Records inserted");
										} catch (Exception e) {
											//System.out.println("Error in insertinig Records:"+e.getMessage());
											logger.error("Error in insertinig Records:"+e.getMessage());
										}
									}
									
								}
								
								lastCellNumberInExcel=lastCellNumberInExcel-maxColsInSheet;
								
								startingColumn=startingColumn+maxColsInSheet;
								
								countDbSuffixNo=countDbSuffixNo+1;
				
							}
							
							
							if(lastCellNumberInExcel<maxColsInSheet)
							{
								String countDBSuffix=countDbSuffixNo+"";
								String dbTableName= sheet.getSheetName()+dbSuffix+countDBSuffix;
								
								cnnListGet=new ArrayList<>();
								
								/*create dynamic tables with cnxml array from  xml/hrow ..*/
								try {
									StringBuilder sql = new StringBuilder();
									sql.append("CREATE TABLE sample."+ sessionUser+"_"+dbTableName.replaceAll("[^\\w]", "")+"(\n");
									sql.append(" `SerialNumber` integer NOT NULL AUTO_INCREMENT,");
									
									cnnListGet=getUpdatedList(originalListGet, maxColsInSheet, countDbSuffixNo);
									
									originalListGet=getRemovedList(originalListGet, cnnListGet);
									

									for (String hclmns : cnnListGet) // or sArray
									{
										sql.append(hclmns).append(" ").append("TEXT NOT NULL,");
										
										//sql.append(hclmns).append(" ").append("VARCHAR(250) NOT NULL,");
									}

									sql.append("PRIMARY KEY (SerialNumber)");
									String withoutLastComma = sql.substring( 0, sql.length( )-1);
									String sqlcreate = withoutLastComma + "));";
									
									//String sc = sqlcreate.concat("ROW_FORMAT=DYNAMIC;");
									pstm = (PreparedStatement) con.prepareStatement(sqlcreate.toString());
									pstm.execute();
									//con.close();
									//System.out.println("table created successfully");
									logger.info("table created successfully");
								} 
								catch (Exception e1) {
									//System.out.println("Error in table creation:"+e1.getMessage());
									logger.error("Error in table creation:"+e1.getMessage());
									break;
								}
								
								/*Read data records*/
								for (int rowNumber = 1;rowNumber <= sheet.getLastRowNum(); rowNumber++)
								{
									Row drow = sheet.getRow(rowNumber);
									
									List<String> dynamiclist = new ArrayList<>();
									
									Map<String, List<String>> map = new HashMap<String, List<String>>();
									if (drow == null)
									{
										// This row is completely empty
									}
									else
									{
										for(int cellNumber = startingColumn;cellNumber < lastCellInLoop; cellNumber++)
										{
											Cell dcell = drow.getCell(cellNumber);
											if (dcell == null || dcell.getCellType() == Cell.CELL_TYPE_BLANK) {
												// This cell is empty
												dynamiclist.add("");
											}else {
												// This cell has data in it
												dcell.setCellType(Cell.CELL_TYPE_STRING);
												dynamiclist.add(dcell.getStringCellValue().replace("'", ""));
											}
										}
										
										map.put(key,dynamiclist);
										//print to check row data
										for(String k : map.keySet()){
											//System.out.println("Key = " + k + " Values = " + map.get(k).toString());

											logger.debug("Key = " + k + " Values = " + map.get(k).toString());
										}	
									}
									
									try {
										StringBuilder sqlinsert = new StringBuilder();
										StringBuilder in_sql = new StringBuilder();
										sqlinsert.append("INSERT INTO sample."+ sessionUser+"_"+dbTableName.replaceAll("[^\\w]", "")+" (");					
										for (String hclmns : cnnListGet) // or sArray
										{
											sqlinsert.append(hclmns).append(",");
										}
										String rcomma = sqlinsert.substring(0, sqlinsert.length( )-1);
										String insert_sql = rcomma + ")" +" "+"VALUES(";
										in_sql.append(insert_sql);
										for(String k : map.keySet()){
											for(String v :map.get(k)){
												in_sql.append("'").append(v).append("'").append(",");
											}
										}
										String removecomma = in_sql.substring(0, in_sql.length()-1);
										//String sqlinserts = removecomma.concat(");");
										String sqlinserts = removecomma.replace("+", "\\+").concat(");");
										//System.out.println("final insert query:"+sqlinserts);
										logger.debug("final insert query:"+sqlinserts);
										pstm = (PreparedStatement) con.prepareStatement(sqlinserts);
										pstm.execute();
										//con.close();
										//System.out.println("Records inserted");
										//	logger.info("Records inserted");
										logger.info("Records inserted");
									} catch (Exception e) {
										//System.out.println("Error in insertinig Records:"+e.getMessage());
										logger.error("Error in insertinig Records:"+e.getMessage());
									}
								}
								
							}
							
						}
						else
						{
							
							
							/*create dynamic tables with cnxml array from  xml/hrow ..*/
							try {
								StringBuilder sql = new StringBuilder();
								sql.append("CREATE TABLE sample."+ sessionUser+"_"+sheet.getSheetName().replaceAll("[^\\w]", "")+"(\n");
								sql.append(" `SerialNumber` integer NOT NULL AUTO_INCREMENT,");

								for (String hclmns : ccnList) // or sArray
								{
									sql.append(hclmns).append(" ").append("TEXT NOT NULL,");
									
									//sql.append(hclmns).append(" ").append("VARCHAR(250) NOT NULL,");
								}

								sql.append("PRIMARY KEY (SerialNumber)");
								String withoutLastComma = sql.substring( 0, sql.length( )-1);
								String sqlcreate = withoutLastComma + "));";
								pstm = (PreparedStatement) con.prepareStatement(sqlcreate.toString());
								pstm.execute();
								//con.close();
								//System.out.println("table created successfully");
								logger.info("table created successfully");
							} catch (Exception e1) {
								//System.out.println("Error in table creation:"+e1.getMessage());
								logger.error("Error in table creation:"+e1.getMessage());
								break;
							}
							
							
							for (int rowNumber = 1;rowNumber <= sheet.getLastRowNum(); rowNumber++) {
								Row drow = sheet.getRow(rowNumber);
								List<String> dynamiclist = new ArrayList<>();
								Map<String, List<String>> map = new HashMap<String, List<String>>();
								if (drow == null) {
									// This row is completely empty
								} else {
									// The row has data
									short firstvar = 0;
									short secvar = (short) (frow.getLastCellNum()-1);

									for (int cellNumber = firstvar;cellNumber <= secvar; cellNumber++) {
										Cell dcell = drow.getCell(cellNumber);
										if (dcell == null || dcell.getCellType() == Cell.CELL_TYPE_BLANK) {
											// This cell is empty
											dynamiclist.add("");
										}else {
											// This cell has data in it
											dcell.setCellType(Cell.CELL_TYPE_STRING);
											dynamiclist.add(dcell.getStringCellValue().replace("'", ""));
										}
									}
									map.put(key,dynamiclist);
									//print to check row data
									for(String k : map.keySet()){
										//System.out.println("Key = " + k + " Values = " + map.get(k).toString());

										logger.debug("Key = " + k + " Values = " + map.get(k).toString());
									}				

								}

								try {
									StringBuilder sqlinsert = new StringBuilder();
									StringBuilder in_sql = new StringBuilder();
									sqlinsert.append("INSERT INTO sample."+ sessionUser+"_"+sheet.getSheetName().replaceAll("[^\\w]", "")+" (");					
									for (String hclmns : ccnList) // or sArray
									{
										sqlinsert.append(hclmns).append(",");
									}
									String rcomma = sqlinsert.substring(0, sqlinsert.length( )-1);
									String insert_sql = rcomma + ")" +" "+"VALUES(";
									in_sql.append(insert_sql);
									for(String k : map.keySet()){
										for(String v :map.get(k)){
											in_sql.append("'").append(v).append("'").append(",");
										}
									}
									String removecomma = in_sql.substring(0, in_sql.length()-1);
									//String sqlinserts = removecomma.concat(");");
									String sqlinserts = removecomma.replace("+", "\\+").concat(");");
									//System.out.println("final insert query:"+sqlinserts);
									logger.debug("final insert query:"+sqlinserts);
									pstm = (PreparedStatement) con.prepareStatement(sqlinserts);
									pstm.execute();
									//con.close();
									//System.out.println("Records inserted");
									//	logger.info("Records inserted");
									logger.info("Records inserted");
								} catch (Exception e) {
									//System.out.println("Error in insertinig Records:"+e.getMessage());
									logger.error("Error in insertinig Records:"+e.getMessage());
								}
							}
						}
						
						
						//prepare data for sheetname table
						Map<String, List<String>> snMap = new HashMap<String, List<String>>();
						for(int i=0; i <= countDbSuffixNo;i++)
						{
						if(i==0)
						{
						ArrayList<String> snList = new ArrayList<String>();
						snList.add(sheet.getSheetName().replaceAll("[^\\w]", ""));
						snList.add("1");
						snList.add(sessionUser+"_"+sheet.getSheetName().replaceAll("[^\\w]", "").toLowerCase());
						snMap.put(sheet.getSheetName().replaceAll("[^a-zA-Z0-9]", ""), snList);
						}
						else
						{
							ArrayList<String> snList = new ArrayList<String>();
							String sheetNameField = sheet.getSheetName().replaceAll("[^\\w]", "")+dbSuffix+i+"";
							String sheetNameTablesField = (sessionUser+"_"+sheet.getSheetName().replaceAll("[^\\w]", "")+dbSuffix+i+"").toLowerCase();
							snList.add(sheetNameField);
							snList.add("1");
							snList.add(sheetNameTablesField);
							snMap.put(sheetNameField, snList);
							
						}

						}

						//finally insert sheet names values to sheetnames table
						try {
							
							//sqlinsert.append("'").append(sheetnms).append("'");	
							for(String snkey : snMap.keySet())
							{
								
								StringBuilder sqlinsert = new StringBuilder();
								sqlinsert.append("INSERT INTO sample."+sessionUser+"_sheetnames(sheetname,startingrow,sheetnametables) VALUES(");
								
								for(String v :snMap.get(snkey))
								{
									sqlinsert.append("'").append(v).append("'").append(",");
								}
								
								String removecomma = sqlinsert.substring(0, sqlinsert.length()-1);
								String iSN_sql = removecomma + ")";
								//	System.out.println("final insert query:"+iSN_sql);
								pstm = (PreparedStatement) con.prepareStatement(iSN_sql.toString());
								pstm.execute();
								
							}
							
							//System.out.println("sheetnames Records inserted");
						} catch (Exception e) {
							// TODO Auto-generated catch block
							//System.err.println("Error in  inserting:"+e.getMessage());
							logger.error(e.getMessage());
						}
						
						
						if(subVal.size() !=0 )
						{
							colNamesMapGet=genColMap(orginalColNames, ccnList);
							String substr = subVal.toString().replace("[", "").replace("]", "").replace(", ", ",");
							
							String message1 ="The following columns names has been automatically renamed by the tool:<br/>"+substr+" <br/> ";
							
							message = message1 ;
							
							msgMap.put("0", message);
							
							msgMap.put("1", sheetName);
							
							msgMapList.add(msgMap);
							
							msgMapList.add(colNamesMapGet);
						}
						else if(subVal.size() ==0)
						{
							colNamesMapGet=genColMap(orginalColNames, ccnList);
							
							msgMap.put("0", "");
							
							msgMap.put("1", sheetName);
							
							msgMapList.add(msgMap);
							
							msgMapList.add(colNamesMapGet);
						}
					

					}  
					else{
						//System.err.println("The column names "+dupList+" are duplicates please check mapping xml \n");
						if(dupList.size()!=0)
						{
						colNamesMapGet=genColMap(orginalColNames, ccnList);
						String duplist = dupList.toString().replace("[", "").replace("]", "").replace(", ", ",");
						message ="The column names "+duplist+" are duplicates please check the excel";
						
						msgMap.put("0", message);
						
						msgMap.put("1", sheetName);
						
						msgMapList.add(msgMap);
						
						msgMapList.add(colNamesMapGet);
						}
						
					}
					
					
					
					
				}
			}
			
			pstm.close();
			con.close();


		} 
		catch (Exception e) 
		{
			//System.out.println(""+e.getMessage());
			logger.error("error in reading excel sheet: "+e.getMessage());
		}
		
		finally {
		    if (pstm!= null) {
		        try {
		        	pstm.close();
		        	//System.out.println("closing pstm connections");
		        	logger.info("closing pstm connections");
		        } catch (SQLException e) { }
		    }
		    if (con != null) {
		        try {
		            con.close();
		            //System.out.println("closing all opened connections");
		            logger.info("closing all opened connections");
		        } catch (SQLException e) { }
		    }
		}
		
		return msgMapList;


	}
	
	public Map<String, String> genColMap(List<String> orginalCols , List<String> DbCols)
	{
		Map<String, String> colNamesMap = new LinkedHashMap<>();
		
		
		for(int b=0;b<orginalCols.size();b++)
		{
			for(int a=b;b==a;a++)
			{
				colNamesMap.put(orginalCols.get(b),DbCols.get(b));
				
				
			}
		}
		
		
		
		return colNamesMap;
	}
	
	public List<String> getUpdatedList(List<String> cnnList, int maxSheetCols,int countDbSuffixNo)
	{
		List<String> ccnListGet= new ArrayList<>();
		
		
		
		
		
		int colsCount=0;
		for(String cols: cnnList)
		{
			if(colsCount<maxSheetCols)
			{
				ccnListGet.add(cols);
				colsCount=colsCount+1;
			}
			else
			{
				break;
			}
		}
		
		
		
		
		return ccnListGet;
		
	}
	
	public List<String> getRemovedList(List<String> originalList , List<String> modifiedList)
	{
		originalList.removeAll(modifiedList);
		
		return originalList;
	}
	
	


}
