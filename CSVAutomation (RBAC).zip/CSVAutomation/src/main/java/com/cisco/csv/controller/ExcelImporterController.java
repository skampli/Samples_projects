package com.cisco.csv.controller;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.InetAddress;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.Set;

import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.cisco.csv.services.GenAutoMappingTables;
import com.cisco.csv.services.GenDynamicTables;
import com.cisco.csv.services.GenerateTables;
import com.cisco.csv.writer.MappingXmlWriter;
import com.cisco.csv.writer.TarWriter;
import com.cisco.model.UploadedFile;
import com.sun.net.httpserver.HttpsConfigurator;
@Controller

public class ExcelImporterController {
	
	private final static Logger logger = Logger.getLogger(ExcelImporterController.class);

	/*@RequestMapping(method = RequestMethod.POST)
	public String upload(FileBean uploadItem, BindingResult result){
		ExcelImport excel = new ExcelImport();
		excel.importExcel(uploadItem);
		//return "imported successfully";
		 return "redirect:/success";
	}*/
	
	@Autowired
	MappingXmlWriter mappingXmlWriter;
	
	
	
	@RequestMapping("/upload")
	public ModelAndView getUploadForm(@ModelAttribute("uploadedFile") UploadedFile uploadedFile,BindingResult result)
	{
		return new ModelAndView("upload");
	}
	
	
	
	@RequestMapping( value="/success" ,method=RequestMethod.POST)
	public String fileUpload(@ModelAttribute("uploadedFile") UploadedFile uploadedFile, BindingResult result,final RedirectAttributes redirectAttributes,HttpServletResponse response) 		  
	{
		InputStream inputStream = null;
		OutputStream outputStream = null;
		
		String message1="";
		//System.out.println("uploaded file content"+uploadedFile.getFile().getBytes().toString());
		
		/*Properties props=new Properties();
		String propsName="/config.properties";
		InputStream inputStr = this.getClass().getResourceAsStream(propsName);
		props.load(inputStr);
		//logger.info("uploaded file content"+uploadedFile.getFile().getBytes().toString());
		logger.debug("uploaded file content"+uploadedFile.getFile().getBytes().toString());

		MultipartFile file = uploadedFile.getFile();
		String fileName = file.getOriginalFilename();
		Authentication auth = SecurityContextHolder.getContext().getAuthentication();
		String sessionUser = auth.getName(); //get logged in username
*/		
		//String fileNameUser=sessionUser+"_"+fileName;
		String absolutePath="";
		
		String absoluteXmlPath="";
		
		String xmlConfig="xml-configs";
		try
		{	
			Properties props=new Properties();
			String propsName="/config.properties";
			InputStream inputStr = this.getClass().getResourceAsStream(propsName);
			props.load(inputStr);
			//logger.info("uploaded file content"+uploadedFile.getFile().getBytes().toString());
			logger.debug("uploaded file content"+uploadedFile.getFile().getBytes().toString());

			MultipartFile file = uploadedFile.getFile();
			String fileName = file.getOriginalFilename();
			
			int indexOfDot = fileName.indexOf(".");
			
			String fileNameTrim =fileName.substring(0, indexOfDot); 
			
			Authentication auth = SecurityContextHolder.getContext().getAuthentication();
			String sessionUser = auth.getName(); //get logged in username

			String fileNameUser=sessionUser+"_"+fileName;
			
			String xmlFileName=sessionUser+"_"+fileNameTrim+".xml";


			InetAddress ip;
			String hostname;
			ip = InetAddress.getLocalHost();
			hostname = ip.getHostName();
			 
			if(hostname.equalsIgnoreCase("SKAMPLI-80MHF"))
			{
				Set<Object> configKeys=props.keySet();

				for(Object obj:configKeys)
				{
					String configKey=(String)obj;

					if(configKey.equalsIgnoreCase("filePath_local"))
					{

						String pathName=props.getProperty(configKey);

						absolutePath=pathName+fileNameUser;
						absoluteXmlPath=pathName+"xml-configs/"+xmlFileName;


					}

				}
			}
			else
			{
				absolutePath=props.getProperty("filePath_server")+fileNameUser;
				
				absoluteXmlPath=props.getProperty("filePath_server")+xmlConfig+"/"+xmlFileName;
			}

			System.out.println("Absolutepath value**************"+absolutePath);
			inputStream=file.getInputStream();

			//File newFile=new File("/tmp/"+fileNameUser);  
			//File newFile=new File("C:\\Users\\djhalani\\file\\"+fileNameUser);
			File newFile=new File(absolutePath);
			if (!newFile.exists()) {
				newFile.createNewFile();
			}
			else
			{
				if(newFile.delete())
				{
					newFile.createNewFile();
				}
				else
				{
					//logger.info("the file with the name "+fileNameUser+" was not deleted");
					logger.debug("the file with the name "+fileNameUser+" was not deleted");
					//System.out.println("the file with the name "+fileNameUser+" was not deleted");
				}
			}


			outputStream = new FileOutputStream(newFile);
			int read = 0;
			byte[] bytes = new byte[1024];
			while ((read = inputStream.read(bytes)) != -1)
			{
				outputStream.write(bytes, 0, read);
			}
			//System.out.println("uploaded filepath"+newFile.getPath());
			//logger.info("uploaded filepath"+newFile.getPath());
			logger.debug("uploaded filepath"+newFile.getPath());
			/*	ExcelImport excel = new ExcelImport();
			excel.importExcel(uploadedFile);*/

			
			String usexml = uploadedFile.getUsexml();		
			
			String autoMapping= uploadedFile.getAutoMapping();
			
			if(usexml != null)
			{
				GenDynamicTables gdt = new GenDynamicTables();
				//gdt.excuteMethod(fileNameUser);
				String message  =gdt.excuteMethod(fileNameUser);
				if(message != null)
				{	
					if(message.contains("The following columns") || message.contains("Mismatched ColumnNames")){
						redirectAttributes.addFlashAttribute("messageDisplayed",message);
						return "redirect:/success";
					}else if(message == null || message.equals("")){
						return "redirect:/success";
					}else if(message.contains("The column names")){
						redirectAttributes.addFlashAttribute("messageDisplayed",message);
						return "redirect:/upload";
					}
				}				
			}
			else
			{
				
				
				if(autoMapping!=null)
				{
					GenAutoMappingTables genAutoMap = new GenAutoMappingTables();
					//String message = genAutoMap.excuteMethod(fileNameUser);
					
					List<Map<String, String>> msgMapGet = genAutoMap.excuteMethod(fileNameUser);
					
					Map<String, String> msgGet=msgMapGet.get(0);
					
					String message=msgGet.get("0");
					
					String excelSheetName= msgGet.get("1");
					
					//System.out.println("message from genAuto:"+message);
					
					Map<String, String>  mapGet = msgMapGet.get(1);
					
					//System.out.println("map from genAuto:"+mapGet);
					
					
					
					if(message != null && !(mapGet.isEmpty()))
					{	
						if(message.contains("The following columns") )
						{
							
							mappingXmlWriter.createXml(mapGet, absoluteXmlPath, excelSheetName);
							
							redirectAttributes.addFlashAttribute("messageDisplayed",message);
							return "redirect:/success";
						}
						else if((message == null || message.equals("")) && !(mapGet.isEmpty()) )
						{
							mappingXmlWriter.createXml(mapGet, absoluteXmlPath, excelSheetName);
							
							return "redirect:/success";
						}
						else if(message.contains("The column names") || message.contains("Please upload the file"))
						{
							redirectAttributes.addFlashAttribute("messageDisplayed",message);
							return "redirect:/upload";
						}
					}
					
					
					
					
				}
				else
				{
					GenerateTables gentable = new GenerateTables();
					outputStream.close();
					String message  =gentable.excuteMethod(fileNameUser);	
					if(!(message==""))
					{
						redirectAttributes.addFlashAttribute("messageDisplayed",message);
						return "redirect:/upload";
					}
				}
				
				
				
				
				
			/*	GenerateTables gentable = new GenerateTables();
				outputStream.close();
				String message  =gentable.excuteMethod(fileNameUser);	
				if(!(message==""))
				{
					redirectAttributes.addFlashAttribute("messageDisplayed",message);
					return "redirect:/upload";
				}*/
			}
			

		}
		catch (Exception e) {
			// TODO Auto-generated catch block
			
			logger.error(e.getMessage());
			//e.printStackTrace();
		}
		return "redirect:/success";

	}
	
	


}
