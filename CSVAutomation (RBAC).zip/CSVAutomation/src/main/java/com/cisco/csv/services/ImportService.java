package com.cisco.csv.services;


import com.cisco.model.UploadedFile;

public interface ImportService {
	 public String importExcel(UploadedFile uploadFile);
}
