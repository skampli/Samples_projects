package com.cisco.csv.controller;

import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.mysql.jdbc.Connection;
import com.mysql.jdbc.ResultSetMetaData;
import com.mysql.jdbc.Statement;

public class ModifyRecordController {

	private final static Logger logger = Logger.getLogger(ModifyRecordController.class);
	
	Authentication auth = SecurityContextHolder.getContext().getAuthentication();
	String sessionUser = auth.getName(); 
	
	@RequestMapping(value="/deleteRecord" , method=RequestMethod.GET)
	public String deleteRecord(@PathVariable("deleteid")String deleteid,@RequestParam("deltble") String deltble) 
	{
		String recordId = deleteid;
		if(StringUtils.isBlank(recordId)){
			return "redirect:/fetchRecords";
		}else{
			try {
				Class.forName("com.mysql.jdbc.Driver");
				Connection con = (Connection) DriverManager.getConnection("jdbc:mysql://localhost:3306/sample","root","cisco123");
				con.setAutoCommit(true);
				PreparedStatement pstm = null;             
				String dquery = "delete from sample." +deltble +" where SerialNumber="+recordId +";";
				pstm = (PreparedStatement) con.prepareStatement(dquery.toString());
				pstm.execute();
				
				logger.debug("deleting record "+recordId);
				pstm.close();
				con.close();
			} catch (ClassNotFoundException e) {
				logger.error(e.getMessage());
				
			} catch (SQLException e) {
				logger.error(e.getMessage());
			}
			
			logger.debug("deleting record ");
			return "redirect:/fetchRecords";
		}
	}	


	@RequestMapping(value="/updateRecord" , method=RequestMethod.GET)
	public String updateRecord(@PathVariable("updateId")String updateId,@PathVariable("deltble")String deltble,@PathVariable List<String> input_values) 
	{
		String recordId = updateId;
		if(StringUtils.isBlank(recordId)){
			return "redirect:/fetchRecords";
		}else{
			try {

				Class.forName("com.mysql.jdbc.Driver");
				Connection con = (Connection) DriverManager.getConnection("jdbc:mysql://localhost:3306/sample","root","cisco123");
				con.setAutoCommit(true);
				PreparedStatement pstm = null;             
				
				
				Statement st = (Statement) con.createStatement();
				String query = "select * from sample."+deltble+" where SerialNumber="+recordId;
				ResultSet rs = st.executeQuery(query);
				ResultSetMetaData metaData = (ResultSetMetaData) rs.getMetaData();

				int columnCount = metaData.getColumnCount();

				List<String> tableColNames = new ArrayList<String>();

				for (int i = 1; i <= columnCount; i++) {
					String columnName = metaData.getColumnName(i);
					tableColNames.add(columnName);
				}

				Map<String,String> map = new LinkedHashMap<String,String>();  

				for (int i=0; i<tableColNames.size(); i++) {
					map.put(tableColNames.get(i), input_values.get(i)); 
				}

				//forming update query
				StringBuilder sql = new StringBuilder();
				sql.append("update sample."+deltble+ " set ");
				for(String k : map.keySet()){
					//System.out.println("Key = " + k + " Values = " + map.get(k).toString());
					sql.append(k).append("='").append( map.get(k).toString()).append("',");
				}

				String withoutLastComma = sql.substring( 0, sql.length( )-1);
				String sqlinserts = withoutLastComma.concat(" where SerialNumber=").concat(recordId).concat(";");
				String sql_c1 = sqlinserts.replace("[", "");
				String update_sql = sql_c1.replace("]", "");
				
				//System.out.println("final_update_qyery::"+update_sql);
				
				//logger.info("final_update_qyery::"+update_sql);
				logger.debug("final_update_qyery::"+update_sql);
				
				pstm = (PreparedStatement) con.prepareStatement(update_sql.toString());
				pstm.execute();
				
				pstm.close();
				con.close();
			} catch (ClassNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			return "sucessfully updated";
		}
	}
	
	
	
}
