package com.cisco.csv.writer;

import java.util.LinkedHashSet;
import java.util.Map;
import java.util.Set;

import javax.servlet.ServletOutputStream;

import java.io.File;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
 




import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.w3c.dom.Text;

public class MappingXmlWriter {
	
	
	
	public void createXml(Map<String, String> colNamesMapGet, String fileName, String excelSheetName)
	{
		 DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
		 
		  DocumentBuilder dBuilder;
		  
		  Set<String> columnMapKeys= new LinkedHashSet<>();
		  
		  columnMapKeys=colNamesMapGet.keySet();
		  
		 
		  
		  try
		  {
			 
			  
			  dBuilder = dbFactory.newDocumentBuilder();
			  
	          Document doc = dBuilder.newDocument();
	           
	           //Element rootElement= doc.createElementNS("", "Configs");
	          Element rootElement=doc.createElement("Configs");
	           
	           doc.appendChild(rootElement);
	           
	          
	           
	           Element columnMapping = doc.createElement("ColumnMapping");
	          
	           rootElement.appendChild(columnMapping);
	           
	          rootElement.appendChild(getMasterSheets(doc,excelSheetName));
	           
	          
	        	   for(String key : columnMapKeys)
	        	   {
	        		   
	        		 //System.out.println("key is"+key);
	        		 //System.out.println("value is "+colNamesMapGet.get(key));
	        	   columnMapping.appendChild(getColumns(doc, key, colNamesMapGet.get(key)));
	        	   }
	           
	        	   checkDoc(doc);
	        	   
	           TransformerFactory transformerFactory = TransformerFactory.newInstance();
	           
	           Transformer transformer = transformerFactory.newTransformer();
	           
	          transformer.setOutputProperty(OutputKeys.INDENT, "yes");
	           
	           DOMSource source = new DOMSource(doc);
	           
	          StreamResult streamResultFile  = new StreamResult(new File(fileName).getAbsolutePath());
	           
	           //StreamResult console = new StreamResult(System.out);
	           
	           transformer.transform(source, streamResultFile);
	           
	           
	           
	           
		  }
		  catch(Exception e)
		  {
			  e.printStackTrace();
		  }
	}
	

	
	private static Node getMasterSheets(Document doc , String sheetName)
	{
		System.out.println("sheetName is:"+sheetName);
		Element masterSheets = doc.createElement("MasterSheets");
		
		masterSheets.appendChild(getMasterSheetsElements(doc, masterSheets, "SheetName", sheetName));
		return masterSheets;
	}
	
	private static Node getMasterSheetsElements(Document doc , Element element , String name , String value)
	{
		Element node = doc.createElement(name);
        node.appendChild(doc.createTextNode(value));
        return node;
	}
	
	private static Node getColumns(Document doc , String name , String value)
	{
		Element column = doc.createElement("Column");
		
		column.appendChild(getColumnElements(doc, column, "Name", name));
		
		column.appendChild(getColumnElements(doc, column, "Value", value));
		
		return column;
		
	}
	
	private static Node getColumnElements(Document doc, Element element, String name, String value)
	{
		Element node = doc.createElement(name);
        node.appendChild(doc.createTextNode(value));
        return node;
	}
	
	public static void checkDoc(Node n) {
		  if (n instanceof Text) {
		    if (((Text) n).getData() == null) {
		      System.err.println("null data!!!!");
		    }
		  }

		  NodeList l = n.getChildNodes();
		  for (int i = 0; i < l.getLength(); ++i) {
		    checkDoc(l.item(i));
		  }
		}

}
