package com.cisco.csv.services;

import java.io.File;
import java.io.InputStream;
import java.net.InetAddress;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.xpath.XPath;
import javax.xml.xpath.XPathConstants;
import javax.xml.xpath.XPathFactory;

import org.apache.log4j.Logger;
import org.hibernate.SessionFactory;
import org.springframework.security.authentication.AnonymousAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NamedNodeMap;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import com.cisco.model.CheckDuplicateAttribute;
import com.cisco.model.ColumnNotEmptyAttribute;
import com.cisco.model.ConflictColAttribute;
import com.cisco.model.ContainsValidator;
import com.cisco.model.DependentSheetAttribute;
import com.cisco.model.DuplicateAttribute;
import com.cisco.model.IsColSubStringAttribute;
import com.cisco.model.IsEmptyAttribute;
import com.cisco.model.IsNumberAttribute;
import com.cisco.model.LengthAttribute;
import com.cisco.model.NotContainValidator;
import com.cisco.model.NotEmptyAttribute;
import com.cisco.model.DependentColumnValidator;


public class UserDaoImpl implements UserDAO {

	private final static Logger logger = Logger.getLogger(UserDaoImpl.class);



	private SessionFactory sessionFactory=null;





	//private List<String> tableColNames=null;
	//	private List<String> tableNames=null;
	//private List<LengthAttribute> lengthAttributeObjList=new ArrayList<>();

	public UserDaoImpl()
	{

	}

	public UserDaoImpl(SessionFactory sessionFactory)
	{
		this.sessionFactory=sessionFactory;
	}




	public List<Map<String, String>> UserCsvGen(Document document, String fileName,Document documentCommon,String sessionUserGet)
	{


		String sessionUser=sessionUserGet;





		//String sessionUser = auth.getName(); //get logged in username




		//Properties propsObj=new Properties();





		//	int size=getUser(sessionUser);
		int j;
		String key="";
		String value="";
		String value1="";
		String colNamesUpper="";
		String valueLower="";
		String valueUpper1="";
		String valueActual="";



		List<Map<String, String>> masterMapUpdate=new ArrayList<Map<String,String>>();

		List<Map<String, String>> masterMap=new ArrayList<Map<String,String>>();
		List <Map<String, String>> masterMapSort=new ArrayList<Map<String,String>>();

		XPath xPath =  XPathFactory.newInstance().newXPath();
		List<String> xmlName=new ArrayList<>();

		List<String>tableNamesUse=new ArrayList<>();

		List<String> mandatoryFields=new ArrayList<>();

		Map<String, String> nameValuePair=new LinkedHashMap<>();

		Map<String,String> nameValuePairDup=new LinkedHashMap<>();

		List<LengthAttribute> lengthAttributeObjListGet=new ArrayList<>();

		List<DuplicateAttribute> dupAttributeObjListGet= new ArrayList<>();

		String expressionName="/Configs/ColumnMapping/Column/Name";

		String expressionTableNames="/Configs/MasterSheets/SheetName";

		String expressionValue="/Configs/ColumnMapping/Column/Value";

		String expressionMandatoryCol="/Configs/MandatoryColumns/ColumnName";

		String expressionIdentifierValue="/Configs/Identifier/Name";

		List<LengthAttribute> lengthAttributeObjList=new ArrayList<>();

		List<DuplicateAttribute> dupAttributeObjList=new ArrayList<>();

		List<DependentSheetAttribute> dependentSheetObjList=new ArrayList<>();

		List<DependentSheetAttribute> dependentSheetObjListGet=new ArrayList<>();

		List<ColumnNotEmptyAttribute>  colNotEmptyList= new ArrayList<>();

		List<ColumnNotEmptyAttribute>  colNotEmptyListGet= new ArrayList<>();

		List<ConflictColAttribute>  conflictColListGet= new ArrayList<>();

		List<ConflictColAttribute>  conflictColList= new ArrayList<>();

		List<IsColSubStringAttribute> isColSubstringList= new ArrayList<>();

		List<IsColSubStringAttribute> isColSubstringListGet= new ArrayList<>();

		Set<String> valueKeyMapGetList=new LinkedHashSet<>();

		List<String> valueKeyMapGetListYes=new ArrayList<>();

		List<String> valueKeyMapGetSkipDuplicateList= new ArrayList<>();

		List<String> alternativeValueMandatoryErrorList=new ArrayList<>();

		List<String> alternativeValueMandatoryErrorGet=new ArrayList<>();

		List<NotContainValidator> notContainValidatorList = new ArrayList<>();

		List<NotContainValidator> notContainValidatorListGet = new ArrayList<>();


		List<DependentColumnValidator> dependentColList = new ArrayList<>();

		List<DependentColumnValidator> dependentColListGet = new ArrayList<>();

		List<DuplicateAttribute> duplicateAttributeYesObjList= new ArrayList<>();

		List<ContainsValidator> containsValidatorList = new ArrayList<>();

		List<ContainsValidator> containsValidatorListGet = new ArrayList<>();

		List<NotEmptyAttribute> notEmptyAttributeList = new ArrayList<>();

		List<NotEmptyAttribute> notEmptyAttributeListGet = new ArrayList<>();


		List<IsEmptyAttribute> isEmptyAttributeList = new ArrayList<>();

		List<IsEmptyAttribute> isEmptyAttributeListGet = new ArrayList<>();


		List<IsNumberAttribute> isNumberObjList= new ArrayList<>();

		List<IsNumberAttribute> isNumberObjListGet= new ArrayList<>();

		List<CheckDuplicateAttribute> duplicateValuesList= new ArrayList<>();

		List<CheckDuplicateAttribute> duplicateValuesListGet= new ArrayList<>();

		List<CheckDuplicateAttribute> duplValListGet= new ArrayList<>();

		Set<String> allAttributes=new LinkedHashSet<>();

		String dbSuffix="";

		Connection con=null;
		Statement statement=null;

		String messageSaved="";
		try
		{
			/*DB Connection */
			Class.forName("com.mysql.jdbc.Driver");
			con = (Connection) DriverManager.getConnection("jdbc:mysql://localhost:3306/sample","root","cisco123");
			con.setAutoCommit(true);

			NodeList nodeListTableName=(NodeList)xPath.compile(expressionTableNames).evaluate(document, XPathConstants.NODESET);

			NodeList nodeListName=(NodeList)xPath.compile(expressionName).evaluate(document, XPathConstants.NODESET);

			NodeList nodeListValue=(NodeList)xPath.compile(expressionValue).evaluate(document, XPathConstants.NODESET);

			NodeList nodeListMandatoryColName=(NodeList)xPath.compile(expressionMandatoryCol).evaluate(document, XPathConstants.NODESET);

			NodeList nodeListIdentifierValue=(NodeList)xPath.compile(expressionIdentifierValue).evaluate(document, XPathConstants.NODESET);


			//messageSaved="The processing started in the background, please download the file from home page";

			logger.info("CSV generation process begin");



			/* Storing the keys in the list */
			for (int i = 0; i < nodeListName.getLength(); i++)
			{
				xmlName.add(nodeListName.item(i).getFirstChild().getNodeValue().toString().replaceAll("(\r\n|\n)", ""));

				logger.debug("xmlName list contains*************"+xmlName);

			}


			/*For storing the Names and value tag of xml into map:-nameValuePair */
			for(int k=0;k<nodeListName.getLength();k++)
			{
				if(!(nodeListValue.item(k).getFirstChild()==null))
				{
					nameValuePair.put(nodeListName.item(k).getFirstChild().getNodeValue().toString().replaceAll("(\r\n|\n)", ""), nodeListValue.item(k).getFirstChild().getNodeValue());


				}
				else
				{
					nameValuePair.put(nodeListName.item(k).getFirstChild().getNodeValue(),"");
				}
			}


			/*If the masterSheet tag is not present in the XML then do the If part otherwise the ELSE part*/




			if(nodeListTableName.getLength()==0)
			{
				String sql="SELECT sheetname FROM "+sessionUser+"_sheetnames;";     //changes are to be made
				try {
					//Class.forName("com.mysql.jdbc.Driver");
					//con = (Connection) DriverManager.getConnection("jdbc:mysql://localhost:3306/sample","root","cisco123");
					//con.setAutoCommit(true);

					statement = con.createStatement();

					ResultSet resultSet = statement.executeQuery(sql);

					while(resultSet.next())
					{

						tableNamesUse.add(resultSet.getString(1));
					}

					logger.debug("Taking the sheets names directly from the SheetNames table from DB**********"+tableNamesUse);
					//logger.info("Taking the sheets names directly from the SheetNames table from DB**********"+tableNamesUse);

					/*statement.close();
					con.close();*/
				}
				catch (Exception e) {
					//con.close();
					logger.error("mastersheet tag not present"+e.getMessage());
					//e.printStackTrace();
				}

				/*		finally 
				{
				    if (statement!= null) {
				        try {
				        	statement.close();
				        // System.out.println("closing Statement connections");

				         logger.debug("closing statement connections");

				        } catch (SQLException e) { }
				    }
				    if (con != null) {
				        try {
				            con.close();
				            //System.out.println("closing all opened connections");
				            logger.debug("closing all opened connections");
				        } catch (SQLException e) { }
				    }
				}*/

			}
			else
			{
				/* For getting the value of the mastersheet tag to get the table names*/
				for (int i = 0; i < nodeListTableName.getLength(); i++)
				{
					tableNamesUse.add(nodeListTableName.item(i).getFirstChild().getNodeValue());

				}
				logger.debug("Taking the sheets names directly from the SheetNames tag from the xml**********"+tableNamesUse);
				//logger.info("Taking the sheets names directly from the SheetNames tag from the xml**********"+tableNamesUse);

			}

			/*  For storing all the Attributes of the nodes in the set allAttributes*/
			for(int k=0;k<nodeListValue.getLength();k++)
			{
				Element e=(Element)nodeListValue.item(k);

				if(!(e.getAttributes()==null))
				{
					NamedNodeMap elementAttribute=e.getAttributes();

					if(!(elementAttribute.getLength()==0))
					{

						for(int r=0;r<elementAttribute.getLength();r++)
						{
							Node attr = elementAttribute.item(r);

							if(!(attr==null))
							{
								String attributeName=attr.getNodeName();

								allAttributes.add(attributeName);
							}
						}
					}
				}
			}


			for(int k=0;k<nodeListMandatoryColName.getLength();k++)
			{
				Element e=(Element)nodeListMandatoryColName.item(k);

				if(!(e.getAttributes()==null))
				{
					NamedNodeMap elementAttribute=e.getAttributes();

					if(!(elementAttribute.getLength()==0))
					{

						for(int r=0;r<elementAttribute.getLength();r++)
						{
							Node attr = elementAttribute.item(r);

							if(!(attr==null))
							{
								String attributeName=attr.getNodeName();

								allAttributes.add(attributeName);
							}
						}
					}
				}
			}



			/* For getting the value of the mandatory tag to get the mandatory cols name  */
			for(int i=0;i<nodeListMandatoryColName.getLength();i++)
			{
				mandatoryFields.add(nodeListMandatoryColName.item(i).getFirstChild().getNodeValue().replaceAll("[^\\w]", ""));
			}


			Set<String> set=new LinkedHashSet<String>();
			set= nameValuePair.keySet();

			logger.debug("Initial values of the keyset of nameValuePairMap********" + set);



			for(String obj:set)
			{
				String propsObjKey=obj;

				nameValuePairDup.put(propsObjKey, nameValuePair.get(propsObjKey));


			}

			List<String> nameTags=checkTagName("columnTailString", document);

			List<String> columnNotEmptyTags=checkTagName("columnNotEmpty", document);

			logger.debug("Starting the loop for number of tables used");
			logger.info("Processing the rows for csv generation");
			//	logger.info("Starting the loop for number of tables used");
			// for number of tables used

			dbSuffix= getDbSuffix(sessionUser); /* getting the dbSiffix value from the method getDbSuffix */
			for(String tableNames:tableNamesUse)
			{


				//String tableName=tableNames.replaceAll("[^\\w]", "");
				
				System.out.println("table name is :"+tableNames);

				String tableNameSheet=tableNames.replaceAll("[^\\w]", "");

				int size=getUser(sessionUser,tableNameSheet,con);




				logger.debug("the size of the table   "+tableNameSheet+"   is "+ size);


				/*	List<String> tableColNames=new ArrayList<>();
				tableColNames=getColNames(sessionUser,tableName,con);*/


				//for iterating across the row of table
				logger.debug("Starting the loop for iterating across the row of table");
				//logger.info("Starting the loop for iterating across the row of table");
				for(int i=0;i<size;i++)
				{

					Map<String, String> eachEntry=new LinkedHashMap<String,String>();

					int count = getCountOfTables(tableNameSheet, con, sessionUser,dbSuffix);

					int countMax=count;

					while(count>0)
					{
						List<String> tableColNames=new ArrayList<>();

						String tableName= getSuffixedTableNames(tableNameSheet, dbSuffix, count, countMax);

						tableColNames=getColNames(sessionUser,tableName,con);


						tablerows:	

							for(String colNames: tableColNames)
							{
								/*for iterating across the keys in properties file*/

								//System.out.println("colmn name is ******"+colNames);



								logger.debug("colmn name is ******"+colNames);

								for(String name:xmlName)
								{

									key = name;


									logger.debug("key value is ******************"+key);


									if(!(key.equalsIgnoreCase("MasterTable")||key.equalsIgnoreCase("MandatoryFields")))
									{
										value=nameValuePair.get(key);




										String sheetValue=SheetValue(nodeListValue, value, i, nodeListIdentifierValue,sessionUser,tableName,con);

										nameValuePair.put(key, sheetValue);

										//System.out.println(key+":"+sheetValue);
										//value=props.getProperty(key);


										//valueLower=value.toLowerCase();

										valueLower=sheetValue.toLowerCase();




										if(valueLower.contains(colNames))	
										{
											logger.debug("the value : "+valueLower+" contains the colname  "+colNames);

											//String mandatoryField=props.getProperty("MandatoryFields");
											String mandatoryField=mandatoryFields.toString();

											/*calling the method to fetch the col value from DB*/
											logger.debug("calling the method to fetch the col value from DB");
											value1=UserCsvGenPop(colNames, i,sessionUser,tableName,con);  

											value1=value1.replace("\n", "").replace("\r", "");

											logger.debug("the value from DB for the colname  "+colNames+" is "+value1);

											logger.debug("validating the mandatory fields not null");

											/*	validating the mandatory fields not null*/
											String mandatoryFieldLower=mandatoryField.toLowerCase();
											if(mandatoryFieldLower.contains(colNames) &&  (value1.isEmpty() || value1.contains(" ")))
											{
												logger.debug("mandatory fields "+mandatoryFieldLower+" value is empty "+value1);

												alternativeValueMandatoryErrorGet=alternativeColumnMandatory(colNames,document,i,tableName,sessionUser,alternativeValueMandatoryErrorList,con);

												eachEntry.clear();

												break tablerows;


											}
											else
											{
												if(!(value1==null ||value1.equalsIgnoreCase("")))
												{

													//valueActual=value.replaceAll("(?i)"+Pattern.quote(colNames),value1);



													/*validate trim char attribute*/


													value1=ValidateTrimChar(document,value1,key);

													/*if(allAttributes.contains("trimchar"))
												{
													for(String nameTag: nameTags)
													{
														if(nameTag.equalsIgnoreCase(key))
														{
															value1=ValidateTrimChar(document,value1,key);
														}
													}
												}*/



													if(allAttributes.contains("columnTailString"))
													{
														//List<String> nameTags=checkTagName("columnTailString", document);


														for(String nameTag: nameTags)
														{

															if(nameTag.equalsIgnoreCase(key))
															{
																value1=ValidateColumnTailString(colNames,value1,document, key);
															}
														}


													}

													/*case insensitive use of replaceAll method*/
													//valueActual=sheetValue.replaceAll("(?i)"+Pattern.quote(colNames),value1);
													value1=Matcher.quoteReplacement(value1);
													valueActual=sheetValue.replaceAll("(?i)"+Pattern.quote(colNames),value1);
													//valueWithoutTrim=sheetValue.replaceAll("(?i)"+Pattern.quote(colNames),value1);
													//valueActual=valueWithoutTrim.trim();

													nameValuePair.put(key, valueActual);
													logger.debug("Updating the namevaluePair map with the actual values");
													eachEntry.put(key, valueActual);
													logger.debug("Updating the eachEntry map with the actual values");

												}
												else
												{	
													value1="";

													logger.debug("column name is "+colNames);

													if(allAttributes.contains("columnNotEmpty"))
													{

														for(String tag: columnNotEmptyTags)
														{


															if(tag.equalsIgnoreCase(key))
															{
																logger.debug("tag which is same as key is "+tag);
																colNotEmptyListGet=ValidateColumnNotEmpty(colNames,value1,document,tableName,i,colNotEmptyList,sessionUser,con);
															}
														}



													}

													valueActual=value1;

													eachEntry.put(key, valueActual);	

													logger.debug("Updating the eachEntry map with the actual values if the value from DB is empty");
												} 
											}

											/*			
						if(!(value1==null ||value1==""))
						{
							case insensitive use of replaceAll method
							valueActual=value.replaceAll("(?i)"+Pattern.quote(colNames),value1);
							props.setProperty(key, valueActual);
							eachEntry.put(key, valueActual);

						}
						else
						{	
						value1="";

						valueActual=value1;

						eachEntry.put(key, valueActual);	
						} */

										}


									}

								}		



							}



						logger.debug("for the keys whose values are not the name of column and we have to take their values as it is in props file");
						/*for the keys whose values are not the name of column and we have to take their values as it is in props file*/
						if(!(eachEntry.isEmpty()))
						{
							/*			Set<String> keys=eachEntry.keySet();
						Set<String>set2=new LinkedHashSet<String>();                   
						set2=set;
						List<String> allValues=new ArrayList<>();
						List<String> tableValues=new ArrayList<>();
						for(String ob:set2)
						{
							allValues.add(ob);
						}
						logger.debug("All the names as keys from the XML"+allValues);

						for(String s1:keys)
						{
							tableValues.add(s1);
						}
						logger.debug("All the names as keys from the from the table generated map"+tableValues);

						allValues.removeAll(tableValues);
						for(String ob1:allValues)
						{
							String key2=ob1;
							String value2=nameValuePair.get(key2);
							//String value2=props.getProperty(key2);
							if(!(key2.equalsIgnoreCase("MasterTable")|| key2.equalsIgnoreCase("MandatoryFields")))
							{

								eachEntry.put(key2, value2);
							}
						}*/

							if(countMax==1)
							{
								Set<String> keys=eachEntry.keySet();
								Set<String>set2=new LinkedHashSet<String>();                   
								set2=set;
								List<String> allValues=new ArrayList<>();
								List<String> tableValues=new ArrayList<>();
								for(String ob:set2)
								{
									allValues.add(ob);
								}
								logger.debug("All the names as keys from the XML"+allValues);

								for(String s1:keys)
								{
									tableValues.add(s1);
								}
								logger.debug("All the names as keys from the from the table generated map"+tableValues);

								allValues.removeAll(tableValues);
								for(String ob1:allValues)
								{
									String key2=ob1;
									String value2=nameValuePair.get(key2);
									//String value2=props.getProperty(key2);
									if(!(key2.equalsIgnoreCase("MasterTable")|| key2.equalsIgnoreCase("MandatoryFields")))
									{

										eachEntry.put(key2, value2);
									}
								}
							}


							Map<String, String> eachEntryCommonConfig=new LinkedHashMap<>();

							eachEntryCommonConfig=UserCommonConfig(documentCommon, eachEntry);

							if(allAttributes.contains("notContains"))
							{
								eachEntryCommonConfig=ValidateNotContainsAttribute(document,eachEntryCommonConfig);
							}

							if(allAttributes.contains("contains"))
							{
								eachEntryCommonConfig=ValidateContainsAttribute(document, eachEntryCommonConfig);
							}

							if(allAttributes.contains("notContainsValidator"))
							{
								notContainValidatorListGet=ValidateNotContainsValidator(document, eachEntryCommonConfig, notContainValidatorList, i , tableName,sessionUser,con);
							}

							if(allAttributes.contains("containsValidator"))
							{
								containsValidatorListGet=ValidateContainsValidator(document, eachEntryCommonConfig, containsValidatorList, i, tableName,sessionUser,con);
							}



							/*if(allAttributes.contains("skipDuplicate"))
						{
							eachEntryCommonConfig=ValidateSkipDuplicate(document, eachEntryCommonConfig, valueKeyMapGetSkipDuplicateList);
						}*/

							/*	if(!(eachEntryCommonConfig.isEmpty()))
						{
						if(allAttributes.contains("ifEmptyIgnoreRow"))
						{
							eachEntryCommonConfig=ValidateIfEmptyIgnoreRow(document, eachEntryCommonConfig);

						}


						}*/

							//if(!(eachEntryCommonConfig.isEmpty()))
							//	{
							if(allAttributes.contains("dependentCol"))
							{
								eachEntryCommonConfig=ValidateDependentColumn(document, eachEntryCommonConfig);
							}

							if(allAttributes.contains("subStrDelimiter"))
							{
								eachEntryCommonConfig=ValidateSubStrDelimiter(document,eachEntryCommonConfig);
							}

							//Doing pickDependentSheetValue here//

							if(allAttributes.contains("pickDependentSheetValue"))
							{
								eachEntryCommonConfig=ValidatePickDependentSheetColValue(document,tableName,nodeListIdentifierValue,sessionUser,i,con,eachEntryCommonConfig);
								//ValidatePickDependentSheetColValue(document,tableName,nodeListIdentifierValue,sessionUser,i,con,eachEntryCommonConfig);
							}

							if(allAttributes.contains("dependentSheet"))
							{
								dependentSheetObjListGet=ValidateDependentSheet(document,tableName,nodeListIdentifierValue,sessionUser, i, dependentSheetObjList,con);
							}

							if(allAttributes.contains("length"))
							{
								lengthAttributeObjListGet=ValidateAttribute(document,eachEntryCommonConfig,i,tableName,lengthAttributeObjList,sessionUser,con);
							}

							if(allAttributes.contains("duplicate"))
							{
								dupAttributeObjListGet=ValidateDuplicateAttribute(document,eachEntryCommonConfig,i,tableName,dupAttributeObjList,valueKeyMapGetList, valueKeyMapGetListYes,sessionUser,con);
							}

							if(allAttributes.contains("isNumber"))
							{
								isNumberObjListGet=ValidateNumberAttribute(document, eachEntryCommonConfig, i, tableName, isNumberObjList,sessionUser,con);
							}



							if(allAttributes.contains("prefix"))
							{
								eachEntryCommonConfig=ValidatePrefix(document, eachEntryCommonConfig);
							}

							if(allAttributes.contains("conflictCol"))
							{
								conflictColListGet=ValidateConflitCol(document, eachEntryCommonConfig , i, tableName, conflictColList, sessionUser,con);
							}

							if(allAttributes.contains("isColSubString"))
							{
								isColSubstringListGet=ValidateIsColSubString(document, eachEntryCommonConfig, i, tableName, sessionUser, isColSubstringList,con);
							}

							/*	if(allAttributes.contains("notContainsValidator"))
							{
								notContainValidatorListGet=ValidateNotContainsValidator(document, eachEntryCommonConfig, notContainValidatorList, i , tableName);
							}*/

							/*if(allAttributes.contains("containsValidator"))
							{
								containsValidatorListGet=ValidateContainsValidator(document, eachEntryCommonConfig, containsValidatorList, i, tableName);
							}
							 */
							/*	if(allAttributes.contains("notEmpty"))
						{
							notEmptyAttributeListGet=ValidateNotEmpty(document, eachEntryCommonConfig, tableName, i, notEmptyAttributeList,sessionUser,con);
						}*/

							if(allAttributes.contains("checkDuplicate"))
							{
								duplicateValuesListGet=ValidateCheckDuplicate(document, eachEntryCommonConfig, i, tableName, duplicateValuesList,sessionUser,con);
							}

							if(allAttributes.contains("skipDuplicate"))
							{
								eachEntryCommonConfig=ValidateSkipDuplicate(document, eachEntryCommonConfig, valueKeyMapGetSkipDuplicateList);
							}

							/*if(allAttributes.contains("ifEmptyIgnoreRow"))
							{
								eachEntryCommonConfig=ValidateIfEmptyIgnoreRow(document, eachEntryCommonConfig);

							}

							eachEntryCommonConfig=ValidateExcludeColumn(document, eachEntryCommonConfig);*/

							if(!(eachEntryCommonConfig.isEmpty()) )
							{
								if(allAttributes.contains("ifEmptyIgnoreRow"))
								{
									eachEntryCommonConfig=ValidateIfEmptyIgnoreRow(document, eachEntryCommonConfig);

								}



							}

							if(!(eachEntryCommonConfig.isEmpty()))
							{
								if(allAttributes.contains("notEmpty"))
								{
									notEmptyAttributeListGet=ValidateNotEmpty(document, eachEntryCommonConfig, tableName, i, notEmptyAttributeList,sessionUser,con);
								}
							}



							if(!(eachEntryCommonConfig.isEmpty()))
							{
								if(allAttributes.contains("isEmpty"))
								{
									isEmptyAttributeListGet=ValidateIsEmpty(document, eachEntryCommonConfig, tableName, i, isEmptyAttributeList, sessionUser,con);
								}
							}


							if(!(eachEntryCommonConfig.isEmpty()) )
							{
								if(allAttributes.contains("dropChar"))
								{
									eachEntryCommonConfig=ValidateDropChar(document,eachEntryCommonConfig);

								}

								/*if(allAttributes.contains("handleList"))
							{
								eachEntryCommonConfig=ValidateHandleList(document,eachEntryCommonConfig);

							}*/

								if(allAttributes.contains("dependentColValidator"))
								{
									dependentColListGet=ValidateDependentColumnValidator(document, eachEntryCommonConfig, dependentColList, i , tableName,sessionUser,con);


								}
								
								if(allAttributes.contains("replace"))
								{
									eachEntryCommonConfig=ValidateReplace(document,eachEntryCommonConfig);
								}


								eachEntryCommonConfig=ValidateExcludeColumn(document, eachEntryCommonConfig);

								//masterMap.add(eachEntryCommonConfig);

								if(count==1)
								{
									masterMap.add(eachEntryCommonConfig);
								}
							}









							//	}




							/*if(allAttributes.contains("dependentCol"))
						{
							eachEntryCommonConfig=ValidateDependentColumn(document, eachEntryCommonConfig);
						}

						if(allAttributes.contains("subStrDelimiter"))
						{
							eachEntryCommonConfig=ValidateSubStrDelimiter(document,eachEntryCommonConfig);
						}

						if(allAttributes.contains("dependentSheet"))
						{
							dependentSheetObjListGet=ValidateDependentSheet(document,tableName,nodeListIdentifierValue,sessionUser, i, dependentSheetObjList);
						}

						if(allAttributes.contains("length"))
						{
							lengthAttributeObjListGet=ValidateAttribute(document,eachEntryCommonConfig,i,tableName,lengthAttributeObjList);
						}

						if(allAttributes.contains("duplicate"))
						{
							dupAttributeObjListGet=ValidateDuplicateAttribute(document,eachEntryCommonConfig,i,tableName,dupAttributeObjList,valueKeyMapGetList);
						}*/



							//eachEntryCommonConfig = ValidateTrimCharAttribute(document,eachEntryCommonConfig);


							//if(message=="")
							//{



							//masterMap.add(eachEntryCommonConfig);



							//}
							//else
							//{
							//Map<String, String> messageValue=new LinkedHashMap<>();
							//messageValue.put("Error_Message", message);
							//masterMapSort.add(messageValue);
							//return masterMapSort;
							//}            







							//	masterMap.add(eachEntryCommonConfig);
							//masterMap.add(eachEntry);
						}

						logger.debug("All the entries are there in masterMap");

						/* Again entering the initial values in the map nameValuePair */
						logger.debug("Again entering the initial values in the map nameValuePair");

						/*			Set<String> keysNameValuePairDup=new HashSet<>();
					keysNameValuePairDup=nameValuePairDup.keySet();

					for(String ob1:keysNameValuePairDup)
					{

						String keyProps=ob1;
						nameValuePair.put(keyProps, nameValuePairDup.get(keyProps));

						//props.setProperty(keyProps, propsObj.getProperty(keyProps));
						//System.out.println("final props obj value"+props.getProperty(keyProps));
					}*/

						if(countMax==1)
						{
							Set<String> keysNameValuePairDup=new HashSet<>();
							keysNameValuePairDup=nameValuePairDup.keySet();

							for(String ob1:keysNameValuePairDup)
							{

								String keyProps=ob1;
								nameValuePair.put(keyProps, nameValuePairDup.get(keyProps));

								//props.setProperty(keyProps, propsObj.getProperty(keyProps));
								//System.out.println("final props obj value"+props.getProperty(keyProps));
							}
						}

						//logger.info("Loop ending for number of rows in table");
						logger.debug("Loop ending for number of rows in table");

						count=count-1;

					}

					if(countMax>1)
					{
						Set<String> keysNameValuePairDup=new HashSet<>();
						keysNameValuePairDup=nameValuePairDup.keySet();

						for(String ob1:keysNameValuePairDup)
						{

							String keyProps=ob1;
							nameValuePair.put(keyProps, nameValuePairDup.get(keyProps));

							//props.setProperty(keyProps, propsObj.getProperty(keyProps));
							//System.out.println("final props obj value"+props.getProperty(keyProps));
						}
					}


				}   /* Loop ending for number of rows in table*/


				//logger.info("loop ending for tables");	
				logger.debug("loop ending for tables");
			}    /*  loop ending for tables  */








			//logger.debug("passing the master map and commanConfig document to the method for getting the values from commanComfig XML");

			//masterMapUpdate= UserCommonConfig(documentCommon,masterMap);



			/*	for(Map<String, String> masterMapGet:masterMapUpdate)
		{
			Map<String, String> sortedMap=new LinkedHashMap<>();

			for(String keysNamevaluePair:nameValuePair.keySet())
			{
				sortedMap.put(keysNamevaluePair, masterMapGet.get(keysNamevaluePair));

			}
			masterMapSort.add(sortedMap);

			System.out.println("sorted map list----------------------------"+masterMapSort.toString());

		}*/


			/*  latest*/

			/*	for(Map<String, String> masterMapGet:masterMap)
			{
				Map<String, String> sortedMap=new LinkedHashMap<>();

				for(String keysNamevaluePair:nameValuePair.keySet())
				{
					sortedMap.put(keysNamevaluePair, masterMapGet.get(keysNamevaluePair));

				}
				masterMapSort.add(sortedMap);

				System.out.println("sorted map list----------------------------"+masterMapSort.toString());

			}*/

			if(allAttributes.contains("checkDuplicate"))
			{
				duplValListGet=FindDuplicateYes(duplicateValuesListGet);
			}

			if(allAttributes.contains("handleList"))
			{
				masterMap=ValidateHandleList(document,masterMap);

			}




			if(    !(lengthAttributeObjListGet.isEmpty()) || !(dupAttributeObjListGet.isEmpty())  || !(alternativeValueMandatoryErrorGet.isEmpty())     || !(dependentSheetObjListGet.isEmpty())    ||  ! (colNotEmptyListGet.isEmpty())     ||  ! (conflictColListGet.isEmpty())    || !(isColSubstringListGet.isEmpty())    || !(notContainValidatorListGet.isEmpty())       || !(containsValidatorListGet.isEmpty())     || !(notEmptyAttributeListGet.isEmpty())     || !(duplValListGet.isEmpty())         || !(isNumberObjListGet.isEmpty())   || !(isEmptyAttributeListGet.isEmpty())    || !(dependentColListGet.isEmpty())                                             )
			{


				List<String> errorMessages=new ArrayList<>();

				List<Map<String, String>> errorMessageMapList=new ArrayList<>();



				//System.out.println("size of the length attribute obj list is************"+lengthAttributeObjListGet.size());

				if(!(lengthAttributeObjListGet.isEmpty()))
				{
					errorMessages.add("=============Length Validation Errors=============");

					for(LengthAttribute obj:lengthAttributeObjListGet)
					{

						String columnName=obj.getColumnName();

						String tableName=obj.getSheetName();

						int rowIndex=obj.getRowNumber();

						String specifiedLen=obj.getSpecifiedColLength();

						int actualLen=obj.getActualColLength();

						//String message="Validation Falied for "+columnName+" for the row "+rowIndex+" of the table "+tableName+" as its actual length is "+actualLen+" and specified length is "+specifiedLen;

						//String message="Validation Falied for '"+columnName+"'field length in '"+tableName+"' Sheet Row Number "+rowIndex+"; Actual Length: "+actualLen+" and Configured Length: "+specifiedLen;

						String message="SheetName:'"+tableName+"' row:"+rowIndex+" column:'"+columnName+"' actual length:"+actualLen+" configured length:"+specifiedLen;


						errorMessages.add(message);
						//System.out.println("error msg are***************"+errorMessages);


					}


				}

				if(!(dupAttributeObjListGet.isEmpty())	)
				{
					errorMessages.add("=============Duplication Errors=============");
					for(DuplicateAttribute obj:dupAttributeObjListGet)
					{
						if(obj.getAttributeValue().equalsIgnoreCase("no"))
						{
							String columnName=obj.getColumnName();

							String tableName=obj.getSheetName();

							String columnValue=obj.getColumnValue();

							int rowIndex=obj.getRowNumber();


							//String message="Table:'"+tableName+"' row:"+rowIndex+"  with value : '"+columnValue+"' in column: '"+columnName+"' is duplicated"; 

							String message="SheetName:'"+tableName+"' row:"+rowIndex+" column:'"+columnName+"' with value:'"+columnValue+"' is duplicated"; 

							errorMessages.add(message);
						}

						/*	if(obj.getAttributeValue().equalsIgnoreCase("yes"))
						{
							String columnName=obj.getColumnName();

							String tableName=obj.getSheetName();

							String columnValue=obj.getColumnValue();

							int rowIndex=obj.getRowNumber();

							String message=tableName+" row "+rowIndex+"  with value  "+columnValue+" in column "+columnName+" is not duplicated"; 

							errorMessages.add(message);
						}
						 */
					}
				}

				if(!(dependentSheetObjListGet.isEmpty())	)
				{
					errorMessages.add("=============Dependent Sheet Errors=============");

					for(DependentSheetAttribute obj :dependentSheetObjListGet)
					{
						int row = obj.getRow();

						String identifierName = obj.getIdentifierName();

						String tableName = obj.getTableName();

						String dependentSheet = obj.getDependentSheet();

						String colValue=obj.getColValue();

						//String message= identifierName+": having value: '"+colValue+"' in row "+row+" in the table '"+tableName+"' is not present in the dependent sheet '"+dependentSheet+"'";

						String message="SheetName:'"+tableName+"' row: "+row+" column:'"+identifierName+"' with value:'"+colValue+"' is not present in the dependent sheet:'"+dependentSheet+"'";

						errorMessages.add(message);


					}

				}





				if( !(conflictColListGet.isEmpty()))
				{
					errorMessages.add("=============Conflict Column Errors=============");

					for(ConflictColAttribute obj : conflictColListGet)
					{
						int row= obj.getRow();

						String ColName= obj.getColumnName();

						String colValue= obj.getColumnValue();

						String tableName= obj.getSheetName();

						String attributeName= obj.getAttributeColumn();

						//String message="Column : '"+ColName+"' having value as: '"+colValue+"' is conflicting with the column: '"+attributeName+"' of the table : '"+tableName+"' in the row: "+row;



						String message="SheetName:'"+tableName+"' row:"+row+" column:'"+ColName+"' with value:'"+colValue+"' is conflicting with the column:'"+attributeName+"'";

						errorMessages.add(message);
					}
				}





				if( !(colNotEmptyListGet.isEmpty()))
				{
					errorMessages.add("=============Column Not empty Errors=============");

					for(ColumnNotEmptyAttribute obj: colNotEmptyListGet)
					{

						int row= obj.getRow();

						String colName= obj.getColName();

						String tableName= obj.getTableName();

						String valueCol=obj.getValue();

						//String message="Column : '"+colName+"' value is empty '"+valueCol+"' in the table name '"+tableName+"' in the row : "+row;

						String message="SheetName:'"+tableName+"' row:"+row+" column:'"+colName+"' value is empty";

						errorMessages.add(message);

					}
				}


				if(!(isColSubstringListGet.isEmpty()))
				{
					errorMessages.add("=============Is Column Substring Errors=============");


					for(IsColSubStringAttribute obj : isColSubstringListGet)
					{
						int row= obj.getRow();

						String tableName= obj.getTableName();

						String ColName = obj.getColName();

						String ColValue = obj.getColValue();

						String attributeCol=obj.getAttributeColumn();

						String attributeColValue = obj.getAttributeColValue();

						//String message = "Column : '"+ColName+"' with value is : '"+ColValue+"' in the table : '"+tableName+"' in the row : "+row+" is not the substring for :"+attributeCol+" having value as: '"+attributeColValue+"'";

						String message="SheetName:'"+tableName+"' row:"+row+" column:'"+ColName+"' with the value:'"+ColValue+"' is not the substring of column:'"+attributeCol+"' with the value:'"+attributeColValue+"'";

						errorMessages.add(message);
					}

				}


				if(!(duplValListGet.isEmpty()))
				{
					errorMessages.add("=============No Duplication Errors=============");

					for(CheckDuplicateAttribute obj : duplValListGet)
					{

						int row =obj.getRow();

						String tableName = obj.getTableName();

						String colName = obj.getColName();

						String colValue = obj.getColValue();

						//String message = "Column : '"+colName+"' with value : '"+colValue+"' for the table : '"+tableName+"' in the row : "+row+" is not duplicated";

						String message="SheetName:'"+tableName+"' row:"+row+" column:'"+colName+"' with the value:'"+colValue+"' is not duplicated";

						errorMessages.add(message);
					}
				}




				if(!(alternativeValueMandatoryErrorGet.isEmpty())      )
				{
					errorMessages.add("=============Alternative value not Found Errors=============");


					for(String message:alternativeValueMandatoryErrorGet)
					{
						errorMessages.add(message);
					}

				}


				if(!(notContainValidatorListGet.isEmpty()))
				{
					errorMessages.add("=============Not Contains Validator Errors=============");

					for(NotContainValidator obj : notContainValidatorListGet)
					{
						String tableName = obj.getTableName();

						String colName= obj.getColName();

						String colValue = obj.getColValue();

						String attributeValue = obj.getAttributeValue();

						int row = obj.getRow();

						//String message = "Column :'"+colName+"' with value : '"+colValue+"' in the row : "+row+" contains: '"+attributeValue+"' in the table: "+tableName;

						String message="SheetName:'"+tableName+"' row:"+row+" column:'"+colName+"' with value:'"+colValue+"' contains:'"+attributeValue+"'";

						errorMessages.add(message);
					}

				}


				if( !(containsValidatorListGet.isEmpty()) )
				{
					errorMessages.add("=============Contains Validator Errors=============");

					for(ContainsValidator obj : containsValidatorListGet)
					{

						String tableName = obj.getTableName();

						String colName = obj.getColName();

						String colValue= obj.getColValue();

						String attributeValue = obj.getAttributeValue();

						int row = obj.getRow();

						//String message = "Column :'"+colName+"' with value is : '"+colValue+"' in the row "+row+" does not contains ': "+attributeValue+"' in the table: '"+tableName+"'";

						String message="SheetName:'"+tableName+"' row:"+row+" column:'"+colName+"' with the value:'"+colValue+"' does not contains:'"+attributeValue+"'";

						errorMessages.add(message);

					}
				}

				if( !(dependentColListGet.isEmpty()) )
				{
					errorMessages.add("=============Dependent Column Validator Errors=============");

					for(DependentColumnValidator obj : dependentColListGet)
					{

						String tableName = obj.getTableName();

						String colName = obj.getColName();

						//String colValue= obj.getColValue();

						String attributeValue = obj.getAttributeValue();

						int row = obj.getRow();

						//String message = "Column :'"+colName+"' with value is : '"+colValue+"' in the row "+row+" does not contains ': "+attributeValue+"' in the table: '"+tableName+"'";

						String message="SheetName:'"+tableName+"' row:"+row+" column:'"+colName+" having value of the dependent column:'"+attributeValue+"' as empty";

						errorMessages.add(message);

					}
				}


				if( !(notEmptyAttributeListGet.isEmpty())  )
				{
					errorMessages.add("=============Not Empty Validator Errors=============");

					for(NotEmptyAttribute obj : notEmptyAttributeListGet)
					{
						String tableName = obj.getTableName();

						String colName = obj.getColName();

						String colValue = obj.getColValue();

						int row = obj.getRow();

						//String message = "Column : '"+colName+"'  is empty in the row: "+row+" of the table : '"+tableName+"'";

						String message="SheetName:'"+tableName+"' row:"+row+" column:'"+colName+"' is empty";

						errorMessages.add(message);
					}


				}


				if( !(isEmptyAttributeListGet.isEmpty())  )
				{
					errorMessages.add("=============Is Empty Validator Errors=============");

					for(IsEmptyAttribute obj : isEmptyAttributeListGet)
					{
						String tableName = obj.getTableName();

						String colName = obj.getColName();

						String colValue = obj.getColValue();

						int row = obj.getRow();

						//String message = "Column : '"+colName+"'  is empty in the row: "+row+" of the table : '"+tableName+"'";

						String message="SheetName:'"+tableName+"' row:"+row+" column:'"+colName+"' with value:'"+colValue+"' is not empty";

						errorMessages.add(message);
					}


				}


				if( !(isNumberObjListGet.isEmpty()) )
				{
					errorMessages.add("=============Is Number Validator Errors=============");


					for(IsNumberAttribute obj : isNumberObjListGet)
					{
						String tableName = obj.getTableName();

						String colName = obj.getColName();

						String colValue = obj.getColValue();

						int row = obj.getRow();

						String message="SheetName:'"+tableName+"' row:"+row+" column:'"+colName+"' with value:'"+colValue+"' is not a number";

						errorMessages.add(message);
					}
				}


				for(int i=0;i<errorMessages.size();i++)
				{
					//System.out.println(i+":"+errorMessages.get(i));
					Map<String, String> errorMessageMap=new LinkedHashMap<>();
					errorMessageMap.put(String.valueOf(i), errorMessages.get(i));
					errorMessageMapList.add(errorMessageMap);
				}

				//System.out.println(errorMessages);

				//System.out.println("size of the errorMapList**********"+errorMessageMapList.size());

				logger.info("Error log generation process completed");

				return errorMessageMapList;






			}
			else
			{
				for(Map<String, String> masterMapGet:masterMap)
				{
					Map<String, String> sortedMap=new LinkedHashMap<>();

					List<String> orgKeys = new ArrayList<>();

					List<String> processedKeys = new ArrayList<>();

					for(String key1 : nameValuePair.keySet())
					{
						orgKeys.add(key1);
					}



					for(String key2 : masterMapGet.keySet())
					{
						processedKeys.add(key2);
					}

					orgKeys.retainAll(processedKeys);


					//for(String keysNamevaluePair:nameValuePair.keySet())
					for(String keysNamevaluePair:orgKeys)	
					{
						sortedMap.put(keysNamevaluePair, masterMapGet.get(keysNamevaluePair));

					}
					masterMapSort.add(sortedMap);

					//System.out.println("sorted map list----------------------------"+masterMapSort.toString());

				}
			}


		}
		catch(Exception e)
		{
			logger.error("mastermap not able to return "+e);
			//e.printStackTrace();
		}
		finally 
		{
			if (statement!= null) {
				try {
					statement.close();
					//System.out.println("closing statement connections");

					logger.debug("closing statement connections");
				} catch (SQLException e) { }
			}
			if (con != null) {
				try {
					con.close();
					//System.out.println("closing all opened connections");
					logger.debug("closing all opened connections");
				} catch (SQLException e) { }
			}
		}



		logger.debug("returning the sorted masterMapSort");
		logger.info("CSV generation process completed");

		//logger.info("returning the sorted masterMapSort");

		return masterMapSort;

	}


	public int getUser(String sessionUser,String tableName, Connection con ) throws SQLException {


		String query="SELECT count(*) FROM " +sessionUser+"_"+ tableName+";";
		int size=0;

		//Connection con =null;

		Statement statement=null;


		try {
			/*Class.forName("com.mysql.jdbc.Driver");
			con = (Connection) DriverManager.getConnection("jdbc:mysql://localhost:3306/sample","root","cisco123");
			con.setAutoCommit(true);*/
			statement = con.createStatement();
			logger.debug("Opening connections");
			logger.debug("Opening statement connections");
			ResultSet result = statement.executeQuery(query);
			while(result.next())
			{
				size=result.getInt(1);
			}
			//System.out.println("size of the uploaded table in db is  ***"+size);
			logger.debug("size of the uploaded table in db is  ***"+size);

			statement.close();
			//con.close();
		} 
		catch (Exception e1) {
			// TODO Auto-generated catch block

			logger.error("size of the table"+e1.getMessage());
		} 

		finally
		{
			if (statement!= null) {
				try {
					statement.close();
					logger.debug("closing statement connections");
					//System.out.println("closing statement connections");
				} catch (SQLException e) { }
			}
			/*if (con != null) {
		        try {
		            con.close();
		            logger.debug("closing all opened connections");
		           // System.out.println("closing all opened connections");
		        } catch (SQLException e) { }
		    }*/
		}

		return size;
	}


	public List<String> getColNames(String sessionUser, String tableName,Connection con)  throws SQLException{
		List<String> 	tableColNames=new ArrayList<String>();

		//Connection con=null;

		Statement statement=null;

		try {
			/*Class.forName("com.mysql.jdbc.Driver");
			 con = (Connection) DriverManager.getConnection("jdbc:mysql://localhost:3306/sample","root","cisco123");
			con.setAutoCommit(true);*/
			//String fileName1 = fileName.replace(".csv", "");
			statement = con.createStatement();
			ResultSet resultSet = statement.executeQuery("SELECT * FROM " +sessionUser+"_"+ tableName+";" );

			ResultSetMetaData metadata = resultSet.getMetaData();
			int columnCount = metadata.getColumnCount();


			for (int i = 1; i <= columnCount; i++) {
				String columnName = metadata.getColumnName(i);
				String colNameLower= columnName.toLowerCase();
				tableColNames.add(colNameLower);
			}

			logger.debug("DB cols names are :"+tableColNames);

			statement.close();
			//con.close();
		} catch (Exception e1) {
			// TODO Auto-generated catch block


			logger.error(e1.getMessage());
		} 

		finally
		{
			if (statement!= null) {
				try {
					statement.close();
					//System.out.println("closing statement connections");

					logger.debug("closing statement connections");

				} catch (SQLException e) { }
			}
			/*if (con != null) {
		        try {
		            con.close();
		            //System.out.println("closing all opened connections");
		            logger.debug("closing all opened connections");
		        } catch (SQLException e) { }
		    }*/
		}

		logger.debug("the table column names are"+tableColNames);



		return tableColNames;

	}


	public String UserCsvGenPop(String val, int i,String sessionUser,String tableName,Connection con) throws SQLException
	{


		logger.debug("in usercsvgenProp method for fetching the values from DB");
		//logger.info("in usercsvgenProp method for fetching the values from DB");


		String sql="SELECT "+ val+" FROM " +sessionUser+"_"+ tableName+";";
		String tableValue="";

		List<String> tableValues=new ArrayList<>();

		//Connection con =null;

		Statement statement=null;

		try {
			/*Class.forName("com.mysql.jdbc.Driver");
			con = (Connection) DriverManager.getConnection("jdbc:mysql://localhost:3306/sample","root","cisco123");
			con.setAutoCommit(true);*/

			statement = con.createStatement();
			//System.out.println("the sql is  "+sql); 
			ResultSet resultSet = statement.executeQuery(sql);
			//	System.out.println("the size of the result set is "+resultSet.getFetchSize());
			while(resultSet.next())
			{

				tableValues.add(resultSet.getString(val));
			}

			for(int j=0;j<tableValues.size();j++)
			{
				if(j==i)
				{
					tableValue=tableValues.get(j);
				}
			}
			//	System.out.println("value for the column"+val+"for the row"+i+"is  : "+tableValue);

			statement.close();
			//con.close();
		}

		catch (Exception e) {
			// TODO: handle exception
			//con.close();
			logger.error("taking col value from DB"+e.getMessage());

			//e.printStackTrace();
		}

		finally 
		{
			if (statement!= null) {
				try {
					statement.close();
					//System.out.println("closing statement connections");

					logger.debug("closing statement connections");
				} catch (SQLException e) { }
			}
			/* if (con != null) {
		        try {
		            con.close();
		            //System.out.println("closing all opened connections");
		            logger.debug("closing all opened connections");
		        } catch (SQLException e) { }
		    }*/
		}


		logger.debug("the DB value for the colname "+val+" is "+tableValue);
		//logger.info("the DB value for the colname "+val+" is "+tableValue);

		return tableValue;

	}



	public Map<String, String> UserCommonConfig(Document documentCommon,Map<String, String>eachEntry)
	{
		List<Map<String, String>> masterMapUpdate=new ArrayList<Map<String,String>>();



		Set<String> setCommonConfig=new HashSet<>();
		String keyCommonConfig="";
		String valueCommonConfig="";
		String valColUpdated="";
		String valueCol="";

		String expressionCommonName="/Configs/CommonConfig/Config/Name";

		Map<String, String> commonConfigMap=new HashMap<>();

		String expressionCommonValue="/Configs/CommonConfig/Config/Value";

		XPath xPathCommon =  XPathFactory.newInstance().newXPath();

		Map<String, String> eachEntryUpdated=new HashMap<String,String>();
		try
		{
			NodeList nodeListCommonName=(NodeList)xPathCommon.compile(expressionCommonName).evaluate(documentCommon, XPathConstants.NODESET);
			NodeList nodeListCommonValue=(NodeList)xPathCommon.compile(expressionCommonValue).evaluate(documentCommon, XPathConstants.NODESET);

			for (int i = 0; i < nodeListCommonName.getLength(); i++)
			{
				if(nodeListCommonName.item(i).getFirstChild()==null && nodeListCommonValue.item(i).getFirstChild()==null )
				{

					return eachEntry;
				}
				if(!(nodeListCommonValue.item(i).getFirstChild()==null))
				{
					commonConfigMap.put(nodeListCommonName.item(i).getFirstChild().getNodeValue(), nodeListCommonValue.item(i).getFirstChild().getNodeValue());
				}
				else
				{
					commonConfigMap.put(nodeListCommonName.item(i).getFirstChild().getNodeValue(), nodeListCommonName.item(i).getFirstChild().getNodeValue());
				}

			}
			setCommonConfig=commonConfigMap.keySet();

			//for(Map<String, String> mapEachRow:masterMap)
			//{
			//	Map<String, String> eachEntryUpdated=new HashMap<String,String>();
			//Set<String> allKeys=mapEachRow.keySet();
			Set<String> allKeys=eachEntry.keySet();

			if(commonConfigMap.isEmpty())
			{
				return eachEntry;
			}
			else
			{
				for(String o:setCommonConfig)
				{

					keyCommonConfig = o;
					String keyCommonConfigLower=keyCommonConfig.toLowerCase();


					for(String eachFileCol:allKeys)
					{
						//valueCol=mapEachRow.get(eachFileCol);
						valueCol=eachEntry.get(eachFileCol);
						String valueColLower=valueCol.toLowerCase();

						if(valueColLower.contains(keyCommonConfigLower))
						{
							valueCommonConfig=commonConfigMap.get(keyCommonConfig);
							System.out.println("Value common config:"+valueCommonConfig);
							//valueCommonConfig=props1.getProperty(keyCommonConfig);
							valColUpdated=valueCol.replaceAll("(?i)"+Pattern.quote(keyCommonConfig),valueCommonConfig);
							//mapEachRow.put(eachFileCol, valColUpdated);
							eachEntry.put(eachFileCol, valColUpdated);
							eachEntryUpdated.put(eachFileCol, valColUpdated);

						}
						else
						{
							eachEntryUpdated.put(eachFileCol, valueCol);
						}
					}
				}
			}






			/*	for(String o:setCommonConfig)
			{

				keyCommonConfig = o;
				String keyCommonConfigLower=keyCommonConfig.toLowerCase();


				for(String eachFileCol:allKeys)
				{
					//valueCol=mapEachRow.get(eachFileCol);
					valueCol=eachEntry.get(eachFileCol);
					String valueColLower=valueCol.toLowerCase();

					if(valueColLower.contains(keyCommonConfigLower))
					{
						valueCommonConfig=commonConfigMap.get(keyCommonConfig);
						//valueCommonConfig=props1.getProperty(keyCommonConfig);
						valColUpdated=valueCol.replaceAll("(?i)"+Pattern.quote(keyCommonConfig),valueCommonConfig);
						//mapEachRow.put(eachFileCol, valColUpdated);
						eachEntry.put(eachFileCol, valColUpdated);
						eachEntryUpdated.put(eachFileCol, valColUpdated);

					}
					else
					{
						eachEntryUpdated.put(eachFileCol, valueCol);
					}
				}
			}*/

			//masterMapUpdate.add(eachEntryUpdated);


			//}

			//System.out.println("size of the map with common config*******"+masterMapUpdate.size());

			logger.debug("size of the map with common config*******"+masterMapUpdate.size());
			//logger.info("size of the map with common config*******"+masterMapUpdate.size());
		}
		catch(Exception e)
		{
			logger.error("returning from UserCommonConfig"+e.getMessage());
			e.printStackTrace();
		}

		logger.debug("returning the map having the values from the comman config");
		//logger.info("returning the map having the values from the comman config");
		//return masterMapUpdate;

		return eachEntryUpdated;
	}



	public List<LengthAttribute> ValidateAttribute(Document document,Map<String, String> eachEntry,int row, String tableName,List<LengthAttribute> lengthAttributeObjList, String sessionUser,Connection con )
	{

		//int actualExcelRow=row+1;

		int actualExcelRow=row+1;

		int startingRowNumber=0;

		String expressionName="/Configs/ColumnMapping/Column/Name";

		String expressionValue="/Configs/ColumnMapping/Column/Value";

		String message="";

		XPath xPath =  XPathFactory.newInstance().newXPath();

		Map<String, String> nameAttributePair=new LinkedHashMap<>();



		Set<String> setNameAttributePair=new LinkedHashSet<String>();

		//System.out.println("size of the lengthAttributeObjList before"+lengthAttributeObjList.size());

		try
		{

			startingRowNumber=getStartingRow(sessionUser, tableName,con);

			actualExcelRow=actualExcelRow+startingRowNumber;


			NodeList nodeListName=(NodeList)xPath.compile(expressionName).evaluate(document, XPathConstants.NODESET);

			NodeList nodeListValue=(NodeList)xPath.compile(expressionValue).evaluate(document, XPathConstants.NODESET);

			/* For storing Attribute value along with the name in the map*/
			for(int r=0;r<nodeListName.getLength();r++)
			{   

				Element e=(Element)nodeListValue.item(r);

				if(e.getAttribute("length").isEmpty())		
				{

					//System.out.println("checking for the empty attribute value***********"+e.getAttribute("length")+" : "+nodeListName.item(r).getFirstChild().getNodeValue());
					continue;
				}
				else
				{
					//System.out.println("checking for the not empty attribute value***********"+e.getAttribute("length")+" : "+nodeListName.item(r).getFirstChild().getNodeValue());
					nameAttributePair.put(nodeListName.item(r).getFirstChild().getNodeValue(), e.getAttribute("length"));
				}

			}


			Set<String> setEachEntry=new LinkedHashSet<String>();

			setEachEntry=eachEntry.keySet();

			setNameAttributePair=nameAttributePair.keySet();





			for(String keyMapGet:setEachEntry )
			{
				String valueMapGet=eachEntry.get(keyMapGet);

				keyNameAttributePairLoop:
					for(String keyNameAttributePair: setNameAttributePair)
					{

						if(keyMapGet.equalsIgnoreCase(keyNameAttributePair) && !(valueMapGet.isEmpty() )    )
						{
							//System.out.println("keyMapGet*****"+keyMapGet);

							//System.out.println("keyNameAttributePair*******"+keyNameAttributePair);



							String valueNameAttributePair=nameAttributePair.get(keyNameAttributePair);

							//System.out.println("valueNameAttributePair******"+valueNameAttributePair);

							//System.out.println("valueMapGet length is *********"+valueMapGet+": "+valueMapGet.length());

							if(valueMapGet.length()==Integer.parseInt(valueNameAttributePair))
							{
								//System.out.println("valueMapGet*********"+valueMapGet);

								//System.out.println("valueNameAttributePair******"+valueNameAttributePair);

								//System.out.println("the value of the length match******"+valueMapGet+"given length is "+valueNameAttributePair);

								break keyNameAttributePairLoop;


							}
							else
							{
								//System.out.println("the value of the length dint match******"+valueMapGet+"given length is "+valueNameAttributePair);

								LengthAttribute lengthAttribute=new LengthAttribute();



								lengthAttribute.setColumnName(keyMapGet.toLowerCase());

								lengthAttribute.setRowNumber(actualExcelRow);

								lengthAttribute.setSheetName(tableName);

								lengthAttribute.setActualColLength(valueMapGet.length());

								lengthAttribute.setSpecifiedColLength(valueNameAttributePair);

								lengthAttributeObjList.add(lengthAttribute);

								//System.out.println("size of the lengthAttributeObjList in the loop"+lengthAttributeObjList.size());

								//message="Validation Falied for "+keyMapGet.toLowerCase()+" for the row "+actualExcelRow+" of the table "+tableName+" as its actual length is "+valueMapGet.length()+" and specified length is "+valueNameAttributePair;

								//	System.out.println(message);


								//return lengthAttributeObjList;


							}

						}
					}
			}





		}
		catch(Exception e)
		{
			logger.error("ValidateAttribute"+e.getMessage());

			//e.printStackTrace();
		}

		//System.out.println("size of the lengthAttributeObjList after"+lengthAttributeObjList.size());

		return lengthAttributeObjList;





	}




	public String SheetValue(NodeList nodeListValue, String value, int row,	NodeList nodeListIdentifier, String sessionUser,String tableName,Connection con)
	{

		try
		{


			for(int k=0;k<nodeListValue.getLength();k++)
			{
				if(!(nodeListValue.item(k).getFirstChild()==null))
				{
					String nodeValue=nodeListValue.item(k).getFirstChild().getNodeValue();
					if(nodeValue.equalsIgnoreCase(value))
					{
						//System.out.println("the node value is equal to value from xml");
						Element e=(Element)nodeListValue.item(k);

						if(!(e.getAttributes()==null))
						{
							//System.out.println("e.getAttribites is not null");

							NamedNodeMap elementAttribute=e.getAttributes();

							if(!(elementAttribute.getLength()==0))
							{


								for(int r=0;r<elementAttribute.getLength();r++)
								{



									Node attr = elementAttribute.item(r);

									if((!(attr==null))   && attr.getNodeName().equalsIgnoreCase("sheet") )
									{

										String attributeName=attr.getNodeName();


										//if(attributeName.equalsIgnoreCase("sheet"))
										//{
										String sheetName=attr.getNodeValue().replaceAll("[^\\w]", "");

										String colNodeValue=getSheetValue(sheetName, row, nodeListIdentifier,sessionUser,nodeValue,tableName,con);

										//System.out.println("the colNodeValue is**********"+colNodeValue);

										return colNodeValue;


										//}

									}
									/*else
									{
										return value;
									}*/



								}




							}

							else
							{
								return value;
							}

						}

						else
						{
							return value;
						}

						/*	NamedNodeMap elementAttribute=e.getAttributes();

					Node attr = elementAttribute.item(k);

					String attributeName=attr.getNodeName();

					if(attributeName.equalsIgnoreCase("sheet"))
					{
						String sheetName=attr.getNodeValue().replaceAll("[^\\w]", "");

						String colNodeValue=getSheetValue(sheetName, row, nodeListIdentifier,sessionUser,nodeValue,tableName);

						System.out.println("the colNodeValue is**********"+colNodeValue);


					}*/

					}

				}
			}

		}	
		catch(Exception e)
		{
			logger.error("SheetValue"+e.getMessage());
		}



		return value;
	}


	public String getSheetValue(String sheetName,int row, NodeList nodeListIdentifier,String sessionUser,String nodeValue,String tableName,Connection con) throws SQLException
	{
		String identifierName="";

		String identifierValue="";

		String getColValue="";

		String updatedNodeValue="";

		String identifierTableValue="";
		List<String> sheetNameCols=new ArrayList<>();


		for(int i=0;i<nodeListIdentifier.getLength();i++)
		{
			identifierName=nodeListIdentifier.item(i).getFirstChild().getNodeValue();
		}

		String sqlIdentifierValues="SELECT "+ identifierName+" FROM " +sessionUser+"_"+sheetName+";";

		String sqlIdentifierTableValues="SELECT "+ identifierName+" FROM " +sessionUser+"_"+ tableName+";";



		List<String> identifierValues=new ArrayList<>();

		List<String> identifierTableValues=new ArrayList<>();

		//Connection con=null;

		Statement statement1=null;

		Statement statement2=null;

		Statement statement=null;

		Statement statement3=null;


		try {
			/*Class.forName("com.mysql.jdbc.Driver");
			 con = (Connection) DriverManager.getConnection("jdbc:mysql://localhost:3306/sample","root","cisco123");
			con.setAutoCommit(true);*/


			/*  for storing the cols of the SheetName table present in DB in the list sheetNameCols */
			statement1=con.createStatement();

			ResultSet resultSet1=statement1.executeQuery("SELECT * FROM " +sessionUser+"_"+sheetName+";" );

			ResultSetMetaData metadata = resultSet1.getMetaData();

			int columnCount = metadata.getColumnCount();

			for (int i = 1; i <= columnCount; i++) 
			{
				String columnName = metadata.getColumnName(i);
				String colNameLower= columnName.toLowerCase();
				sheetNameCols.add(colNameLower);
			}



			/*For getting the Identifier value from the tableName table according to the row Index*/

			statement2=con.createStatement();

			ResultSet resultSet2=statement2.executeQuery(sqlIdentifierTableValues);

			while(resultSet2.next())
			{
				identifierTableValues.add(resultSet2.getString(identifierName));
			}

			for(int j=0;j<identifierTableValues.size();j++)
			{
				if(j==row)
				{
					identifierTableValue=identifierTableValues.get(j);
				}
			}


			/* For getting the identifier value from the sheetName table according to the identifierTableValue */

			statement = con.createStatement();

			ResultSet resultSet = statement.executeQuery(sqlIdentifierValues);

			while(resultSet.next())
			{

				identifierValues.add(resultSet.getString(identifierName));
			}


			for(String identifierValueMatch:identifierValues)
			{

				if(identifierValueMatch.equalsIgnoreCase(identifierTableValue))
				{

					for(String sheetNameCol: sheetNameCols)
					{

						String sheetNameColLower=sheetNameCol.toLowerCase();

						String nodeValueLower=nodeValue.toLowerCase();

						//System.out.println("sheetNameColLower*************"+sheetNameColLower);



						if(nodeValueLower.contains(sheetNameColLower))
						{
							/* for getting the colName Value depending upon the identifierValueMatch  */


							//	String sqlgetColValue="SELECT "+ sheetNameCol+" FROM " +sessionUser+"_"+sheetName+ "WHERE 'USERID' ="+"'"+identifierValueMatch+"'"+";";

							String sqlgetColValue="SELECT "+ sheetNameCol+" FROM " +sessionUser+"_"+sheetName+" WHERE userid = "+"'"+identifierValueMatch+"'"+";";
							//PreparedStatement preparedStatement = con.prepareStatement(sqlgetColValue);
							//preparedStatement.setString(1, identifierValueMatch);
							statement3=con.createStatement();

							ResultSet resultSet3= statement3.executeQuery(sqlgetColValue);


							while(resultSet3.next())
							{
								getColValue=resultSet3.getString(1);
							}	

							updatedNodeValue=nodeValue.replaceAll("(?i)"+Pattern.quote(sheetNameCol),getColValue);
							//System.out.println("updated Node value***********"+updatedNodeValue);
							nodeValue=updatedNodeValue;
							//return updatedNodeValue;

						}

						//updatedNodeValue=nodeValue.replaceAll("(?i)"+Pattern.quote(sheetNameCol),getColValue);
					}

				}
			}


			/*statement.close();
			statement1.close();
			statement2.close();


			con.close();*/
		}
		catch(Exception e)
		{
			//con.close();
			logger.error("getSheetValue"+e.getMessage());
			//e.printStackTrace();
		}

		finally 
		{
			if (statement!= null) {
				try {
					statement.close();

					logger.debug("closing statement connections");


					//System.out.println("closing statement connections");
				} catch (SQLException e) { }
			}

			if (statement1!= null) {
				try {
					statement1.close();

					logger.debug("closing statement1 connections");
					//System.out.println("closing statement connections");
				} catch (SQLException e) { }
			}

			if (statement2!= null) {
				try {
					statement2.close();

					logger.debug("closing statement2 connections");
					//System.out.println("closing statement connections");
				} catch (SQLException e) { }
			}

			if (statement3!= null) {
				try {
					statement3.close();

					logger.debug("closing statement3 connections");
					//System.out.println("closing statement connections");
				} catch (SQLException e) { }
			}


			/*   if (con != null) {
		        try {
		            con.close();
		           // System.out.println("closing all opened connections");
		            logger.debug("closing all opened connections");
		        } catch (SQLException e) { }
		    }*/
		}

		return updatedNodeValue;
	}



	public String ValidateTrimChar(Document document,String value,String key)
	{
		String expressionName="/Configs/ColumnMapping/Column/Name";

		String expressionValue="/Configs/ColumnMapping/Column/Value";

		XPath xPath =  XPathFactory.newInstance().newXPath();

		Map<String, String> nameAttributePair=new LinkedHashMap<>();

		Set<String> setNameAttributePair=new LinkedHashSet<String>();


		try
		{
			NodeList nodeListName=(NodeList)xPath.compile(expressionName).evaluate(document, XPathConstants.NODESET);

			NodeList nodeListValue=(NodeList)xPath.compile(expressionValue).evaluate(document, XPathConstants.NODESET);

			/* For storing Attribute value along with the name in the map*/
			for(int r=0;r<nodeListName.getLength();r++)
			{   

				Element e=(Element)nodeListValue.item(r);

				if(e.getAttribute("trimchar").isEmpty())		
				{


					continue;
				}
				else
				{
					//System.out.println("checking for the not empty attribute value***********"+e.getAttribute("trimchar")+" : "+nodeListName.item(r).getFirstChild().getNodeValue());
					nameAttributePair.put(nodeListName.item(r).getFirstChild().getNodeValue(), e.getAttribute("trimchar"));
				}

			}

			setNameAttributePair=nameAttributePair.keySet();

			for(String keyNameAttributePair: setNameAttributePair)
			{
				if(keyNameAttributePair.equalsIgnoreCase(key))
				{
					String valueNameAttributePair=nameAttributePair.get(keyNameAttributePair);


					for(int i=0;i<valueNameAttributePair.length();i++)
					{
						char a=valueNameAttributePair.charAt(i);



						if(value.contains(String.valueOf(a)))
						{
							value=value.replace(String.valueOf(a), "");

							//System.out.println("replaced value**"+valueMapGet);
						}
					}
				}
			}


		}
		catch(Exception e)
		{
			logger.error("ValidateTrimChar"+e.getMessage());
			//e.printStackTrace();
		}


		return value;
	}






	public List<DuplicateAttribute> ValidateDuplicateAttribute(Document document,Map<String, String> eachEntry,int row, String tableName,List<DuplicateAttribute> dupAttributeObjList, Set<String> valueKeyMapGetList , List<String> valueKeyMapGetListYes, String sessionUser,Connection con )
	{

		//int actualExcelRow=row+1;

		int actualExcelRow=row+1;

		int startingRowNumber=0;

		String expressionName="/Configs/ColumnMapping/Column/Name";

		String expressionValue="/Configs/ColumnMapping/Column/Value";

		String message="";

		XPath xPath =  XPathFactory.newInstance().newXPath();

		Map<String, String> nameAttributePair=new LinkedHashMap<>();

		Set<String> setNameAttributePair=new LinkedHashSet<String>();

		try
		{
			startingRowNumber=getStartingRow(sessionUser, tableName,con);

			actualExcelRow=actualExcelRow+startingRowNumber;

			NodeList nodeListName=(NodeList)xPath.compile(expressionName).evaluate(document, XPathConstants.NODESET);

			NodeList nodeListValue=(NodeList)xPath.compile(expressionValue).evaluate(document, XPathConstants.NODESET);


			/* For storing Attribute value along with the name in the map*/
			for(int r=0;r<nodeListName.getLength();r++)
			{   

				Element e=(Element)nodeListValue.item(r);

				if(e.getAttribute("duplicate").isEmpty())		
				{

					//System.out.println("checking for the empty attribute value***********"+e.getAttribute("duplicate")+" : "+nodeListName.item(r).getFirstChild().getNodeValue());
					continue;
				}
				else
				{
					//System.out.println("checking for the not empty attribute value***********"+e.getAttribute("duplicate")+" : "+nodeListName.item(r).getFirstChild().getNodeValue());
					nameAttributePair.put(nodeListName.item(r).getFirstChild().getNodeValue(), e.getAttribute("duplicate"));
				}

			}


			Set<String> setEachEntry=new LinkedHashSet<String>();

			setEachEntry=eachEntry.keySet();

			setNameAttributePair=nameAttributePair.keySet();

			//List<String> valueKeyMapGetList=new ArrayList<>();

			String valueKeyMapGet="";



			for(String keyMapGet:setEachEntry )
			{


				for(String keyNameAttributePair: setNameAttributePair)
				{

					if(keyMapGet.equalsIgnoreCase(keyNameAttributePair))
					{
						//if(nameAttributePair.get(keyNameAttributePair).equals("no"))
						//	{
						valueKeyMapGet=eachEntry.get(keyMapGet);

						if(valueKeyMapGetList.contains(valueKeyMapGet) && !(valueKeyMapGet.equalsIgnoreCase("") )   )
						{




							DuplicateAttribute duplicateAttribute=new DuplicateAttribute();

							duplicateAttribute.setColumnName(keyMapGet);

							duplicateAttribute.setColumnValue(valueKeyMapGet);

							duplicateAttribute.setRowNumber(actualExcelRow);

							duplicateAttribute.setSheetName(tableName);

							duplicateAttribute.setAttributeValue("no");

							dupAttributeObjList.add(duplicateAttribute);



						}
						else
						{
							valueKeyMapGetList.add(valueKeyMapGet);		

						}
						//}


					}



				}


			}



		}
		catch(Exception e)
		{
			logger.error("ValidateDuplicateAttribute"+e.getMessage());
			//e.printStackTrace();
		}


		return dupAttributeObjList;
	}





	public List<String> alternativeColumnMandatory(String colName, Document document ,int row, String tableName, String sessionUser, List<String>alternativeValueMandatoryErrorList,Connection con)
	{
		String expressionMandatoryCol="/Configs/MandatoryColumns/ColumnName";

		XPath xPath =  XPathFactory.newInstance().newXPath();

		Map<String, String> nameAttributePair=new LinkedHashMap<>();

		Set<String> setNameAttributePair=new LinkedHashSet<String>();

		String alternativeColumnValueError="";
		String nodeValue="";

		String mandNodeValue="";

		//String errorColAttrValue="";

		try
		{
			NodeList nodeListMandatoryCol=(NodeList)xPath.compile(expressionMandatoryCol).evaluate(document, XPathConstants.NODESET);


			for(int r=0;r<nodeListMandatoryCol.getLength();r++)
			{   


				if(!(nodeListMandatoryCol.item(r).getFirstChild()==null))
				{
					nodeValue=nodeListMandatoryCol.item(r).getFirstChild().getNodeValue();

					Element e=(Element)nodeListMandatoryCol.item(r);

					if(!(e.getAttributes()==null))
					{

						NamedNodeMap elementAttribute=e.getAttributes();

						if(!(elementAttribute.getLength()==0))
						{


							for(int s=0;s<elementAttribute.getLength();s++)
							{

								Node attr = elementAttribute.item(s);

								if((!(attr==null))   && attr.getNodeName().equalsIgnoreCase("alternateCol") )
								{
									mandNodeValue=nodeValue;


									if(e.getAttribute("alternateCol").isEmpty())		
									{

										//System.out.println("checking for the empty attribute value***********"+e.getAttribute("alternateCol")+" : "+nodeListName.item(r).getFirstChild().getNodeValue());
										continue;
									}
									else
									{
										//System.out.println("checking for the not empty attribute value***********"+e.getAttribute("alternateCol")+" : "+nodeListName.item(r).getFirstChild().getNodeValue());
										nameAttributePair.put(nodeListMandatoryCol.item(r).getFirstChild().getNodeValue(), e.getAttribute("alternateCol"));
									}



								}

							}

						}
					}
				}




			}

			setNameAttributePair=nameAttributePair.keySet();

			//errorColAttrValue=ValidateErrorCol(nodeListMandatoryCol);

			//String [] errorColArray=errorColAttrValue.split(",");

			//GetErrorColValues(errorColAttrValue, tableName, row, sessionUser);




			//System.out.println("the attribute value of error col is"+errorColAttrValue);


			for(String name:setNameAttributePair)
			{
				if(name.equalsIgnoreCase(colName))
				{
					String alternativeColumn=nameAttributePair.get(name);

					alternativeColumnValueError=getAlternativeColValue(alternativeColumn,tableName,sessionUser,row,mandNodeValue,nodeListMandatoryCol,con);
					if( !(alternativeColumnValueError.equalsIgnoreCase("")) )
					{
						alternativeValueMandatoryErrorList.add(alternativeColumnValueError);
					}


					//alternativeValueMandatoryErrorList.add(alternativeColumnValueError);
				}
			}

		}
		catch(Exception e)
		{
			logger.error("alternativeColumnMandatory"+e.getMessage());
			//e.printStackTrace();
		}
		return alternativeValueMandatoryErrorList;
	}



	public String getAlternativeColValue(String alternativeColumn,String tableName, String sessionUser,int row, String mandNodeValue,NodeList nodeListMandatoryCol,Connection con) throws SQLException
	{

		//String sqlAlternativeColValue="SELECT "+ alternativeColumn+" FROM " +sessionUser+"_"+tableName+" WHERE SerialNumber = "+"'"+row+"'"+";";
		int serialNum=row+1;

		int actaulRow=row+1;

		int startingRowNumber=0;

		String sqlAlternativeColValue="SELECT "+ alternativeColumn+" FROM " +sessionUser+"_"+tableName+" WHERE SerialNumber = "+serialNum+";";

		String alternativeColValue="";

		String alternativeColValueError="";

		String errorColAttrValue="";

		List<String> errorColsValuesListGet = new ArrayList<>();

		List<String> errorColsNamesListGet = new ArrayList<>();

		String errorMessage="";

		//Connection con=null;

		Statement statement=null;


		try
		{

			startingRowNumber=getStartingRow(sessionUser, tableName,con);

			actaulRow=actaulRow+startingRowNumber;

			errorColAttrValue=ValidateErrorCol(nodeListMandatoryCol);

			int errorColAttrValueSize= errorColAttrValue.length();

			/*Class.forName("com.mysql.jdbc.Driver");

			 con = (Connection) DriverManager.getConnection("jdbc:mysql://localhost:3306/sample","root","cisco123");

			con.setAutoCommit(true);*/

			statement=con.createStatement();

			ResultSet resultSet= statement.executeQuery(sqlAlternativeColValue);

			while(resultSet.next())
			{
				if(!(resultSet.getString(1).isEmpty()))
				{
					alternativeColValue=resultSet.getString(1);
				}
				else
				{
					alternativeColValue="false";
				}


			}


			if(alternativeColValue.equalsIgnoreCase("false"))
			{

				if(errorColAttrValueSize==0)
				{
					alternativeColValueError="SheetName:'"+tableName+"' row:"+actaulRow+" column:'"+alternativeColumn+"' value is empty for the corresponding column:'"+mandNodeValue+"' which is also empty";
					return alternativeColValueError;
				}

				else
				{
					//errorColsValuesListGet=GetErrorColValues(errorColAttrValue, tableName, row, sessionUser);

					String [] errorColsValuesArrayGet=GetErrorColValues(errorColAttrValue, tableName, row, sessionUser,con);

					//errorColsNamesListGet=GetErrorColNames(errorColAttrValue, tableName, row, sessionUser);

					String [] errorColsNamesArrayGet=GetErrorColNames(errorColAttrValue, tableName, row, sessionUser,con);

					errorMessage=GetErrorColsMsg(errorColsValuesArrayGet, errorColsNamesArrayGet);

					alternativeColValueError="SheetName:'"+tableName+"' row:"+actaulRow+" column:'"+alternativeColumn+"' value is empty for the corresponding column:'"+mandNodeValue+"' which is also empty"+errorMessage;

				}
			}

			/*statement.close();

			con.close();*/
		}
		catch(Exception e)
		{
			//con.close();
			logger.error("getAlternativeColValue"+e.getMessage());
			//e.printStackTrace();
		}

		finally 
		{
			if (statement!= null) {
				try {
					statement.close();

					logger.debug("closing statement connections");


					//System.out.println("closing statement connections");
				} catch (SQLException e) { }
			}
			/* if (con != null) {
		        try {
		            con.close();
		            //System.out.println("closing all opened connections");
		            logger.debug("closing all opened connections");
		        } catch (SQLException e) { }
		    }*/
		}

		return alternativeColValueError;
	}



	public String ValidateErrorCol(NodeList nodeListMandatoryCol)
	{

		String nodeValue="";

		String mandNodeValue="";

		String attributeValue="";

		try
		{

			for(int r=0;r<nodeListMandatoryCol.getLength();r++)
			{   


				if(!(nodeListMandatoryCol.item(r).getFirstChild()==null))
				{
					nodeValue=nodeListMandatoryCol.item(r).getFirstChild().getNodeValue();

					Element e=(Element)nodeListMandatoryCol.item(r);

					if(!(e.getAttributes()==null))
					{

						NamedNodeMap elementAttribute=e.getAttributes();

						if(!(elementAttribute.getLength()==0))
						{


							for(int s=0;s<elementAttribute.getLength();s++)
							{

								Node attr = elementAttribute.item(s);

								if((!(attr==null))   && attr.getNodeName().equalsIgnoreCase("errorCol") )
								{
									mandNodeValue=nodeValue;


									if(e.getAttribute("errorCol").isEmpty())		
									{

										//System.out.println("checking for the empty attribute value***********"+e.getAttribute("alternateCol")+" : "+nodeListName.item(r).getFirstChild().getNodeValue());
										continue;
									}
									else
									{
										//System.out.println("checking for the not empty attribute value***********"+e.getAttribute("alternateCol")+" : "+nodeListName.item(r).getFirstChild().getNodeValue());
										attributeValue=e.getAttribute("errorCol");
									}



								}

							}

						}
					}
				}




			}


		}
		catch(Exception e)
		{
			//e.printStackTrace();

			logger.error("ValidateErrorCol"+e.getMessage());
		}

		return attributeValue;

	}


	//public List<String> GetErrorColValues(String errorCols , String tableName , int row , String sessionUser)
	public String[] GetErrorColValues(String errorCols , String tableName , int row , String sessionUser,Connection con) throws SQLException
	{
		int serialNum=row+1;

		//List<String> errorColsValuesList = new ArrayList<>();


		String [] errorColsArray= errorCols.split(",");

		int sizeErrorColsArray = errorColsArray.length;

		String [] errorColsValuesArray= new String[sizeErrorColsArray];

		//Connection con=null;

		Statement statement=null;


		String sqlErrorColValues="SELECT "+ errorCols+" FROM " +sessionUser+"_"+tableName+" WHERE SerialNumber = "+serialNum+";";

		try
		{
			/*Class.forName("com.mysql.jdbc.Driver");

			 con = (Connection) DriverManager.getConnection("jdbc:mysql://localhost:3306/sample","root","cisco123");

			con.setAutoCommit(true);*/

			statement=con.createStatement();

			ResultSet resultSet= statement.executeQuery(sqlErrorColValues);

			ResultSetMetaData rsmd = resultSet.getMetaData();

			int numberOfColumns = rsmd.getColumnCount();



			while(resultSet.next())
			{
				for(int i=1;i<=numberOfColumns;i++)
				{

					//errorColsValuesList.add(resultSet.getString(i));



					errorColsValuesArray[i-1]=resultSet.getString(i);


					//System.out.println(rsmd.getColumnName(i)+":"+resultSet.getString(i)+ " ");


				}
			}

			/*statement.close();
			con.close();*/

		}
		catch(Exception e)
		{
			//con.close();
			logger.error("GetErrorColValues"+e.getMessage());
			//e.printStackTrace();
		}

		finally {
			if (statement!= null) {
				try {
					statement.close();

					logger.debug("closing statement connections");

					//System.out.println("closing statement connections");
				} catch (SQLException e) { }
			}
			/* if (con != null) {
		        try {
		            con.close();
		            //System.out.println("closing all opened connections");
		            logger.debug("closing all opened connections");
		        } catch (SQLException e) { }
		    }*/
		}

		//return errorColsValuesList;

		return errorColsValuesArray;


	}

	public String [] GetErrorColNames(String errorCols , String tableName , int row , String sessionUser,Connection con) throws SQLException
	//public List<String> GetErrorColNames(String errorCols , String tableName , int row , String sessionUser)
	{
		int serialNum=row+1;

		//List<String> errorColsNamesList = new ArrayList<>();

		String [] errorColsArray= errorCols.split(",");

		int sizeErrorColsArray = errorColsArray.length;

		String [] errorColsNamesArray= new String[sizeErrorColsArray];

		//Connection con=null;

		Statement statement=null;

		String sqlErrorColValues="SELECT "+ errorCols+" FROM " +sessionUser+"_"+tableName+" WHERE SerialNumber = "+serialNum+";";

		try
		{
			/*Class.forName("com.mysql.jdbc.Driver");

			 con = (Connection) DriverManager.getConnection("jdbc:mysql://localhost:3306/sample","root","cisco123");

			con.setAutoCommit(true);*/

			statement=con.createStatement();

			ResultSet resultSet= statement.executeQuery(sqlErrorColValues);

			ResultSetMetaData rsmd = resultSet.getMetaData();

			int numberOfColumns = rsmd.getColumnCount();

			while(resultSet.next())
			{
				for(int i=1;i<=numberOfColumns;i++)
				{

					//errorColsNamesList.add(rsmd.getColumnName(i));



					errorColsNamesArray[i-1] = rsmd.getColumnName(i);



					//System.out.println(rsmd.getColumnName(i)+":"+resultSet.getString(i)+ " ");


				}
			}

			/*statement.close();
			con.close();*/

		}
		catch(Exception e)
		{
			//con.close();
			logger.error("GetErrorColNames"+e.getMessage());


			//e.printStackTrace();
		}

		finally {
			if (statement!= null) {
				try {
					statement.close();

					logger.debug("closing statement connections");

					// System.out.println("closing statement connections");
				} catch (SQLException e) { }
			}
			/* if (con != null) {
		        try {
		            con.close();
		            //System.out.println("closing all opened connections");


		            logger.debug("closing all opened connections");
		        } catch (SQLException e) { }
		    }*/
		}

		//return errorColsNamesList;

		return errorColsNamesArray;
	}


	public String GetErrorColsMsg(String [] errorColsValuesArray , String [] errorColsNamesArray )
	{
		String errorMsg="";


		if(errorColsNamesArray.length==0 || errorColsValuesArray.length==0)
		{
			return errorMsg;
		}
		else
		{


			for(int i=0 ;i<errorColsNamesArray.length;i++)
			{
				errorMsg=errorMsg+"; column:'"+errorColsNamesArray[i]+"' value is '"+errorColsValuesArray[i]+"'";

				//System.out.println(errorMsg);
			}
		}

		return errorMsg;

	}


	public List<DependentSheetAttribute> ValidateDependentSheet(Document document ,  String tableName, NodeList nodeListIdentifier,String sessionUser, int row , List<DependentSheetAttribute> dependentSheetObjList , Connection con)
	{
		String expressionMandatoryCol="/Configs/MandatoryColumns/ColumnName";

		//int actualRow=row+1;

		int actualRow=row+1;

		XPath xPath =  XPathFactory.newInstance().newXPath();

		String dependentSheet="";

		String identifierName="";

		int startingRowNumber=0;


		String flag="false";



		String identifierValue="";


		List<String> identifierValuesGet = new ArrayList<>();

		try
		{
			startingRowNumber=getStartingRow(sessionUser, tableName,con);

			actualRow=actualRow+startingRowNumber;


			NodeList nodeListMandatoryCol=(NodeList)xPath.compile(expressionMandatoryCol).evaluate(document, XPathConstants.NODESET);

			for(int i=0;i<nodeListIdentifier.getLength();i++)
			{

				if(!(nodeListIdentifier.item(i).getFirstChild()==null))
				{
					identifierName=nodeListIdentifier.item(i).getFirstChild().getNodeValue();
				}
			}

			for(int r=0;r<nodeListMandatoryCol.getLength();r++)
			{   

				Element e=(Element)nodeListMandatoryCol.item(r);

				if(e.getAttribute("dependentSheet").isEmpty())		
				{


					continue;
				}
				else
				{

					dependentSheet=e.getAttribute("dependentSheet");

					//System.out.println("dependent sheet name is *******"+dependentSheet);
					logger.debug("dependent sheet name is *******"+dependentSheet);
				}

			}

			identifierValuesGet = CheckDependentSheet(dependentSheet,nodeListIdentifier,sessionUser,con);

			identifierValue=CheckIdentifierValue(tableName,identifierName,row,sessionUser,con);


			for(String identifierValues: identifierValuesGet)
			{
				if( !(identifierValue.equalsIgnoreCase(identifierValues)) && !(identifierValue.equalsIgnoreCase("")) )
				{



					continue;
				}
				else
				{
					flag="true";
					break;
				}
			}

			if(flag.equalsIgnoreCase("false"))
			{
				DependentSheetAttribute dependentSheetAttribute = new DependentSheetAttribute();

				dependentSheetAttribute.setDependentSheet(dependentSheet);

				dependentSheetAttribute.setIdentifierName(identifierName);

				dependentSheetAttribute.setRow(actualRow);

				dependentSheetAttribute.setTableName(tableName);

				dependentSheetAttribute.setColValue(identifierValue);

				dependentSheetObjList.add(dependentSheetAttribute);


			}








		}
		catch(Exception e)
		{
			logger.error("ValidateDependentSheet"+e.getMessage());
			//e.printStackTrace();
		}

		return dependentSheetObjList;
	}

	public String CheckIdentifierValue(String tableName, String columnName, int row, String sessionUser,Connection con) throws SQLException
	{

		int serialNum=row+1;

		String sqlGetValue="SELECT "+ columnName+" FROM " +sessionUser+"_"+tableName+" WHERE SerialNumber = "+serialNum+";";

		String identifierValue="";

		//Connection con=null;

		Statement statement=null;


		try
		{
			/*Class.forName("com.mysql.jdbc.Driver");

			 con = (Connection) DriverManager.getConnection("jdbc:mysql://localhost:3306/sample","root","cisco123");

			con.setAutoCommit(true);*/

			statement=con.createStatement();

			ResultSet resultSet= statement.executeQuery(sqlGetValue);

			while(resultSet.next())
			{
				if(!(resultSet.getString(1).isEmpty()))
				{
					identifierValue=resultSet.getString(1);
				}

			}

			//System.out.println("Values in list identifierValues**************"+identifierValue);

			logger.debug("Values in list identifierValues**************"+identifierValue);

			/*statement.close();
			con.close();*/


		}
		catch(Exception e)
		{
			//con.close();
			logger.error("CheckIdentifierValue"+e.getMessage());
			//e.printStackTrace();
		}

		finally {
			if (statement!= null) {
				try {
					statement.close();


					logger.debug("closing statement connections");

					//System.out.println("closing statement connections");
				} catch (SQLException e) { }
			}
			/*if (con != null) {
		        try {
		            con.close();
		            //System.out.println("closing all opened connections");

		            logger.debug("closing all opened connections");
		        } catch (SQLException e) { }
		    }*/
		}

		return identifierValue;
	}


	public List<String>  CheckDependentSheet( String dependentSheet, NodeList nodeListIdentifier, String sessionUser,Connection con) throws SQLException
	{
		String identifierName="";

		//Connection con=null;

		Statement statement=null;


		for(int i=0;i<nodeListIdentifier.getLength();i++)
		{

			if(!(nodeListIdentifier.item(i).getFirstChild()==null))
			{
				identifierName=nodeListIdentifier.item(i).getFirstChild().getNodeValue();
			}
		}


		String dependentSheetReplace=dependentSheet.replaceAll("[^\\w]", "");

		String sqlIdentifierValues="SELECT "+ identifierName+" FROM " +sessionUser+"_"+dependentSheetReplace+";";

		List<String> identifierValues=new ArrayList<>();

		try
		{
			/*Class.forName("com.mysql.jdbc.Driver");

			con = (Connection) DriverManager.getConnection("jdbc:mysql://localhost:3306/sample","root","cisco123");

			con.setAutoCommit(true);*/

			statement=con.createStatement();

			ResultSet resultSet= statement.executeQuery(sqlIdentifierValues);

			while(resultSet.next())
			{
				if(!(resultSet.getString(1).isEmpty()))
				{
					identifierValues.add(resultSet.getString(1));
				}

			}

			//System.out.println("Values in list identifierValues**************"+identifierValues);
			logger.debug("Values in list identifierValues**************"+identifierValues);


			/*statement.close();
			con.close();
			 */

		}
		catch(Exception e)
		{
			//con.close();
			logger.error("CheckDependentSheet"+e.getMessage());
			//e.printStackTrace();
		}

		finally {
			if (statement!= null) {
				try {
					statement.close();

					logger.debug("closing statement connections");

					//System.out.println("closing statement connections");
				} catch (SQLException e) { }
			}
			/* if (con != null) {
		        try {
		            con.close();
		           // System.out.println("closing all opened connections");

		            logger.debug("closing all opened connections");

		        } catch (SQLException e) { }
		    }*/
		}

		return identifierValues;

	}


	public Map<String, String> ValidatePickDependentSheetColValue(Document document, String tableName,NodeList nodeListIdentifier,String sessionUser, int row ,Connection con, Map<String, String> eachEntry)
	{

		String expressionName="/Configs/ColumnMapping/Column/Name";

		String expressionValue="/Configs/ColumnMapping/Column/Value";

		String identifierName="";
		
		String identifierValue="";

		XPath xPath =  XPathFactory.newInstance().newXPath();

		Map<String, String> nameAttributePair=new LinkedHashMap<>();

		Set<String> setNameAttributePair=new LinkedHashSet<String>();

		String dependentSheetName="";

		String dependentSheetColName="";
		
		int flag=0;
		
		List<String> dependentSheetColValuesGet= new ArrayList<>();
		
		//System.out.println("row number is "+row);

		try
		{
			NodeList nodeListName=(NodeList)xPath.compile(expressionName).evaluate(document, XPathConstants.NODESET);

			NodeList nodeListValue=(NodeList)xPath.compile(expressionValue).evaluate(document, XPathConstants.NODESET);

			for(int i=0;i<nodeListIdentifier.getLength();i++)
			{

				if(!(nodeListIdentifier.item(i).getFirstChild()==null))
				{
					identifierName=nodeListIdentifier.item(i).getFirstChild().getNodeValue();
				}
			}

			/* For storing Attribute value along with the name in the map*/
			for(int r=0;r<nodeListName.getLength();r++)
			{   

				Element e=(Element)nodeListValue.item(r);

				if(e.getAttribute("pickDependentSheetValue").isEmpty())		
				{

					//System.out.println("checking for the empty attribute value***********"+e.getAttribute("pickDependentSheetValue")+" : "+nodeListName.item(r).getFirstChild().getNodeValue());
					continue;
				}
				else
				{
					//System.out.println("checking for the not empty attribute value***********"+e.getAttribute("pickDependentSheetValue")+" : "+nodeListName.item(r).getFirstChild().getNodeValue());
					nameAttributePair.put(nodeListName.item(r).getFirstChild().getNodeValue(), e.getAttribute("pickDependentSheetValue"));
				}

			}

			Set<String> setEachEntry=new LinkedHashSet<String>();

			setEachEntry=eachEntry.keySet();
			
			//System.out.println("SetEachEntry**"+setEachEntry);

			setNameAttributePair=nameAttributePair.keySet();

			//System.out.println("Identifier Name is ****"+identifierName);

			for(String eachEntryKey: setEachEntry)
			{
				for(String nameAttributePairKey : setNameAttributePair)
				{
					String nameAttributePairValues=nameAttributePair.get(nameAttributePairKey);

					String [] nameAttributePairValue=nameAttributePairValues.split(",");

					dependentSheetName=nameAttributePairValue[0];

					dependentSheetColName = nameAttributePairValue[1];

					if(eachEntryKey.equalsIgnoreCase(nameAttributePairKey) )
					{
						eachEntry.put(eachEntryKey, "");
						
						dependentSheetColValuesGet = FindDependentSheetColValue(dependentSheetName,dependentSheetColName,sessionUser,con);
						
						identifierValue=CheckIdentifierValue(tableName, identifierName, row, sessionUser, con);
						
						//System.out.println("Identifier Name is ****"+identifierName+"Identifier Value is ****"+identifierValue);
						
						logger.debug("Identifier Name is ****"+identifierName+"Identifier Value is ****"+identifierValue);
						
						//System.out.println("**********dependentSheetColValuesGet*******"+dependentSheetColValuesGet);
						
						for(String dependentSheetColValue : dependentSheetColValuesGet)
						{
							if(dependentSheetColValue.contains(identifierValue))
							{
								eachEntry.put(eachEntryKey, dependentSheetColValue);
								
								//System.out.println("******"+eachEntryKey+","+dependentSheetColValue);
								
								logger.debug("******"+eachEntryKey+","+dependentSheetColValue);
								
								flag=1;
								
								return eachEntry;
							}
							
						}
						
						
					}


				}
			}
			
			
		}
		catch(Exception e)
		{
			logger.error("ValidatePickDependentSheetColValue"+e.getMessage());
		}
		
		return eachEntry;

	}
	
	public List<String> FindDependentSheetColValue(String dependentSheet, String dependentSheetColName, String sessionUser,Connection con)throws SQLException
	{
		Statement statement=null;
		
		String dependentSheetReplace=dependentSheet.replaceAll("[^\\w]", "");
		
		String sql="SELECT "+ dependentSheetColName+" FROM " +sessionUser+"_"+dependentSheetReplace+";";
		
		List<String> dependentSheetColValues = new ArrayList<>();
		
		try
		{
			/*Class.forName("com.mysql.jdbc.Driver");

			con = (Connection) DriverManager.getConnection("jdbc:mysql://localhost:3306/sample","root","cisco123");

			con.setAutoCommit(true);*/

			statement=con.createStatement();

			ResultSet resultSet= statement.executeQuery(sql);

			while(resultSet.next())
			{

				dependentSheetColValues.add(resultSet.getString(1));
			}
			//System.out.println("Values in list identifierValues**************"+identifierValues);
			logger.debug("Values in list dependentSheetColValues**************"+dependentSheetColValues);


			/*statement.close();
			con.close();
			 */

		}
		catch(Exception e)
		{
			//con.close();
			logger.error("FindDependentSheetColValue"+e.getMessage());
			//e.printStackTrace();
		}

		finally {
			if (statement!= null) {
				try {
					statement.close();

					logger.debug("closing statement connections");

					//System.out.println("closing statement connections");
				} catch (SQLException e) { }
			}
			
		}
		
		return dependentSheetColValues;
	}


	public Map<String, String> ValidateNotContainsAttribute(Document document, Map<String, String> eachEntry)
	{
		String expressionName="/Configs/ColumnMapping/Column/Name";

		String expressionValue="/Configs/ColumnMapping/Column/Value";

		XPath xPath =  XPathFactory.newInstance().newXPath();

		Map<String, String> nameAttributePair=new LinkedHashMap<>();

		Set<String> setNameAttributePair=new LinkedHashSet<String>();

		try
		{
			NodeList nodeListName=(NodeList)xPath.compile(expressionName).evaluate(document, XPathConstants.NODESET);

			NodeList nodeListValue=(NodeList)xPath.compile(expressionValue).evaluate(document, XPathConstants.NODESET);

			/* For storing Attribute value along with the name in the map*/
			for(int r=0;r<nodeListName.getLength();r++)
			{   

				Element e=(Element)nodeListValue.item(r);

				if(e.getAttribute("notContains").isEmpty())		
				{

					//System.out.println("checking for the empty attribute value***********"+e.getAttribute("notContains")+" : "+nodeListName.item(r).getFirstChild().getNodeValue());
					continue;
				}
				else
				{
					//System.out.println("checking for the not empty attribute value***********"+e.getAttribute("notContains")+" : "+nodeListName.item(r).getFirstChild().getNodeValue());
					nameAttributePair.put(nodeListName.item(r).getFirstChild().getNodeValue(), e.getAttribute("notContains"));
				}

			}


			Set<String> setEachEntry=new LinkedHashSet<String>();

			setEachEntry=eachEntry.keySet();

			setNameAttributePair=nameAttributePair.keySet();

			for(String eachEntryKey: setEachEntry)
			{
				String eachEntryValue=eachEntry.get(eachEntryKey);

				for(String nameAttributePairKey : setNameAttributePair)
				{
					String nameAttributePairValues=nameAttributePair.get(nameAttributePairKey);

					String [] nameAttributePairValue=nameAttributePairValues.split(",");

					if(eachEntryKey.equalsIgnoreCase(nameAttributePairKey) &&  !(eachEntryValue.isEmpty()))
					{
						for(int i=0;i<nameAttributePairValue.length;i++)
						{
							if(eachEntryValue.contains(nameAttributePairValue[i]))
							{
								eachEntryValue="";
								eachEntry.put(eachEntryKey,eachEntryValue);

							}
						}			

					}
				}
			}



		}
		catch(Exception e)
		{
			logger.error("ValidateNotContainsAttribute"+e.getMessage());
			//e.printStackTrace();
		}

		return eachEntry;
	}

	public List<NotContainValidator> ValidateNotContainsValidator(Document document, Map<String, String> eachEntry, List<NotContainValidator> notContainValidatorList ,int row , String tableName,String sessionUser,Connection con)
	{
		String expressionName="/Configs/ColumnMapping/Column/Name";

		String expressionValue="/Configs/ColumnMapping/Column/Value";

		XPath xPath =  XPathFactory.newInstance().newXPath();

		Map<String, String> nameAttributePair=new LinkedHashMap<>();

		Set<String> setNameAttributePair=new LinkedHashSet<String>();

		//int actualRow = row+1;

		int actualRow = row+1;

		int startingRowNumber=0;

		try
		{
			startingRowNumber=getStartingRow(sessionUser, tableName,con);

			actualRow=actualRow+startingRowNumber;

			NodeList nodeListName=(NodeList)xPath.compile(expressionName).evaluate(document, XPathConstants.NODESET);

			NodeList nodeListValue=(NodeList)xPath.compile(expressionValue).evaluate(document, XPathConstants.NODESET);

			/* For storing Attribute value along with the name in the map*/
			for(int r=0;r<nodeListName.getLength();r++)
			{   

				Element e=(Element)nodeListValue.item(r);

				if(e.getAttribute("notContainsValidator").isEmpty())		
				{

					//System.out.println("checking for the empty attribute value***********"+e.getAttribute("notContainsValidator")+" : "+nodeListName.item(r).getFirstChild().getNodeValue());
					continue;
				}
				else
				{
					//System.out.println("checking for the not empty attribute value***********"+e.getAttribute("notContainsValidator")+" : "+nodeListName.item(r).getFirstChild().getNodeValue());
					nameAttributePair.put(nodeListName.item(r).getFirstChild().getNodeValue(), e.getAttribute("notContainsValidator"));
				}

			}

			Set<String> setEachEntry=new LinkedHashSet<String>();

			setEachEntry=eachEntry.keySet();

			setNameAttributePair=nameAttributePair.keySet();

			for(String eachEntryKey: setEachEntry)
			{
				String eachEntryValue=eachEntry.get(eachEntryKey);

				for(String nameAttributePairKey : setNameAttributePair)
				{
					String nameAttributePairValues=nameAttributePair.get(nameAttributePairKey);

					String [] nameAttributePairValue=nameAttributePairValues.split(",");

					if(eachEntryKey.equalsIgnoreCase(nameAttributePairKey) &&  !(eachEntryValue.isEmpty()))
					{
						for(int i=0;i<nameAttributePairValue.length;i++)
						{
							if(eachEntryValue.contains(nameAttributePairValue[i])      )
							{
								NotContainValidator notContainValidator = new NotContainValidator();

								notContainValidator.setAttributeValue(nameAttributePairValue[i]);

								notContainValidator.setColName(eachEntryKey);

								notContainValidator.setColValue(eachEntryValue);

								notContainValidator.setRow(actualRow);

								notContainValidator.setTableName(tableName);

								notContainValidatorList.add(notContainValidator);

							}
						}			

					}
				}
			}


		}
		catch(Exception e)
		{
			logger.error("ValidateNotContainsValidator"+e.getMessage());
			//e.printStackTrace();
		}

		return notContainValidatorList;
	}



	public Map<String, String> ValidateSubStrDelimiter(Document document , Map<String, String> eachEntry)
	{
		String expressionName="/Configs/ColumnMapping/Column/Name";

		String expressionValue="/Configs/ColumnMapping/Column/Value";

		XPath xPath =  XPathFactory.newInstance().newXPath();

		Map<String, String> nameAttributePair=new LinkedHashMap<>();

		Set<String> setNameAttributePair=new LinkedHashSet<String>();

		try
		{
			NodeList nodeListName=(NodeList)xPath.compile(expressionName).evaluate(document, XPathConstants.NODESET);

			NodeList nodeListValue=(NodeList)xPath.compile(expressionValue).evaluate(document, XPathConstants.NODESET);

			/* For storing Attribute value along with the name in the map*/
			for(int r=0;r<nodeListName.getLength();r++)
			{   

				Element e=(Element)nodeListValue.item(r);

				if(e.getAttribute("subStrDelimiter").isEmpty())		
				{

					//System.out.println("checking for the empty attribute value***********"+e.getAttribute("subStrDelimiter")+" : "+nodeListName.item(r).getFirstChild().getNodeValue());
					continue;
				}
				else
				{
					//System.out.println("checking for the not empty attribute value***********"+e.getAttribute("subStrDelimiter")+" : "+nodeListName.item(r).getFirstChild().getNodeValue());
					nameAttributePair.put(nodeListName.item(r).getFirstChild().getNodeValue(), e.getAttribute("subStrDelimiter"));
				}

			}

			Set<String> setEachEntry=new LinkedHashSet<String>();

			setEachEntry=eachEntry.keySet();

			setNameAttributePair=nameAttributePair.keySet();

			for(String eachEntryKey : setEachEntry)
			{
				String eachEntryValue=eachEntry.get(eachEntryKey);

				for(String nameAttributePairKey : setNameAttributePair)
				{
					String nameAttributePairValues= nameAttributePair.get(nameAttributePairKey);

					if(eachEntryKey.equalsIgnoreCase(nameAttributePairKey))
					{
						String [] values=nameAttributePairValues.split(",");

						String startPosition=values[0];

						String delimiter=values[1];

						if(startPosition.matches("\\d+") && delimiter.matches("[^\\dA-Za-z ]"))
						{
							if( !(eachEntryValue.length()<=   Integer.parseInt(startPosition)) && eachEntryValue.contains(delimiter))
							{

								int startPositionIndex=Integer.parseInt(startPosition);

								int delimiterIndex=eachEntryValue.indexOf(delimiter);

								String subString=eachEntryValue.substring(startPositionIndex, delimiterIndex);

								//if(subString.matches("\\d+"))
								//{
								eachEntry.put(eachEntryKey, subString);
								//}

								//eachEntry.put(eachEntryKey, subString);

							}
						}
					}



				}
			}



		}
		catch(Exception e)
		{
			logger.error("ValidateSubStrDelimiter"+e.getMessage());
			//e.printStackTrace();
		}

		return eachEntry;
	}

	public Map<String, String> ValidateContainsAttribute(Document document, Map<String, String>eachEntry )
	{
		String expressionName="/Configs/ColumnMapping/Column/Name";

		String expressionValue="/Configs/ColumnMapping/Column/Value";

		XPath xPath =  XPathFactory.newInstance().newXPath();

		Map<String, String> nameAttributePair=new LinkedHashMap<>();

		Set<String> setNameAttributePair=new LinkedHashSet<String>();


		try
		{
			NodeList nodeListName=(NodeList)xPath.compile(expressionName).evaluate(document, XPathConstants.NODESET);

			NodeList nodeListValue=(NodeList)xPath.compile(expressionValue).evaluate(document, XPathConstants.NODESET);

			/* For storing Attribute value along with the name in the map*/
			for(int r=0;r<nodeListName.getLength();r++)
			{   

				Element e=(Element)nodeListValue.item(r);

				if(e.getAttribute("contains").isEmpty())		
				{

					//System.out.println("checking for the empty attribute value***********"+e.getAttribute("contains")+" : "+nodeListName.item(r).getFirstChild().getNodeValue());
					continue;
				}
				else
				{
					//System.out.println("checking for the not empty attribute value***********"+e.getAttribute("contains")+" : "+nodeListName.item(r).getFirstChild().getNodeValue());
					nameAttributePair.put(nodeListName.item(r).getFirstChild().getNodeValue(), e.getAttribute("contains"));
				}

			}

			Set<String> setEachEntry=new LinkedHashSet<String>();

			setEachEntry=eachEntry.keySet();

			setNameAttributePair=nameAttributePair.keySet();


			for(String eachEntryKey: setEachEntry)
			{

				String eachEntryValue=eachEntry.get(eachEntryKey);

				for(String nameAttributePairKey : setNameAttributePair)
				{
					String nameAttributePairValues=nameAttributePair.get(nameAttributePairKey);

					String [] nameAttributePairValue=nameAttributePairValues.split(",");

					if(eachEntryKey.equalsIgnoreCase(nameAttributePairKey) &&  !(eachEntryValue.isEmpty()))
					{
						String flag="false";
						for(int i=0;i<nameAttributePairValue.length;i++)
						{
							if(eachEntryValue.contains(nameAttributePairValue[i])) 
							{

								flag="true";

							}

						}

						if(flag.equalsIgnoreCase("false"))
						{
							String eachEntryValueUpdated="";

							eachEntry.put(eachEntryKey, eachEntryValueUpdated);
						}


					}
				}


			}


		}
		catch(Exception e)
		{
			logger.error("ValidateContainsAttribute"+e.getMessage());
			//e.printStackTrace();
		}

		return eachEntry;
	}

	public List<ContainsValidator> ValidateContainsValidator(Document document , Map<String, String> eachEntry, List<ContainsValidator> containsValidatorList , int row, String tableName ,String sessionUser,Connection con)
	{
		String expressionName="/Configs/ColumnMapping/Column/Name";

		String expressionValue="/Configs/ColumnMapping/Column/Value";

		XPath xPath =  XPathFactory.newInstance().newXPath();

		Map<String, String> nameAttributePair=new LinkedHashMap<>();

		Set<String> setNameAttributePair=new LinkedHashSet<String>();

		//int actualRow = row+1;

		int actualRow = row+1;

		int startingRowNumber=0;

		try
		{
			startingRowNumber=getStartingRow(sessionUser, tableName,con);

			actualRow=actualRow+startingRowNumber;


			NodeList nodeListName=(NodeList)xPath.compile(expressionName).evaluate(document, XPathConstants.NODESET);

			NodeList nodeListValue=(NodeList)xPath.compile(expressionValue).evaluate(document, XPathConstants.NODESET);

			/* For storing Attribute value along with the name in the map*/
			for(int r=0;r<nodeListName.getLength();r++)
			{   

				Element e=(Element)nodeListValue.item(r);

				if(e.getAttribute("containsValidator").isEmpty())		
				{

					//System.out.println("checking for the empty attribute value***********"+e.getAttribute("containsValidator")+" : "+nodeListName.item(r).getFirstChild().getNodeValue());
					continue;
				}
				else
				{
					//System.out.println("checking for the not empty attribute value***********"+e.getAttribute("containsValidator")+" : "+nodeListName.item(r).getFirstChild().getNodeValue());
					nameAttributePair.put(nodeListName.item(r).getFirstChild().getNodeValue(), e.getAttribute("containsValidator"));
				}

			}

			Set<String> setEachEntry=new LinkedHashSet<String>();

			setEachEntry=eachEntry.keySet();

			setNameAttributePair=nameAttributePair.keySet();

			for(String eachEntryKey: setEachEntry)
			{

				String eachEntryValue=eachEntry.get(eachEntryKey);

				for(String nameAttributePairKey : setNameAttributePair)
				{
					String nameAttributePairValues=nameAttributePair.get(nameAttributePairKey);

					String [] nameAttributePairValue=nameAttributePairValues.split(",");

					if(eachEntryKey.equalsIgnoreCase(nameAttributePairKey) &&  !(eachEntryValue.isEmpty()))
					{
						String flag="false";

						for(int i=0;i<nameAttributePairValue.length;i++)
						{
							if(eachEntryValue.contains(nameAttributePairValue[i])  ) 
							{

								flag="true";

								break;

							}


						}


						if(flag.equalsIgnoreCase("false"))
						{
							ContainsValidator containValidator = new ContainsValidator();

							containValidator.setAttributeValue(nameAttributePairValues);

							containValidator.setColName(eachEntryKey);

							containValidator.setColValue(eachEntryValue);

							containValidator.setTableName(tableName);

							containValidator.setRow(actualRow);

							containsValidatorList.add(containValidator);


						}




						/*if(flag.equalsIgnoreCase("false"))
						{



							String eachEntryValueUpdated="";

							eachEntry.put(eachEntryKey, eachEntryValueUpdated);
						}*/


					}
				}


			}



		}
		catch(Exception e)
		{
			logger.error("ValidateContainsValidator"+e.getMessage());
			//e.printStackTrace();
		}

		return containsValidatorList;
	}


	public String ValidateColumnTailString(String colNames , String value, Document document , String key)
	{
		String expressionName="/Configs/ColumnMapping/Column/Name";

		String expressionValue="/Configs/ColumnMapping/Column/Value";

		XPath xPath =  XPathFactory.newInstance().newXPath();

		Map<String, String> nameAttributePair=new LinkedHashMap<>();

		Set<String> setNameAttributePair=new LinkedHashSet<String>();


		try
		{
			NodeList nodeListName=(NodeList)xPath.compile(expressionName).evaluate(document, XPathConstants.NODESET);

			NodeList nodeListValue=(NodeList)xPath.compile(expressionValue).evaluate(document, XPathConstants.NODESET);

			/* For storing Attribute value along with the name in the map*/
			for(int r=0;r<nodeListName.getLength();r++)
			{   

				Element e=(Element)nodeListValue.item(r);

				if(e.getAttribute("columnTailString").isEmpty())		
				{

					//System.out.println("checking for the empty attribute value***********"+e.getAttribute("columnTailString")+" : "+nodeListName.item(r).getFirstChild().getNodeValue());
					continue;
				}
				else
				{
					//System.out.println("checking for the not empty attribute value***********"+e.getAttribute("columnTailString")+" : "+nodeListName.item(r).getFirstChild().getNodeValue());
					nameAttributePair.put(nodeListName.item(r).getFirstChild().getNodeValue(), e.getAttribute("columnTailString"));
				}

			}


			setNameAttributePair=nameAttributePair.keySet();

			for(String nameAttributePairKey : setNameAttributePair)
			{
				String nameAttributePairValues=nameAttributePair.get(nameAttributePairKey);


				String[] nameAttributePairValue=nameAttributePairValues.split(",");

				String colNameAttr=nameAttributePairValue[0];

				String lastDigitAttr=nameAttributePairValue[1];

				if(colNameAttr.matches("^[a-zA-Z0-9]*$") && lastDigitAttr.matches("\\d+") && nameAttributePairKey.equalsIgnoreCase(key) )
				{
					int lastDigits=Integer.parseInt(lastDigitAttr);

					if(colNameAttr.equalsIgnoreCase(colNames))
					{
						int lengthValue=value.length();

						int startPosition=lengthValue-lastDigits;

						String subStrValue=value.substring(startPosition, lengthValue);

						//System.out.println("last for digits of "+ colNameAttr+" having value as "+value+" is "+subStrValue);
						logger.debug("last for digits of "+ colNameAttr+" having value as "+value+" is "+subStrValue);
						value=subStrValue;

						return value;
					}
				}

			}





		}
		catch(Exception e)
		{  
			logger.error("ValidateColumnTailString"+e.getMessage());
			//e.printStackTrace();

		}

		return value;
	}


	public Map<String, String> ValidateDependentColumn(Document document, Map<String, String> eachEntry  )
	{
		String expressionName="/Configs/ColumnMapping/Column/Name";

		String expressionValue="/Configs/ColumnMapping/Column/Value";

		XPath xPath =  XPathFactory.newInstance().newXPath();

		Map<String, String> nameAttributePair=new LinkedHashMap<>();

		Set<String> setNameAttributePair=new LinkedHashSet<String>();

		Set<String> setEachEntry=new LinkedHashSet<>();

		setEachEntry=eachEntry.keySet();


		try
		{
			NodeList nodeListName=(NodeList)xPath.compile(expressionName).evaluate(document, XPathConstants.NODESET);

			NodeList nodeListValue=(NodeList)xPath.compile(expressionValue).evaluate(document, XPathConstants.NODESET);

			/* For storing Attribute value along with the name in the map*/
			for(int r=0;r<nodeListName.getLength();r++)
			{   

				Element e=(Element)nodeListValue.item(r);

				if(e.getAttribute("dependentCol").isEmpty())		
				{

					//System.out.println("checking for the empty attribute value***********"+e.getAttribute("dependentCol")+" : "+nodeListName.item(r).getFirstChild().getNodeValue());
					continue;
				}
				else
				{
					//System.out.println("checking for the not empty attribute value***********"+e.getAttribute("dependentCol")+" : "+nodeListName.item(r).getFirstChild().getNodeValue());
					nameAttributePair.put(nodeListName.item(r).getFirstChild().getNodeValue(), e.getAttribute("dependentCol"));
				}

			}

			setNameAttributePair=nameAttributePair.keySet();





			for(String eachEntryKey: setEachEntry)
			{

				for(String nameAttributeKey: setNameAttributePair)
				{

					String nameAttributeValue=nameAttributePair.get(nameAttributeKey);

					if(eachEntryKey.equalsIgnoreCase(nameAttributeValue))
					{
						String eachEntryValue=eachEntry.get(eachEntryKey);

						if(eachEntryValue.equalsIgnoreCase(""))
						{
							eachEntry.put(nameAttributeKey, eachEntryValue);

							//System.out.println("value of "+nameAttributeKey+" is updated to "+eachEntryValue+" as the value of "+nameAttributeValue+" was this: "+eachEntryValue);

							logger.debug("value of "+nameAttributeKey+" is updated to "+eachEntryValue+" as the value of "+nameAttributeValue+" was this: "+eachEntryValue);
						}
					}


				}



			}







			/*		for(String nameValueDupKey: setNameValuePairDup)	
			{
				String nameValueDupValue= nameValuePairDup.get(nameValueDupKey);
				for(String nameAttributePairKey: setNameAttributePair)
				{
					String nameAttributePairValue=nameAttributePair.get(nameAttributePairKey);
					if(nameValueDupValue.equalsIgnoreCase(nameAttributePairValue))
					{
						replacedValue=eachEntry.get(nameValueDupKey);

						if (replacedValue.equalsIgnoreCase("")) 
						{
							eachEntry.put(nameAttributePairKey, replacedValue);

							System.out.println("value of "+nameAttributePairKey+" is updated to "+replacedValue+" as the value of "+nameAttributePairValue+" was this: "+replacedValue);
						}
					}
				}

			}*/





		}
		catch(Exception e)
		{
			logger.error("ValidateDependentColumn"+e.getMessage());
			//e.printStackTrace();
		}

		return eachEntry;
	}


	public List<String> checkTagName(String attributeName , Document document)
	{
		String expressionName="/Configs/ColumnMapping/Column/Name";

		String expressionValue="/Configs/ColumnMapping/Column/Value";

		XPath xPath =  XPathFactory.newInstance().newXPath();

		List<String> nameTags=new ArrayList<>();

		try
		{
			NodeList nodeListName=(NodeList)xPath.compile(expressionName).evaluate(document, XPathConstants.NODESET);

			NodeList nodeListValue=(NodeList)xPath.compile(expressionValue).evaluate(document, XPathConstants.NODESET);

			/* For storing Attribute value along with the name in the map*/
			for(int r=0;r<nodeListName.getLength();r++)
			{   

				Element e=(Element)nodeListValue.item(r);

				if(e.getAttribute(attributeName).isEmpty())		
				{


					continue;
				}
				else
				{



					nameTags.add(nodeListName.item(r).getFirstChild().getNodeValue());
				}

			}
		}
		catch(Exception e)
		{
			logger.error("checkTagName"+e.getMessage());
			//e.printStackTrace();

		}

		return nameTags;
	}


	public Map<String, String> ValidateIfEmptyIgnoreRow(Document document , Map<String, String> eachEntry)
	{
		String expressionName="/Configs/ColumnMapping/Column/Name";

		String expressionValue="/Configs/ColumnMapping/Column/Value";

		XPath xPath =  XPathFactory.newInstance().newXPath();

		Map<String, String> nameAttributePair=new LinkedHashMap<>();

		try
		{
			NodeList nodeListName=(NodeList)xPath.compile(expressionName).evaluate(document, XPathConstants.NODESET);

			NodeList nodeListValue=(NodeList)xPath.compile(expressionValue).evaluate(document, XPathConstants.NODESET);

			/* For storing Attribute value along with the name in the map*/
			for(int r=0;r<nodeListName.getLength();r++)
			{   

				Element e=(Element)nodeListValue.item(r);

				if(e.getAttribute("ifEmptyIgnoreRow").isEmpty())		
				{

					//System.out.println("checking for the empty attribute value***********"+e.getAttribute("ifEmptyIgnoreRow")+" : "+nodeListName.item(r).getFirstChild().getNodeValue());
					continue;
				}
				else
				{
					//System.out.println("checking for the not empty attribute value***********"+e.getAttribute("ifEmptyIgnoreRow")+" : "+nodeListName.item(r).getFirstChild().getNodeValue());
					nameAttributePair.put(nodeListName.item(r).getFirstChild().getNodeValue(), e.getAttribute("ifEmptyIgnoreRow"));
				}

			}

			Set<String> setNameAttributePair=new LinkedHashSet<>();

			Set<String> setEachEntry=new LinkedHashSet<>();

			setNameAttributePair=nameAttributePair.keySet();

			setEachEntry=eachEntry.keySet();


			eachEntryLoop:

				for(String eachEntryKey : setEachEntry)
				{
					String eachEntryValue = eachEntry.get(eachEntryKey);

					for(String nameAttributeKey : setNameAttributePair)
					{

						String nameAttributeValue = nameAttributePair.get(nameAttributeKey);

						if(nameAttributeKey.equalsIgnoreCase(eachEntryKey) && eachEntryValue.equalsIgnoreCase(""))
						{
							if(nameAttributeValue.equalsIgnoreCase("yes"))
							{
								eachEntry.clear();
								break eachEntryLoop;
							}
						}

					}



				}


		}
		catch(Exception e)
		{
			logger.error("ValidateIfEmptyIgnoreRow"+e.getMessage());
			//e.printStackTrace();
		}

		return eachEntry;

	}

	public List<NotEmptyAttribute> ValidateNotEmpty(Document document , Map<String, String> eachEntry, String tableName , int row, List<NotEmptyAttribute> notEmptyAttributeList,String sessionUser,Connection con)
	{
		String expressionName="/Configs/ColumnMapping/Column/Name";

		String expressionValue="/Configs/ColumnMapping/Column/Value";

		XPath xPath =  XPathFactory.newInstance().newXPath();

		Map<String, String> nameAttributePair=new LinkedHashMap<>();

		//int actualRow = row+1;

		int actualRow = row+1;

		int startingRowNumber=0;

		try
		{

			startingRowNumber=getStartingRow(sessionUser, tableName,con);

			actualRow=actualRow+startingRowNumber;

			NodeList nodeListName=(NodeList)xPath.compile(expressionName).evaluate(document, XPathConstants.NODESET);

			NodeList nodeListValue=(NodeList)xPath.compile(expressionValue).evaluate(document, XPathConstants.NODESET);

			/* For storing Attribute value along with the name in the map*/
			for(int r=0;r<nodeListName.getLength();r++)
			{   

				Element e=(Element)nodeListValue.item(r);

				if(e.getAttribute("notEmpty").isEmpty())		
				{

					//System.out.println("checking for the empty attribute value***********"+e.getAttribute("notEmpty")+" : "+nodeListName.item(r).getFirstChild().getNodeValue());
					continue;
				}
				else
				{
					//System.out.println("checking for the not empty attribute value***********"+e.getAttribute("notEmpty")+" : "+nodeListName.item(r).getFirstChild().getNodeValue());
					nameAttributePair.put(nodeListName.item(r).getFirstChild().getNodeValue(), e.getAttribute("notEmpty"));
				}

			}

			Set<String> setNameAttributePair=new LinkedHashSet<>();

			Set<String> setEachEntry=new LinkedHashSet<>();

			setNameAttributePair=nameAttributePair.keySet();

			setEachEntry=eachEntry.keySet();


			eachEntryLoop:

				for(String eachEntryKey : setEachEntry)
				{
					String eachEntryValue = eachEntry.get(eachEntryKey);

					for(String nameAttributeKey : setNameAttributePair)
					{

						String nameAttributeValue = nameAttributePair.get(nameAttributeKey);

						if(nameAttributeKey.equalsIgnoreCase(eachEntryKey) && eachEntryValue.equalsIgnoreCase(""))
						{
							if(nameAttributeValue.equalsIgnoreCase("yes"))
							{
								NotEmptyAttribute notEmptyAttribute = new NotEmptyAttribute();

								notEmptyAttribute.setColName(eachEntryKey);

								notEmptyAttribute.setColValue(eachEntryValue);

								notEmptyAttribute.setRow(actualRow);

								notEmptyAttribute.setTableName(tableName);

								notEmptyAttributeList.add(notEmptyAttribute);


								break eachEntryLoop;
							}
						}

					}



				}

		}
		catch(Exception e)
		{
			logger.error("ValidateNotEmpty"+e.getMessage());
			//e.printStackTrace();
		}

		return notEmptyAttributeList;

	}

	public List<IsEmptyAttribute> ValidateIsEmpty(Document document , Map<String, String> eachEntry, String tableName , int row,List<IsEmptyAttribute> isEmptyAttributeList,String sessionUser,Connection con)
	{
		String expressionName="/Configs/ColumnMapping/Column/Name";

		String expressionValue="/Configs/ColumnMapping/Column/Value";

		XPath xPath =  XPathFactory.newInstance().newXPath();

		Map<String, String> nameAttributePair=new LinkedHashMap<>();

		//int actualRow = row+1;

		int actualRow = row+1;

		int startingRowNumber=0;

		try
		{
			startingRowNumber=getStartingRow(sessionUser, tableName,con);

			actualRow=actualRow+startingRowNumber;

			NodeList nodeListName=(NodeList)xPath.compile(expressionName).evaluate(document, XPathConstants.NODESET);

			NodeList nodeListValue=(NodeList)xPath.compile(expressionValue).evaluate(document, XPathConstants.NODESET);

			/* For storing Attribute value along with the name in the map*/
			for(int r=0;r<nodeListName.getLength();r++)
			{   

				Element e=(Element)nodeListValue.item(r);

				if(e.getAttribute("isEmpty").isEmpty())		
				{

					//System.out.println("checking for the empty attribute value***********"+e.getAttribute("isEmpty")+" : "+nodeListName.item(r).getFirstChild().getNodeValue());
					continue;
				}
				else
				{
					//System.out.println("checking for the not empty attribute value***********"+e.getAttribute("isEmpty")+" : "+nodeListName.item(r).getFirstChild().getNodeValue());
					nameAttributePair.put(nodeListName.item(r).getFirstChild().getNodeValue(), e.getAttribute("isEmpty"));
				}

			}

			Set<String> setNameAttributePair=new LinkedHashSet<>();

			Set<String> setEachEntry=new LinkedHashSet<>();

			setNameAttributePair=nameAttributePair.keySet();

			setEachEntry=eachEntry.keySet();

			eachEntryLoop:

				for(String eachEntryKey : setEachEntry)
				{
					String eachEntryValue = eachEntry.get(eachEntryKey);

					for(String nameAttributeKey : setNameAttributePair)
					{

						String nameAttributeValue = nameAttributePair.get(nameAttributeKey);

						if(nameAttributeKey.equalsIgnoreCase(eachEntryKey) && !(eachEntryValue.isEmpty()))
						{
							if(nameAttributeValue.equalsIgnoreCase("yes"))
							{
								IsEmptyAttribute isEmptyAttribute = new IsEmptyAttribute();

								isEmptyAttribute.setColName(eachEntryKey);

								isEmptyAttribute.setColValue(eachEntryValue);

								isEmptyAttribute.setRow(actualRow);

								isEmptyAttribute.setTableName(tableName);

								isEmptyAttributeList.add(isEmptyAttribute);


								break eachEntryLoop;
							}
						}

					}



				}

		}
		catch(Exception e)
		{
			logger.error("ValidateIsEmpty"+e.getMessage());
		}

		return isEmptyAttributeList;
	}




	public Map<String, String> ValidateSkipDuplicate(Document document, Map<String, String>eachEntry, List<String> valueKeyMapGetSkipDuplicateList)
	{
		String expressionName="/Configs/ColumnMapping/Column/Name";

		String expressionValue="/Configs/ColumnMapping/Column/Value";

		XPath xPath =  XPathFactory.newInstance().newXPath();

		Map<String, String> nameAttributePair=new LinkedHashMap<>();

		Set<String> setNameAttributePair=new LinkedHashSet<String>();

		try
		{
			NodeList nodeListName=(NodeList)xPath.compile(expressionName).evaluate(document, XPathConstants.NODESET);

			NodeList nodeListValue=(NodeList)xPath.compile(expressionValue).evaluate(document, XPathConstants.NODESET);

			/* For storing Attribute value along with the name in the map*/
			for(int r=0;r<nodeListName.getLength();r++)
			{   

				Element e=(Element)nodeListValue.item(r);

				if(e.getAttribute("skipDuplicate").isEmpty())		
				{

					//System.out.println("checking for the empty attribute value***********"+e.getAttribute("skipDuplicate")+" : "+nodeListName.item(r).getFirstChild().getNodeValue());
					continue;
				}
				else
				{
					//System.out.println("checking for the not empty attribute value***********"+e.getAttribute("skipDuplicate")+" : "+nodeListName.item(r).getFirstChild().getNodeValue());
					nameAttributePair.put(nodeListName.item(r).getFirstChild().getNodeValue(), e.getAttribute("skipDuplicate"));
				}

			}

			Set<String> setEachEntry=new LinkedHashSet<String>();

			setEachEntry=eachEntry.keySet();

			setNameAttributePair=nameAttributePair.keySet();

			String valueKeyMapGet="";

			eachEntryLoop:

				for(String keyMapGet:setEachEntry )
				{
					for(String keyNameAttributePair: setNameAttributePair)
					{
						if(keyMapGet.equalsIgnoreCase(keyNameAttributePair))
						{
							if(nameAttributePair.get(keyNameAttributePair).equals("yes"))
							{
								valueKeyMapGet=eachEntry.get(keyMapGet);

								if(valueKeyMapGetSkipDuplicateList.contains(valueKeyMapGet) && !(valueKeyMapGet.equalsIgnoreCase("") )   )
								{
									eachEntry.clear();
									break eachEntryLoop;
								}
								else
								{
									valueKeyMapGetSkipDuplicateList.add(valueKeyMapGet);
								}
							}
						}
					}
				}


		}
		catch(Exception e)
		{
			logger.error("ValidateSkipDuplicate"+e.getMessage());
			//e.printStackTrace();
		}

		return eachEntry;
	}






	public List<ColumnNotEmptyAttribute> ValidateColumnNotEmpty(String colName, String value , Document document , String tableName , int row , List<ColumnNotEmptyAttribute> colNotEmptyList,String sessionUser,Connection con)
	{
		String expressionName="/Configs/ColumnMapping/Column/Name";

		String expressionValue="/Configs/ColumnMapping/Column/Value";

		XPath xPath =  XPathFactory.newInstance().newXPath();

		Map<String, String> nameAttributePair=new LinkedHashMap<>();

		//int actualRow=row+1;

		int actualRow=row+1;

		int startingRowNumber=0;

		try
		{

			startingRowNumber=getStartingRow(sessionUser, tableName,con);

			actualRow=actualRow+startingRowNumber;

			NodeList nodeListName=(NodeList)xPath.compile(expressionName).evaluate(document, XPathConstants.NODESET);

			NodeList nodeListValue=(NodeList)xPath.compile(expressionValue).evaluate(document, XPathConstants.NODESET);

			/* For storing Attribute value along with the name in the map*/
			for(int r=0;r<nodeListName.getLength();r++)
			{   

				Element e=(Element)nodeListValue.item(r);

				if(e.getAttribute("columnNotEmpty").isEmpty())		
				{

					//System.out.println("checking for the empty attribute value***********"+e.getAttribute("columnNotEmpty")+" : "+nodeListName.item(r).getFirstChild().getNodeValue());
					continue;
				}
				else
				{
					//System.out.println("checking for the not empty attribute value***********"+e.getAttribute("columnNotEmpty")+" : "+nodeListName.item(r).getFirstChild().getNodeValue());
					nameAttributePair.put(nodeListName.item(r).getFirstChild().getNodeValue(), e.getAttribute("columnNotEmpty"));
				}

			}

			Set<String> setNameAttributePair=new LinkedHashSet<>();

			setNameAttributePair=nameAttributePair.keySet();







			for(String nameAttributePairKey : setNameAttributePair)
			{
				String nameAttributePairValue = nameAttributePair.get(nameAttributePairKey);

				if(nameAttributePairValue.equalsIgnoreCase(colName) && value.equalsIgnoreCase(""))
				{
					ColumnNotEmptyAttribute colNotEmpty= new ColumnNotEmptyAttribute();

					colNotEmpty.setColName(colName);

					colNotEmpty.setRow(actualRow);

					colNotEmpty.setTableName(tableName);

					colNotEmpty.setValue(value);

					colNotEmptyList.add(colNotEmpty);
				}


			}






		}
		catch(Exception e)
		{
			logger.error("ValidateColumnNotEmpty"+e.getMessage());
			//e.printStackTrace();
		}


		return colNotEmptyList;

	}

	public Map<String, String> ValidatePrefix(Document document , Map<String, String> eachEntry)
	{
		String expressionName="/Configs/ColumnMapping/Column/Name";

		String expressionValue="/Configs/ColumnMapping/Column/Value";

		XPath xPath =  XPathFactory.newInstance().newXPath();

		Map<String, String> nameAttributePair=new LinkedHashMap<>();

		Set<String> setNameAttributePair=new LinkedHashSet<String>();

		Set<String> setEachEntry=new LinkedHashSet<>();

		try
		{
			NodeList nodeListName=(NodeList)xPath.compile(expressionName).evaluate(document, XPathConstants.NODESET);

			NodeList nodeListValue=(NodeList)xPath.compile(expressionValue).evaluate(document, XPathConstants.NODESET);

			/* For storing Attribute value along with the name in the map*/
			for(int r=0;r<nodeListName.getLength();r++)
			{   

				Element e=(Element)nodeListValue.item(r);

				if(e.getAttribute("prefix").isEmpty())		
				{

					//System.out.println("checking for the empty attribute value***********"+e.getAttribute("prefix")+" : "+nodeListName.item(r).getFirstChild().getNodeValue());
					continue;
				}
				else
				{
					//System.out.println("checking for the not empty attribute value***********"+e.getAttribute("prefix")+" : "+nodeListName.item(r).getFirstChild().getNodeValue());
					nameAttributePair.put(nodeListName.item(r).getFirstChild().getNodeValue(), e.getAttribute("prefix"));
				}

			}

			setNameAttributePair=nameAttributePair.keySet();

			setEachEntry=eachEntry.keySet();


			for(String eachEntryKey: setEachEntry)
			{

				String eachEntryValue = eachEntry.get(eachEntryKey);

				for(String nameAttributePairKey : setNameAttributePair)
				{

					if(eachEntryKey.equalsIgnoreCase(nameAttributePairKey))
					{
						if(!(eachEntryValue.equalsIgnoreCase("")) )
						{
							String nameAttributePairValue= nameAttributePair.get(nameAttributePairKey);

							eachEntryValue=nameAttributePairValue+eachEntryValue;

							eachEntry.put(eachEntryKey, eachEntryValue);
						}
					}
				}

			}

		}
		catch(Exception e)
		{
			logger.error("ValidatePrefix"+e.getMessage());
			//e.printStackTrace();
		}

		return eachEntry;
	}

	public List<ConflictColAttribute> ValidateConflitCol(Document document, Map<String, String> eachEntry , int row, String tableName, List<ConflictColAttribute>conflictColList, String sessionUser , Connection con)
	{
		String expressionName="/Configs/ColumnMapping/Column/Name";

		String expressionValue="/Configs/ColumnMapping/Column/Value";

		XPath xPath =  XPathFactory.newInstance().newXPath();

		Map<String, String> nameAttributePair=new LinkedHashMap<>();

		Set<String> setNameAttributePair=new LinkedHashSet<String>();

		String conflictColValueGet="";

		//int actualRow=row+1;

		int startingRowNumber=0;

		int actualRow=row+1;

		try
		{
			startingRowNumber=getStartingRow(sessionUser, tableName,con);

			actualRow=actualRow+startingRowNumber;

			NodeList nodeListName=(NodeList)xPath.compile(expressionName).evaluate(document, XPathConstants.NODESET);

			NodeList nodeListValue=(NodeList)xPath.compile(expressionValue).evaluate(document, XPathConstants.NODESET);

			/* For storing Attribute value along with the name in the map*/
			for(int r=0;r<nodeListName.getLength();r++)
			{   

				Element e=(Element)nodeListValue.item(r);

				if(e.getAttribute("conflictCol").isEmpty())		
				{

					//System.out.println("checking for the empty attribute value***********"+e.getAttribute("conflictCol")+" : "+nodeListName.item(r).getFirstChild().getNodeValue());
					continue;
				}
				else
				{
					//System.out.println("checking for the not empty attribute value***********"+e.getAttribute("conflictCol")+" : "+nodeListName.item(r).getFirstChild().getNodeValue());
					nameAttributePair.put(nodeListName.item(r).getFirstChild().getNodeValue(), e.getAttribute("conflictCol"));
				}

			}

			Set<String> setEachEntry=new LinkedHashSet<String>();

			setEachEntry=eachEntry.keySet();

			setNameAttributePair=nameAttributePair.keySet();

			for(String eachEntryKey : setEachEntry)
			{

				String eachEntryValue= eachEntry.get(eachEntryKey);

				for(String nameAttributePairKey : setNameAttributePair)
				{
					String nameAttributePairValue= nameAttributePair.get(nameAttributePairKey);

					if(nameAttributePairKey.equalsIgnoreCase(eachEntryKey))
					{

						if( !(eachEntryValue.equalsIgnoreCase("")))
						{
							conflictColValueGet =CheckConflictColValue(nameAttributePairValue, tableName, row, sessionUser,con);

							if( !(conflictColValueGet.equalsIgnoreCase("")))
							{
								ConflictColAttribute conflictColAttribute = new ConflictColAttribute();

								conflictColAttribute.setAttributeColumn(nameAttributePairKey);

								conflictColAttribute.setColumnName(nameAttributePairValue);

								conflictColAttribute.setColumnValue(conflictColValueGet);

								conflictColAttribute.setSheetName(tableName);

								conflictColAttribute.setRow(actualRow);

								conflictColList.add(conflictColAttribute);
							}
						}
					}

				}
			}
		}
		catch(Exception e)
		{
			logger.error("ValidateConflitCol"+e.getMessage());
			//e.printStackTrace();
		}

		return conflictColList;
	}

	public String CheckConflictColValue(String conflictCol , String tableName , int row , String sessionUser,Connection con) throws SQLException
	{
		int serialNum = row+1;

		String sqlGetValue="SELECT "+ conflictCol+" FROM " +sessionUser+"_"+tableName+" WHERE SerialNumber = "+serialNum+";";

		String conflictColValue="";

		//Connection con=null;

		Statement statement=null;


		try
		{
			/*Class.forName("com.mysql.jdbc.Driver");

			con = (Connection) DriverManager.getConnection("jdbc:mysql://localhost:3306/sample","root","cisco123");

			con.setAutoCommit(true);*/

			statement=con.createStatement();

			ResultSet resultSet= statement.executeQuery(sqlGetValue);

			while(resultSet.next())
			{
				if(!(resultSet.getString(1).isEmpty()))
				{
					conflictColValue=resultSet.getString(1);
				}

			}

			/*statement.close();
			con.close();*/
		}
		catch(Exception e)
		{
			//con.close();
			logger.error("CheckConflictColValue"+e.getMessage());
			//e.printStackTrace();
		}

		finally {
			if (statement!= null) {
				try {
					statement.close();
					//System.out.println("closing statement connections");

					logger.debug("closing statement connections");

				} catch (SQLException e) { }
			}
			/*if (con != null) {
		        try {
		            con.close();
		           // System.out.println("closing all opened connections");


		            logger.debug("closing all opened connections");
		        } catch (SQLException e) { }
		    }*/
		}



		return conflictColValue;
	}

	public List<IsColSubStringAttribute> ValidateIsColSubString(Document document , Map<String, String> eachEntry , int row , String tableName , String sessionUser , List<IsColSubStringAttribute> isColSubstringList,Connection con)
	{
		String expressionName="/Configs/ColumnMapping/Column/Name";

		String expressionValue="/Configs/ColumnMapping/Column/Value";

		XPath xPath =  XPathFactory.newInstance().newXPath();

		Map<String, String> nameAttributePair=new LinkedHashMap<>();

		Set<String> setNameAttributePair=new LinkedHashSet<String>();

		String colSubstringValue="";

		//int actualRow=row+1;

		int startingRowNumber=0;

		int actualRow=row+1;

		try
		{

			startingRowNumber=getStartingRow(sessionUser, tableName,con);

			actualRow=actualRow+startingRowNumber;

			NodeList nodeListName=(NodeList)xPath.compile(expressionName).evaluate(document, XPathConstants.NODESET);

			NodeList nodeListValue=(NodeList)xPath.compile(expressionValue).evaluate(document, XPathConstants.NODESET);

			/* For storing Attribute value along with the name in the map*/
			for(int r=0;r<nodeListName.getLength();r++)
			{   

				Element e=(Element)nodeListValue.item(r);

				if(e.getAttribute("isColSubString").isEmpty())		
				{

					//System.out.println("checking for the empty attribute value***********"+e.getAttribute("isColSubString")+" : "+nodeListName.item(r).getFirstChild().getNodeValue());
					continue;
				}
				else
				{
					//System.out.println("checking for the not empty attribute value***********"+e.getAttribute("isColSubString")+" : "+nodeListName.item(r).getFirstChild().getNodeValue());
					nameAttributePair.put(nodeListName.item(r).getFirstChild().getNodeValue(), e.getAttribute("isColSubString"));
				}

			}

			Set<String> setEachEntry=new LinkedHashSet<String>();

			setEachEntry=eachEntry.keySet();

			setNameAttributePair=nameAttributePair.keySet();


			for(String eachEntryKey : setEachEntry)
			{
				String eachEntryValue = eachEntry.get(eachEntryKey);

				for(String nameAttributePairKey : setNameAttributePair)
				{
					String nameAttributePairValue = nameAttributePair.get(nameAttributePairKey);

					if(eachEntryKey.equalsIgnoreCase(nameAttributePairKey))
					{
						if(!(eachEntryValue.equalsIgnoreCase("")))
						{
							colSubstringValue=CheckColSubString(nameAttributePairValue, tableName, row, sessionUser,con);



							if(!(eachEntryValue.contains(colSubstringValue))  || (colSubstringValue.equalsIgnoreCase(""))               )
							{
								IsColSubStringAttribute isColSubStringAttribute = new IsColSubStringAttribute();

								isColSubStringAttribute.setAttributeColumn(nameAttributePairKey);

								isColSubStringAttribute.setAttributeColValue(eachEntryValue);

								isColSubStringAttribute.setColName(nameAttributePairValue);

								isColSubStringAttribute.setColValue(colSubstringValue);

								isColSubStringAttribute.setRow(actualRow);

								isColSubStringAttribute.setTableName(tableName);

								isColSubstringList.add(isColSubStringAttribute);

							}

						}
					}
				}
			}

		}
		catch(Exception e)
		{
			logger.error("ValidateIsColSubString"+e.getMessage());
			//e.printStackTrace();
		}

		return isColSubstringList;
	}

	public String CheckColSubString(String colName , String tableName , int row , String sessionUser,Connection con) throws SQLException
	{
		int serialNum = row+1;

		String sqlGetValue="SELECT "+ colName+" FROM " +sessionUser+"_"+tableName+" WHERE SerialNumber = "+serialNum+";";

		String colSubstringValue="";

		//Connection con=null;

		Statement statement=null;

		try
		{
			/*Class.forName("com.mysql.jdbc.Driver");

			 con = (Connection) DriverManager.getConnection("jdbc:mysql://localhost:3306/sample","root","cisco123");

			con.setAutoCommit(true);*/

			statement=con.createStatement();

			ResultSet resultSet= statement.executeQuery(sqlGetValue);

			while(resultSet.next())
			{
				if(!(resultSet.getString(1).isEmpty()))
				{
					colSubstringValue=resultSet.getString(1);
				}

			}

			/*statement.close();
			con.close();*/
		}
		catch(Exception e)
		{
			//con.close();
			logger.error("CheckColSubString"+e.getMessage());
			//e.printStackTrace();
		}

		finally {
			if (statement!= null) {
				try {
					statement.close();
					//System.out.println("closing statement connections");

					logger.debug("closing statement connections");

				} catch (SQLException e) { }
			}
			/*if (con != null) {
		        try {
		            con.close();
		           // System.out.println("closing all opened connections");

		            logger.debug("closing all opened connections");

		        } catch (SQLException e) { }
		    }*/
		}

		return colSubstringValue;
	}

	public Map<String, String> ValidateExcludeColumn(Document document , Map<String, String> eachEntry)
	{
		String expressionExcludeCol="/Configs/ExcludeColumn/ColumnName";

		XPath xPath =  XPathFactory.newInstance().newXPath();

		String  excludeColumn="";

		List<String> excludedCols = new ArrayList<>();

		Set<String> eachEntrySet = new LinkedHashSet<>();



		try
		{
			NodeList nodeListExcludeCol=(NodeList)xPath.compile(expressionExcludeCol).evaluate(document, XPathConstants.NODESET);

			for(int i=0;i<nodeListExcludeCol.getLength();i++)
			{

				if(!(nodeListExcludeCol.item(i).getFirstChild()==null))
				{
					excludeColumn=nodeListExcludeCol.item(i).getFirstChild().getNodeValue();

					excludedCols.add(excludeColumn);
				}
			}

			eachEntrySet= eachEntry.keySet();


			for(Iterator<Map.Entry<String, String>> it = eachEntry.entrySet().iterator(); it.hasNext(); ) 
			{
				Map.Entry<String, String> entry = it.next();

				for(String exCols : excludedCols)
				{
					if(entry.getKey().equalsIgnoreCase(exCols))
					{
						it.remove();
					}

				}




				/*  if(entry.getKey().equalsIgnoreCase(excludeColumn))
			      {
			        it.remove();
			      }*/




			}

			/*	for(String eachEntryKey : eachEntrySet)
			{
				if(eachEntryKey.equalsIgnoreCase(excludeColumn))
				{
					eachEntry.remove(eachEntryKey);
				}
			}*/

		}
		catch(Exception e)
		{
			logger.error("ValidateExcludeColumn"+e.getMessage());
			//e.printStackTrace();
		}

		return eachEntry;
	}

	public List<CheckDuplicateAttribute> ValidateCheckDuplicate(Document document , Map<String, String> eachEntry , int row , String tableName , List<CheckDuplicateAttribute> duplicateValuesList, String sessionUser,Connection con)
	{
		String expressionName="/Configs/ColumnMapping/Column/Name";

		String expressionValue="/Configs/ColumnMapping/Column/Value";

		XPath xPath =  XPathFactory.newInstance().newXPath();

		Map<String, String> nameAttributePair=new LinkedHashMap<>();

		Set<String> setNameAttributePair=new LinkedHashSet<String>();

		Set<String> setEachEntry = new LinkedHashSet<>();

		//int actualRow = row+1;
		int actualRow = row+1;

		int startingRow=0;


		try
		{

			startingRow=getStartingRow(sessionUser, tableName,con);

			actualRow=actualRow+startingRow;

			NodeList nodeListName=(NodeList)xPath.compile(expressionName).evaluate(document, XPathConstants.NODESET);

			NodeList nodeListValue=(NodeList)xPath.compile(expressionValue).evaluate(document, XPathConstants.NODESET);

			for(int r=0;r<nodeListName.getLength();r++)
			{   

				Element e=(Element)nodeListValue.item(r);

				if(e.getAttribute("checkDuplicate").isEmpty())		
				{

					//System.out.println("checking for the empty attribute value***********"+e.getAttribute("checkDuplicate")+" : "+nodeListName.item(r).getFirstChild().getNodeValue());
					continue;
				}
				else
				{
					//System.out.println("checking for the not empty attribute value***********"+e.getAttribute("checkDuplicate")+" : "+nodeListName.item(r).getFirstChild().getNodeValue());
					nameAttributePair.put(nodeListName.item(r).getFirstChild().getNodeValue(), e.getAttribute("checkDuplicate"));
				}

			}

			setNameAttributePair = nameAttributePair.keySet();

			setEachEntry = eachEntry.keySet();

			for(String eachEntryKey : setEachEntry)
			{

				String eachEntryValue = eachEntry.get(eachEntryKey);

				for(String nameAttributePairKey : setNameAttributePair)
				{

					String nameAttributePairValue = nameAttributePair.get(nameAttributePairKey);

					if(eachEntryKey.equalsIgnoreCase(nameAttributePairKey) && nameAttributePairValue.equalsIgnoreCase("yes"))
					{
						CheckDuplicateAttribute checkDupAttribute = new CheckDuplicateAttribute();

						checkDupAttribute.setColName(eachEntryKey);

						checkDupAttribute.setColValue(eachEntryValue);

						checkDupAttribute.setRow(actualRow);

						checkDupAttribute.setTableName(tableName);

						duplicateValuesList.add(checkDupAttribute);
					}
				}
			}


		}
		catch(Exception e)
		{
			logger.error("ValidateCheckDuplicate"+e.getMessage());
			//e.printStackTrace();
		}

		return duplicateValuesList;
	}


	public List<CheckDuplicateAttribute> FindDuplicateYes(List<CheckDuplicateAttribute> duplicateValuesList)
	{
		List<String> dupColVal = new ArrayList<>();

		List<CheckDuplicateAttribute> dupValList = new ArrayList<>();

		try
		{

			for(CheckDuplicateAttribute obj : duplicateValuesList)
			{
				String colVal = obj.getColValue();

				dupColVal.add(colVal);

			}


			for( CheckDuplicateAttribute obj : duplicateValuesList)
			{
				int count = 0;

				String colValue = obj.getColValue();

				for(String val : dupColVal)
				{
					if(colValue.equalsIgnoreCase(val))
					{
						count++;
					}


				}

				if(!(count>1))
				{
					CheckDuplicateAttribute obj1 = new CheckDuplicateAttribute();

					obj1.setColName(obj.getColName());

					obj1.setColValue(obj.getColValue());

					obj1.setRow(obj.getRow());

					obj1.setTableName(obj.getTableName());

					dupValList.add(obj1);
				}

			}

		}
		catch(Exception e)
		{
			logger.error("FindDuplicateYes"+e.getMessage());
		}


		return dupValList;




	}

	public List<IsNumberAttribute> ValidateNumberAttribute(Document document , Map<String, String> eachEntry , int row , String tableName , List<IsNumberAttribute> isNumberObjList , String sessionUser,Connection con)
	{
		String expressionName="/Configs/ColumnMapping/Column/Name";

		String expressionValue="/Configs/ColumnMapping/Column/Value";

		XPath xPath =  XPathFactory.newInstance().newXPath();

		Map<String, String> nameAttributePair=new LinkedHashMap<>();

		Set<String> setNameAttributePair=new LinkedHashSet<String>();

		Set<String> setEachEntry = new LinkedHashSet<>();

		//int actualRow = row+1;

		int startingRowNumber=0;


		int actualRow = row+1;

		try
		{

			startingRowNumber=getStartingRow(sessionUser, tableName,con);

			actualRow=actualRow+startingRowNumber;

			NodeList nodeListName=(NodeList)xPath.compile(expressionName).evaluate(document, XPathConstants.NODESET);

			NodeList nodeListValue=(NodeList)xPath.compile(expressionValue).evaluate(document, XPathConstants.NODESET);

			for(int r=0;r<nodeListName.getLength();r++)
			{   

				Element e=(Element)nodeListValue.item(r);

				if(e.getAttribute("isNumber").isEmpty())		
				{

					//System.out.println("checking for the empty attribute value***********"+e.getAttribute("isNumber")+" : "+nodeListName.item(r).getFirstChild().getNodeValue());
					continue;
				}
				else
				{
					//System.out.println("checking for the not empty attribute value***********"+e.getAttribute("isNumber")+" : "+nodeListName.item(r).getFirstChild().getNodeValue());
					nameAttributePair.put(nodeListName.item(r).getFirstChild().getNodeValue(), e.getAttribute("isNumber"));
				}

			}

			setNameAttributePair = nameAttributePair.keySet();

			setEachEntry = eachEntry.keySet();

			for(String eachEntryKey : setEachEntry)
			{
				String eachEntryValue= eachEntry.get(eachEntryKey);

				for(String nameAttributePairKey : setNameAttributePair)
				{
					String nameAttributePairValue = nameAttributePair.get(nameAttributePairKey);

					if(eachEntryKey.equalsIgnoreCase(nameAttributePairKey) && nameAttributePairValue.equalsIgnoreCase("yes")  )
					{
						if(!(eachEntryValue.isEmpty()))
						{
							if(!(eachEntryValue.matches("\\d+")))
							{
								IsNumberAttribute isNumberAttr = new IsNumberAttribute();

								isNumberAttr.setColName(eachEntryKey);

								isNumberAttr.setColValue(eachEntryValue);

								isNumberAttr.setRow(actualRow);

								isNumberAttr.setTableName(tableName);

								isNumberObjList.add(isNumberAttr);
							}
						}

					}

				}
			}



		}
		catch(Exception e)
		{
			logger.error("ValidateNumberAttribute"+e.getMessage());
		}

		return isNumberObjList;

	}

	public int getStartingRow(String sessionUser , String tableName,Connection con) throws SQLException
	{
		String sqlGetValue="SELECT startingrow FROM " +sessionUser+"_sheetnames WHERE  sheetnametables  = '"+sessionUser+"_"+tableName+"';";

		int startingRowNumber=0;

		//Connection con= null;
		Statement statement=null;



		try
		{
			/*Class.forName("com.mysql.jdbc.Driver");

			con = (Connection) DriverManager.getConnection("jdbc:mysql://localhost:3306/sample","root","cisco123");

			con.setAutoCommit(true);*/

			statement=con.createStatement();

			ResultSet resultSet= statement.executeQuery(sqlGetValue);

			while(resultSet.next())
			{
				if(!(resultSet.getString(1).isEmpty()))
				{
					startingRowNumber=resultSet.getInt(1);
				}

			}
			/*statement.close();
			con.close();*/
		}
		catch(Exception e)
		{
			//con.close();
			logger.error("getStartingRow"+e.getMessage());
			//e.printStackTrace();
		}
		finally {
			if (statement!= null) {
				try {
					statement.close();
					//  System.out.println("closing statement connections");

					logger.debug("closing statement connections");

				} catch (SQLException e) { }
			}
			/*if (con != null) {
		        try {
		            con.close();
		          // System.out.println("closing all opened connections");

		            logger.debug("closing all opened connections");

		        } catch (SQLException e) { }
		    }*/
		}


		//System.out.println("row number is "+startingRowNumber);

		return startingRowNumber;


	}


	public String generateHeader(Document document, Document documentCommon)
	{
		String time="";

		String IPAddress="";

		String CCM="";

		String file="";

		String headerMsg="";

		String expressionUTCIPAddress="/Configs/HeaderConfigs/IPAddress";

		String expressionCCMmaster="/Configs/HeaderConfigs/CCM";

		String expressionFile="/Configs/HeaderConfigs/File";

		XPath xPath =  XPathFactory.newInstance().newXPath();

		Date dNow = new Date( );

		SimpleDateFormat ft =  new SimpleDateFormat ("MMM dd,yyyy  hh:mm:ss a ");

		time=ft.format(dNow).toString();

		try
		{
			NodeList nodeListUTCIPAddress=(NodeList)xPath.compile(expressionUTCIPAddress).evaluate(documentCommon, XPathConstants.NODESET);

			NodeList nodeListCCM=(NodeList)xPath.compile(expressionCCMmaster).evaluate(documentCommon, XPathConstants.NODESET);

			NodeList nodeListFile=(NodeList)xPath.compile(expressionFile).evaluate(document, XPathConstants.NODESET);

			/* For getting the value of tag UTCIPAddress*/

			for(int k=0;k<nodeListUTCIPAddress.getLength();k++)
			{
				if(!(nodeListUTCIPAddress.item(k).getFirstChild()==null))
				{
					IPAddress=nodeListUTCIPAddress.item(k).getFirstChild().getNodeValue();
				}

			}

			/* For getting the value of tag CCMmaster*/

			for(int k=0;k<nodeListCCM.getLength();k++)
			{
				if(!(nodeListCCM.item(k).getFirstChild()==null))
				{
					CCM=nodeListCCM.item(k).getFirstChild().getNodeValue();
				}

			}

			/* For getting the value of tag File*/

			for(int k=0;k<nodeListFile.getLength();k++)
			{
				if(!(nodeListFile.item(k).getFirstChild()==null))
				{
					file=nodeListFile.item(k).getFirstChild().getNodeValue();
				}

			}

			headerMsg="Time : "+time+"UTC IP Address : "+IPAddress+"CCM : master-"+CCM+"File : "+file;

			if(IPAddress.isEmpty() && CCM.isEmpty() && file.isEmpty())
			{
				headerMsg="";

			}
			else
			{
				headerMsg="Time : "+time+"UTC ;IP Address : "+IPAddress+";CCM : "+CCM+";File : "+file;


			}

			//System.out.println(headerMsg);

			logger.debug(headerMsg);

		}
		catch(Exception e)
		{
			logger.error("generateHeader"+e.getMessage());
		}

		return headerMsg;
	}

	public String generateFileName(Document document)
	{
		String file="";

		String expressionFile="/Configs/HeaderConfigs/File";

		XPath xPath =  XPathFactory.newInstance().newXPath();

		try
		{
			NodeList nodeListFile=(NodeList)xPath.compile(expressionFile).evaluate(document, XPathConstants.NODESET);

			/* For getting the value of tag File*/

			for(int k=0;k<nodeListFile.getLength();k++)
			{
				if(!(nodeListFile.item(k).getFirstChild()==null))
				{
					file=nodeListFile.item(k).getFirstChild().getNodeValue();
				}

			}
		}
		catch(Exception e)
		{
			logger.error("generateFileName"+e.getMessage());
		}

		return file;
	}

	public String testMethod()
	{
		String message="";
		if(true)
		{
			message="something returned from testMethod ";
		}

		return message;
	}


	public int getCountOfTables(String sheetName , Connection con, String sessionUser,String dbSuffix)
	{
		int countFinal =0;

		int count=0;

		String query="SELECT count(*) FROM " +sessionUser+"_sheetnames WHERE sheetnametables LIKE'"+sessionUser+"_"+sheetName+dbSuffix+"%';";

		Statement statement=null;

		try {

			statement = con.createStatement();

			logger.debug("Opening connections");

			logger.debug("Opening statement connections");

			ResultSet result = statement.executeQuery(query);
			while(result.next())
			{
				count=result.getInt(1);
			}
			//System.out.println("size of the uploaded table in db is  ***"+size);


			statement.close();
			//con.close();
		} 
		catch (Exception e1) {
			// TODO Auto-generated catch block

			logger.error("Number of the tables from same sessionUser"+e1.getMessage());
		} 

		finally
		{
			if (statement!= null) {
				try {
					statement.close();
					logger.debug("closing statement connections");

				} catch (SQLException e) { }
			}

		}

		if(!(dbSuffix.isEmpty()))
		{
			countFinal=count+1;

			return countFinal;
		}



		logger.info("Number of the tables from same sessionUser ***"+countFinal);

		return count;
		//return count;
	}

	public String getDbSuffix(String sessionUser)
	{
		String xmlConfigFilePath="";

		Properties props=new Properties();

		String dbSuffix="";

		try
		{
			/*Getting the hostName*/
			InetAddress ip;
			String hostname;
			ip = InetAddress.getLocalHost();
			hostname = ip.getHostName();

			/*For reading the config properties*/
			String propsName="/config.properties";
			InputStream inputStr = this.getClass().getResourceAsStream(propsName);
			props.load(inputStr);

			if(hostname.equalsIgnoreCase("DJHALANI-80MH9"))
			{
				Set<Object> configKeys=props.keySet();

				for(Object obj:configKeys)
				{
					String configKey=(String)obj;

					if(configKey.equalsIgnoreCase("filePath_local"))
					{

						String pathName=props.getProperty(configKey);

						xmlConfigFilePath=pathName+"xml-configs";

					}

				}
			}
			else
			{
				xmlConfigFilePath=props.getProperty("filePath_server")+"xml-configs";

			}

			File mastersheets = new File(xmlConfigFilePath+"/"+sessionUser+"_"+"master_sheet_info.xml");

			DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
			DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
			Document doc = dBuilder.parse(mastersheets);
			doc.getDocumentElement().normalize();

			NodeList sList = doc.getElementsByTagName("Sheets");
			for (int s = 0; s<sList.getLength(); s++) 
			{
				Node nodes = sList.item(s);
				if (nodes.getNodeType() == Node.ELEMENT_NODE)
				{
					Element ele = (Element) nodes;

					NodeList dbSub = ele.getElementsByTagName("dbSuffix");

					dbSuffix =dbSub.item(0).getChildNodes().item(0).getNodeValue();

					//System.out.println("db suffix:"+dbSuffix);
				}
			}

		}
		catch(Exception e)
		{
			logger.error(e.getMessage());
		}

		return dbSuffix;
	}


	public String getSuffixedTableNames( String sheetName , String dbSuffix , int count, int countMax)
	{
		String tableName="";

		try
		{

			int countDbSuffix=countMax-count;

			if(countDbSuffix==0)
			{
				tableName=sheetName;

			}
			else
			{
				tableName=sheetName+dbSuffix+countDbSuffix+"";
			}

			logger.info("Table name while using suffix is *****"+tableName);
		}
		catch(Exception e)
		{
			logger.error(e.getMessage());
		}

		return tableName;


	}

	public Map<String, String> ValidateDropChar(Document document , Map<String, String> eachEntry )
	{
		String expressionName="/Configs/ColumnMapping/Column/Name";

		String expressionValue="/Configs/ColumnMapping/Column/Value";

		XPath xPath =  XPathFactory.newInstance().newXPath();

		Map<String, String> nameAttributePair=new LinkedHashMap<>();

		Set<String> setNameAttributePair=new LinkedHashSet<String>();



		try
		{
			NodeList nodeListName=(NodeList)xPath.compile(expressionName).evaluate(document, XPathConstants.NODESET);

			NodeList nodeListValue=(NodeList)xPath.compile(expressionValue).evaluate(document, XPathConstants.NODESET);

			/* For storing Attribute value along with the name in the map*/
			for(int r=0;r<nodeListName.getLength();r++)
			{   

				Element e=(Element)nodeListValue.item(r);

				if(e.getAttribute("dropChar").isEmpty())		
				{


					continue;
				}
				else
				{
					//System.out.println("checking for the not empty attribute value***********"+e.getAttribute("dropChar")+" : "+nodeListName.item(r).getFirstChild().getNodeValue());
					nameAttributePair.put(nodeListName.item(r).getFirstChild().getNodeValue(), e.getAttribute("dropChar"));
				}

			}

			setNameAttributePair=nameAttributePair.keySet();

			for(String keyNameAttributePair: setNameAttributePair)
			{
				if(!(keyNameAttributePair.isEmpty()))
				{
					String valueNameAttributePair=nameAttributePair.get(keyNameAttributePair);

					String eachEntryValue=eachEntry.get(keyNameAttributePair);

					int valueNameAttributePairInt=Integer.parseInt(valueNameAttributePair)-1;

					int eachEntryValueLength=eachEntryValue.length();

					if(valueNameAttributePairInt>=0 && valueNameAttributePairInt<eachEntryValueLength)
					{
						/*for(int i=0;i<eachEntryValueLength;i++)
						{
							if(i==valueNameAttributePairInt)
							{
								char a= eachEntryValue.charAt(valueNameAttributePairInt);
								//eachEntryValue=eachEntryValue.replace(String.valueOf(a), "");
								eachEntryValue.replaceFirst(String.valueOf(a), "");
							}
						}*/

						String eachEntryValuePart1=eachEntryValue.substring(0, valueNameAttributePairInt);

						String eachEntryValuePart2=eachEntryValue.substring(valueNameAttributePairInt+1, eachEntryValueLength);

						String eachEntryValueModified=eachEntryValuePart1+eachEntryValuePart2;



						int eachEntryValueLengthRep=eachEntryValueModified.length();

						eachEntry.put(keyNameAttributePair, eachEntryValueModified);
					}


				}
			}


		}
		catch(Exception e)
		{
			logger.error("ValidateDropChar"+e.getMessage());
		}

		return eachEntry;


	}

	public List<Map<String, String>> ValidateHandleList(Document document ,List<Map<String, String>> masterMap)
	{
		String expressionName="/Configs/ColumnMapping/Column/Name";

		String expressionValue="/Configs/ColumnMapping/Column/Value";

		XPath xPath =  XPathFactory.newInstance().newXPath();

		Map<String, String> nameAttributePair=new LinkedHashMap<>();

		Set<String> setNameAttributePair=new LinkedHashSet<String>();

		List<Map<String, String>> masterMapCopy=new ArrayList<>();



		masterMapCopy.addAll(masterMap);

		try
		{
			NodeList nodeListName=(NodeList)xPath.compile(expressionName).evaluate(document, XPathConstants.NODESET);

			NodeList nodeListValue=(NodeList)xPath.compile(expressionValue).evaluate(document, XPathConstants.NODESET);

			/* For storing Attribute value along with the name in the map*/
			for(int r=0;r<nodeListName.getLength();r++)
			{   

				Element e=(Element)nodeListValue.item(r);

				if(e.getAttribute("handleList").isEmpty())		
				{


					continue;
				}
				else
				{
					//System.out.println("checking for the not empty attribute value***********"+e.getAttribute("handleList")+" : "+nodeListName.item(r).getFirstChild().getNodeValue());
					nameAttributePair.put(nodeListName.item(r).getFirstChild().getNodeValue(), e.getAttribute("handleList"));
				}

			}

			setNameAttributePair=nameAttributePair.keySet();



			for(Map<String, String> eachMap:masterMap)
			{
				for(String keyNameAttributePair: setNameAttributePair)
				{
					Map<String, String> keyValueGet = new LinkedHashMap<>();

					String valueNameAttributePair = nameAttributePair.get(keyNameAttributePair);

					String eachMapKeyValue=eachMap.get(keyNameAttributePair);

					keyValueGet=GetHandleListAttrValue(valueNameAttributePair, eachMap);

					Set<String> setEachMap=new LinkedHashSet<String>();

					setEachMap=eachMap.keySet();

					if(eachMapKeyValue.contains(","))
					{
						/*int indexOfComma=eachMapKeyValue.indexOf(",");

						String valuePart1=eachMapKeyValue.substring(0, indexOfComma);

						String valuePart2=eachMapKeyValue.substring(indexOfComma+1,eachMapKeyValue.length());*/


						String valueSeperatedComma [] = eachMapKeyValue.split(",");

						int count=1;

						String flag="true";

						for(String value :valueSeperatedComma)
						{
							if(count==1)
							{
								eachMap.put(keyNameAttributePair, value);
								count=count+1;
							}
							else
							{
								Map<String, String> newMap = new LinkedHashMap<>();

								for(String key:setEachMap)
								{


									for(String keyOfKeyValue: keyValueGet.keySet())
									{
										if(key.equalsIgnoreCase(keyOfKeyValue))
										{
											String valueWithInc=keyValueGet.get(key)+count;

											newMap.put(key, valueWithInc);
											count=count+1;

											flag="false";
										}
									}
									if(key.equalsIgnoreCase(keyNameAttributePair))
									{
										newMap.put(key, value);
									}
									else
									{
										if(flag.equalsIgnoreCase("true"))
										{
											newMap.put(key, eachMap.get(key));
										}
									}
								}

								masterMapCopy.add(newMap);
							}


						}


					}


				}
			}

			System.out.println("size os master map"+masterMap.size());

			System.out.println("size of master map copy"+masterMapCopy.size());


		}
		catch(Exception e)
		{
			logger.error("ValidateHandleList"+e.getMessage());
		}

		return masterMapCopy;

	}

	public Map<String, String> GetHandleListAttrValue(String value,Map<String, String> eachMap)
	{
		String valueOfAttr="";

		Set<String> setEachMap=new LinkedHashSet<String>();

		setEachMap=eachMap.keySet();

		Map<String, String> keyValue=new LinkedHashMap<>();

		for(String key:setEachMap)
		{
			String keyInLower=key.toLowerCase().replaceAll(" ", "");

			String valueInLower=value.toLowerCase().replaceAll(" ", "");

			if(keyInLower.equalsIgnoreCase(valueInLower))
			{
				valueOfAttr=eachMap.get(key);

				keyValue.put(key, valueOfAttr);

			}
		}


		return keyValue;
	}

	public List<DependentColumnValidator> ValidateDependentColumnValidator(Document document, Map<String, String> eachEntry, List<DependentColumnValidator> dependentColList ,int row , String tableName,String sessionUser,Connection con)
	{
		String expressionName="/Configs/ColumnMapping/Column/Name";

		String expressionValue="/Configs/ColumnMapping/Column/Value";

		XPath xPath =  XPathFactory.newInstance().newXPath();

		Map<String, String> nameAttributePair=new LinkedHashMap<>();

		Set<String> setNameAttributePair=new LinkedHashSet<String>();

		Set<String> setEachEntry=new LinkedHashSet<>();

		setEachEntry=eachEntry.keySet();


		int actualRow = row+1;

		int startingRowNumber=0;


		try
		{
			startingRowNumber=getStartingRow(sessionUser, tableName,con);

			actualRow=actualRow+startingRowNumber;

			NodeList nodeListName=(NodeList)xPath.compile(expressionName).evaluate(document, XPathConstants.NODESET);

			NodeList nodeListValue=(NodeList)xPath.compile(expressionValue).evaluate(document, XPathConstants.NODESET);

			/* For storing Attribute value along with the name in the map*/
			for(int r=0;r<nodeListName.getLength();r++)
			{   

				Element e=(Element)nodeListValue.item(r);

				if(e.getAttribute("dependentColValidator").isEmpty())		
				{

					//System.out.println("checking for the empty attribute value***********"+e.getAttribute("dependentColValidator")+" : "+nodeListName.item(r).getFirstChild().getNodeValue());
					continue;
				}
				else
				{
					//System.out.println("checking for the not empty attribute value***********"+e.getAttribute("dependentColValidator")+" : "+nodeListName.item(r).getFirstChild().getNodeValue());
					nameAttributePair.put(nodeListName.item(r).getFirstChild().getNodeValue(), e.getAttribute("dependentColValidator"));
				}

			}

			setNameAttributePair=nameAttributePair.keySet();

			for(String eachEntryKey: setEachEntry)
			{

				for(String nameAttributeKey: setNameAttributePair)
				{

					String nameAttributeValue=nameAttributePair.get(nameAttributeKey);

					if(eachEntryKey.equalsIgnoreCase(nameAttributeValue))
					{
						String eachEntryValue=eachEntry.get(eachEntryKey);

						if(eachEntryValue.equalsIgnoreCase("")|| eachEntryValue.isEmpty())
						{
							//eachEntry.put(nameAttributeKey, eachEntryValue);

							//System.out.println("value of "+nameAttributeKey+" is updated to "+eachEntryValue+" as the value of "+nameAttributeValue+" was this: "+eachEntryValue);

							logger.debug("value of "+nameAttributeKey+" is updated to "+eachEntryValue+" as the value of "+nameAttributeValue+" was this: "+eachEntryValue);

							DependentColumnValidator dependentColValidator = new DependentColumnValidator();

							dependentColValidator.setAttributeValue(nameAttributeValue);

							dependentColValidator.setColName(nameAttributeKey);

							//dependentColValidator.setColValue(eachEntryValue);

							dependentColValidator.setRow(actualRow);

							dependentColValidator.setTableName(tableName);

							dependentColList.add(dependentColValidator);
						}
					}


				}



			}




		}
		catch(Exception e)
		{
			logger.error("ValidateDependentColumnValidator"+e.getMessage());
		}

		return dependentColList;

	}
	
	public Map<String, String> ValidateReplace(Document document , Map<String, String> eachEntry )
	{
		String expressionName="/Configs/ColumnMapping/Column/Name";

		String expressionValue="/Configs/ColumnMapping/Column/Value";

		XPath xPath =  XPathFactory.newInstance().newXPath();

		Map<String, String> nameAttributePair=new LinkedHashMap<>();

		Set<String> setNameAttributePair=new LinkedHashSet<String>();
		
		try
		{
			NodeList nodeListName=(NodeList)xPath.compile(expressionName).evaluate(document, XPathConstants.NODESET);

			NodeList nodeListValue=(NodeList)xPath.compile(expressionValue).evaluate(document, XPathConstants.NODESET);

			/* For storing Attribute value along with the name in the map*/
			for(int r=0;r<nodeListName.getLength();r++)
			{   

				Element e=(Element)nodeListValue.item(r);

				if(e.getAttribute("replace").isEmpty())		
				{


					continue;
				}
				else
				{
					//System.out.println("checking for the not empty attribute value***********"+e.getAttribute("replace")+" : "+nodeListName.item(r).getFirstChild().getNodeValue());
					nameAttributePair.put(nodeListName.item(r).getFirstChild().getNodeValue(), e.getAttribute("replace"));
				}

			}
			setNameAttributePair=nameAttributePair.keySet();
			
			for(String keyNameAttributePair: setNameAttributePair)
			{
				if(!(keyNameAttributePair.isEmpty()))
				{
					String valueNameAttributePair=nameAttributePair.get(keyNameAttributePair);
					System.out.println(valueNameAttributePair);
					
					String [] valueAttr = valueNameAttributePair.split(";");
					
					Map<String, String> keyValueReplace = new LinkedHashMap<String, String>();
					
					for(int i=0;i<valueAttr.length;i++)
					{
						String element[] = valueAttr[i].split(",");
						keyValueReplace.put(element[0], element[1]);
						
					}
					
					String eachEntryValue=eachEntry.get(keyNameAttributePair);
					
					if(eachEntryValue.isEmpty())
					{
						eachEntryValue="null";
					}
					
					Set<String> setKeyValueReplace = keyValueReplace.keySet();
					
					for(String repVal : setKeyValueReplace)
					{
						System.out.println("repVal:"+repVal);
						if(eachEntryValue.contains(repVal) || eachEntryValue.equalsIgnoreCase(repVal))
						{
							eachEntryValue=eachEntryValue.replace(repVal, keyValueReplace.get(repVal));
							break;
						}
					}
					
					System.out.println(eachEntryValue);
					eachEntry.put(keyNameAttributePair, eachEntryValue);
					
					
					

				}
			}
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		return eachEntry;

	}



}


