package com.cisco.csv.controller;

import java.io.File;
import java.io.InputStream;
import java.net.InetAddress;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.Set;

import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.xpath.XPath;
import javax.xml.xpath.XPathConstants;
import javax.xml.xpath.XPathFactory;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.Resource;
import org.springframework.core.io.support.PathMatchingResourcePatternResolver;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;

import com.cisco.csv.services.UserDaoImpl;
import com.cisco.csv.writer.ErrorWriter;
import com.cisco.csv.writer.TxtWriter;




@Controller
public class txtGeneratorController {
	
	
	private final static Logger logger = Logger.getLogger(txtGeneratorController.class);
	
	@Autowired
	UserDaoImpl userDAO;
	
	@Autowired
	TxtWriter txtWriter;
	
	@Autowired
	ErrorWriter errorWriter;
	
	@RequestMapping(value="/typeTxtGen" , params="downloadFile", method=RequestMethod.GET)
	public void txtFile(HttpServletRequest request , HttpServletResponse response,final RedirectAttributes redirectAttributes)
	{
		Authentication auth = SecurityContextHolder.getContext().getAuthentication();
		
		String sessionUser = auth.getName(); //get logged in username
		
		String type=request.getParameter("type");
		
		String fileName="";
		
		String errorFileName="";
		
		Properties props=new Properties();
		
		Document documentCommon=null;
		
		Document document=null;
		
		List<String> csvNames=new ArrayList<>();
		
		List<String> configNames=new ArrayList<>();
		
		List<Map<String, String>> listMapGet=null;
		
		List<String> message=new ArrayList<>();
		
		String xmlConfigFilePath="";
		
		String xmlConfig="xml-configs";
		
		try
		{
			
			/*Getting the hostName*/
			InetAddress ip;
			String hostname;
			ip = InetAddress.getLocalHost();
			hostname = ip.getHostName();
			
		/*For reading the config properties*/
			String propsName="/config.properties";
			InputStream inputStr = this.getClass().getResourceAsStream(propsName);
			props.load(inputStr);
			
			
			if(hostname.equalsIgnoreCase("DJHALANI-80MH9"))
			{
				Set<Object> configKeys=props.keySet();

				for(Object obj:configKeys)
				{
					String configKey=(String)obj;

					if(configKey.equalsIgnoreCase("filePath_local"))
					{

						String pathName=props.getProperty(configKey);

						xmlConfigFilePath=pathName+"xml-configs";

					}

				}
			}
			else
			{
				xmlConfigFilePath=props.getProperty("filePath_server")+xmlConfig;
				
			}
			
			
			/*For getting all the xml files from the xml-configs folder*/
			File folder = new File(xmlConfigFilePath);
			
			File[] listOfFiles = folder.listFiles();
			
			for(int i = 0; i < listOfFiles.length; i++)
			{
				String configName = listOfFiles[i].getName();
				
				if(configName.endsWith(".xml")||configName.endsWith(".XML"))
				{
					configNames.add(configName);
					
					if(configName.contains(sessionUser))
					{

						if(!(configName.contains("CommonConfig"))  )
						{
							
							
							if(!(configName.contains("master_sheet_info")   ))
							{
							
							
							
							int sizeOfUnderScore=configName.indexOf('_')+1;

							int xmlIndex1=configName.indexOf("xml")-1;

							String csvName=configName.substring(sizeOfUnderScore, xmlIndex1);
							//System.out.println("csv file name is*************"+csvName);
							logger.debug("csv file name is*************"+csvName);
							
							csvNames.add(csvName);
							
							}

						}

					}
				}
			}
			
			/*	for getting the object for commonConfig*/
			for(String ConfigFileCommon:configNames)
			{
				if(ConfigFileCommon.contains(sessionUser)&& ConfigFileCommon.contains("CommonConfig"))
				{
					
					
					DocumentBuilderFactory builderFactoryCommon = DocumentBuilderFactory.newInstance();
					DocumentBuilder builderCommon = builderFactoryCommon.newDocumentBuilder();
					XPath xPathCommon =  XPathFactory.newInstance().newXPath();
					/*ClassLoader classLoaderCommon = getClass().getClassLoader();
					File fileCommon = new File(classLoaderCommon.getResource(ConfigFileCommon).getFile());*/
					
					String filePathCommon=xmlConfigFilePath+"/"+ConfigFileCommon;
					
					File fileCommon = new File(filePathCommon);
					
					
					if(fileCommon.exists())
					{
					documentCommon = builderCommon.parse(fileCommon);
					
					String expressionCommonName="/Configs/ColumnMapping/Column/Name";
					String expressionCommonValue="/Configs/ColumnMapping/Column/Value";
					
					NodeList nodeListCommonName=(NodeList)xPathCommon.compile(expressionCommonName).evaluate(documentCommon, XPathConstants.NODESET);
					NodeList nodeListCommonValue=(NodeList)xPathCommon.compile(expressionCommonValue).evaluate(documentCommon, XPathConstants.NODESET);
					for (int i = 0; i < nodeListCommonName.getLength(); i++)
					{
						
						logger.debug("Nodes Name and values "+nodeListCommonName.item(i).getFirstChild().getNodeValue() +"  :  "+nodeListCommonValue.item(i).getFirstChild().getNodeValue());
						


					}
				
					break;
				
					}
				}
			}
			
			
			
			
			/*for getting the object for the TXT to be generated*/
			
			logger.debug("for getting the object for the Txt to be generated");
			
			for(String configFile:configNames)
			{	
					for(String csvNameType:csvNames)
				{

				if(csvNameType.equalsIgnoreCase(type))
					{
						DocumentBuilderFactory builderFactory = DocumentBuilderFactory.newInstance();
						DocumentBuilder builder = builderFactory.newDocumentBuilder();
						
						String configFileLower=configFile.toLowerCase();
						int sizeOfUnderScore=configFileLower.indexOf('_')+1;

						int xmlIndex1=configFileLower.indexOf("xml")-1;

						String xmlConfigName=configFileLower.substring(sizeOfUnderScore, xmlIndex1);
						String sessionUserLower=sessionUser.toLowerCase();
						if(configFileLower.contains(sessionUserLower)&& xmlConfigName.equalsIgnoreCase(csvNameType))

						{

							
							
							logger.debug("config file is ********"+configFile);

							/*ClassLoader classLoader = getClass().getClassLoader();
							File file = new File(classLoader.getResource(configFile).getFile());*/
							
							String filePathCsv=xmlConfigFilePath+"/"+configFile;
							
							File file = new File(filePathCsv);


							if(file.exists())
							{

								
								
								logger.debug("the xml file name is **********"+file.getName());

								 document = builder.parse(file);
								 
								 logger.debug("file is present*************");
								// logger.info("file is present*************");
								

								break;
							}
							else
							{
								logger.debug("file is not present***************");
								//logger.info("file is not present***************");
								
							}


						}


					}


				}

			}
			
		
			request.getSession().setAttribute("type", type);
			
			fileName=type+".txt";
			
			errorFileName=type+"_"+"error.log";
			
			listMapGet=userDAO.UserCsvGen(document,fileName,documentCommon,sessionUser);
			
			for(Map<String, String> messageValue: listMapGet)
			{
				Set<String> keysMessageValue= new LinkedHashSet<>();
				keysMessageValue=messageValue.keySet();
			
				for(String key:keysMessageValue)
				{
					if(key.matches("[0-9]+"))
					{
						message.add(messageValue.get(key));
					}
				}
			}
			
			
			
			if(!(message.isEmpty() ))
			{
				//redirectAttributes.addFlashAttribute("messageDisplayed",message);
				//return "redirect:/csvGen";
				//response.sendRedirect("txtGen?messageDisplayed="+message);	
				
				response.setContentType("text/csv");
				
				response.setHeader("Content-Disposition","attachment;filename="+errorFileName);
				
				ServletOutputStream out=response.getOutputStream();
				
				errorWriter.createErrFile(listMapGet,out,errorFileName);
				
				out.close();
					
			}
			else
			{
				response.setContentType("text/csv");
				//response.setHeader("Content-Disposition","attachment;filename="+csvWriter.getFileName());
				response.setHeader("Content-Disposition","attachment;filename="+fileName);
				ServletOutputStream out=response.getOutputStream();
				txtWriter.createTxt(listMapGet,out,fileName);
				out.close();
				
				
			}
			
			
			for(Map<String, String> mapGet:listMapGet)
			{
				Set<String> keys=mapGet.keySet();

				for(String key:keys)
				{


					//System.out.println(key+":"+mapGet.get(key));
					//logger.info(key+":"+mapGet.get(key));
					logger.debug(key+":"+mapGet.get(key));
				}
				//System.out.println("------------------------");
				//logger.info("------------------------------");
				
				logger.debug("------------------------------");
				
			}
			
			//message=validateAttribute(document,listMapGet);
			
			
			
		//	logger.debug("the value of message for the validation of attribute is************"+message);
			
			
		}
		catch(Exception ex)
		{
			logger.error(ex.getMessage());
			//ex.printStackTrace();
		}
		

		
		
	}
	
	
	@RequestMapping(value="/typeTxtGen" , params="saveFile", method=RequestMethod.GET)
	public String saveTxtFile(HttpServletRequest request , HttpServletResponse response,final RedirectAttributes redirectAttributes)
	{
		Authentication auth = SecurityContextHolder.getContext().getAuthentication();
		
		String sessionUser = auth.getName(); //get logged in username
		
		String type=request.getParameter("type");
		
		String fileName="";
		
		String errorFileName="";
		
		Properties props=new Properties();
		
		Document documentCommon=null;
		
		Document document=null;
		
		List<String> csvNames=new ArrayList<>();
		
		List<String> configNames=new ArrayList<>();
		
		List<Map<String, String>> listMapGet=null;
		
		List<String> message=new ArrayList<>();
		
		String xmlConfigFilePath="";
		
		String xmlConfig="xml-configs";
		
		String absolutePathError="";
		
		String absolutePathTxt="";
		
		String messageSaved="";
		
		try
		{
			/*Getting the hostName*/
			InetAddress ip;
			String hostname;
			ip = InetAddress.getLocalHost();
			hostname = ip.getHostName();
			
			/*For reading the config properties*/
			String propsName="/config.properties";
			InputStream inputStr = this.getClass().getResourceAsStream(propsName);
			props.load(inputStr);
			
			fileName=type+".txt";
			
			errorFileName=type+"_"+"error.log";
			
			if(hostname.equalsIgnoreCase("DJHALANI-80MH9"))
			{
				Set<Object> configKeys=props.keySet();

				for(Object obj:configKeys)
				{
					String configKey=(String)obj;

					if(configKey.equalsIgnoreCase("filePath_local"))
					{

						String pathName=props.getProperty(configKey);

						xmlConfigFilePath=pathName+"xml-configs";
						
						absolutePathTxt=pathName+sessionUser+"/"+fileName;
						
						absolutePathError=pathName+sessionUser+"/"+errorFileName;

					}

				}
			}
			else
			{
				xmlConfigFilePath=props.getProperty("filePath_server")+xmlConfig;
				
				absolutePathTxt=props.getProperty("filePath_server")+sessionUser+"/"+fileName;
				
				absolutePathError=props.getProperty("filePath_server")+sessionUser+"/"+errorFileName;
				
			}
			
			
			/*For getting all the xml files from the xml-configs folder*/
			File folder = new File(xmlConfigFilePath);
			
			File[] listOfFiles = folder.listFiles();
			
			for(int i = 0; i < listOfFiles.length; i++)
			{
				String configName = listOfFiles[i].getName();
				
				if(configName.endsWith(".xml")||configName.endsWith(".XML"))
				{
					configNames.add(configName);
					
					if(configName.contains(sessionUser))
					{

						if(!(configName.contains("CommonConfig"))  )
						{
							
							
							if(!(configName.contains("master_sheet_info")   ))
							{
							
							
							
							int sizeOfUnderScore=configName.indexOf('_')+1;

							int xmlIndex1=configName.indexOf("xml")-1;

							String csvName=configName.substring(sizeOfUnderScore, xmlIndex1);
							//System.out.println("csv file name is*************"+csvName);
							logger.debug("csv file name is*************"+csvName);
							
							csvNames.add(csvName);
							
							}

						}

					}
				}
			}
			
			/*	for getting the object for commonConfig*/
			for(String ConfigFileCommon:configNames)
			{
				if(ConfigFileCommon.contains(sessionUser)&& ConfigFileCommon.contains("CommonConfig"))
				{
					
					
					DocumentBuilderFactory builderFactoryCommon = DocumentBuilderFactory.newInstance();
					DocumentBuilder builderCommon = builderFactoryCommon.newDocumentBuilder();
					XPath xPathCommon =  XPathFactory.newInstance().newXPath();
					/*ClassLoader classLoaderCommon = getClass().getClassLoader();
					File fileCommon = new File(classLoaderCommon.getResource(ConfigFileCommon).getFile());*/
					
					String filePathCommon=xmlConfigFilePath+"/"+ConfigFileCommon;
					
					File fileCommon = new File(filePathCommon);
					
					
					if(fileCommon.exists())
					{
					documentCommon = builderCommon.parse(fileCommon);
					
					String expressionCommonName="/Configs/ColumnMapping/Column/Name";
					String expressionCommonValue="/Configs/ColumnMapping/Column/Value";
					
					NodeList nodeListCommonName=(NodeList)xPathCommon.compile(expressionCommonName).evaluate(documentCommon, XPathConstants.NODESET);
					NodeList nodeListCommonValue=(NodeList)xPathCommon.compile(expressionCommonValue).evaluate(documentCommon, XPathConstants.NODESET);
					for (int i = 0; i < nodeListCommonName.getLength(); i++)
					{
						
						logger.debug("Nodes Name and values "+nodeListCommonName.item(i).getFirstChild().getNodeValue() +"  :  "+nodeListCommonValue.item(i).getFirstChild().getNodeValue());
						


					}
				
					break;
				
					}
				}
			}
			
			
	/*for getting the object for the TXT to be generated*/
			
			logger.debug("for getting the object for the Txt to be generated");
			
			for(String configFile:configNames)
			{	
					for(String csvNameType:csvNames)
				{

				if(csvNameType.equalsIgnoreCase(type))
					{
						DocumentBuilderFactory builderFactory = DocumentBuilderFactory.newInstance();
						DocumentBuilder builder = builderFactory.newDocumentBuilder();
						
						String configFileLower=configFile.toLowerCase();
						int sizeOfUnderScore=configFileLower.indexOf('_')+1;

						int xmlIndex1=configFileLower.indexOf("xml")-1;

						String xmlConfigName=configFileLower.substring(sizeOfUnderScore, xmlIndex1);
						String sessionUserLower=sessionUser.toLowerCase();
						if(configFileLower.contains(sessionUserLower)&& xmlConfigName.equalsIgnoreCase(csvNameType))

						{

							
							
							logger.debug("config file is ********"+configFile);

							/*ClassLoader classLoader = getClass().getClassLoader();
							File file = new File(classLoader.getResource(configFile).getFile());*/
							
							String filePathCsv=xmlConfigFilePath+"/"+configFile;
							
							File file = new File(filePathCsv);


							if(file.exists())
							{

								
								
								logger.debug("the xml file name is **********"+file.getName());

								 document = builder.parse(file);
								 
								 logger.debug("file is present*************");
								// logger.info("file is present*************");
								

								break;
							}
							else
							{
								logger.debug("file is not present***************");
								//logger.info("file is not present***************");
								
							}


						}


					}


				}

			}
			
		listMapGet=userDAO.UserCsvGen(document,fileName,documentCommon,sessionUser);
			
			for(Map<String, String> messageValue: listMapGet)
			{
				Set<String> keysMessageValue= new LinkedHashSet<>();
				keysMessageValue=messageValue.keySet();
			
				for(String key:keysMessageValue)
				{
					if(key.matches("[0-9]+"))
					{
						message.add(messageValue.get(key));
					}
				}
			}
			
			if(!(message.isEmpty() ))
			{
				
				
			
				
				errorWriter.createErrorFileSave(listMapGet,absolutePathError);
				
				
				
				
					
			}
			else
			{
				messageSaved=txtWriter.createTxtSave(listMapGet, absolutePathTxt);
			}
			
			redirectAttributes.addFlashAttribute("messageDisplayed",messageSaved);
			
			
		}
		catch(Exception e)
		{
			logger.error(e.getMessage());
		}
		
		return "redirect:/txtGen";
	}

	
	
	
	
	
	
	
	
	

}
