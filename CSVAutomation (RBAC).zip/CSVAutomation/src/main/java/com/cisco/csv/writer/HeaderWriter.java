package com.cisco.csv.writer;


import java.io.File;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.OutputStream;








import org.apache.log4j.Logger;

public class HeaderWriter {

	private final static Logger logger = Logger.getLogger(HeaderWriter.class);

	File file=null;

	FileWriter fileWriter =null;
	public void createHeaderFile(String headerMsg, String fileName)
	{

		try
		{
			
			String [] headerArray= headerMsg.split(";");
			
			//byte[] contentInBytes = headerMsg.getBytes();

			file=new File(fileName);
			
			logger.info("Writing in the Header file");

			if (!file.exists()) {
				file.createNewFile();
			}
			else
			{
				if(file.delete())
				{
					file.createNewFile();
				}
				else
				{
					//logger.info("the file with the name "+fileNameUser+" was not deleted");
					logger.debug("the file with the name "+fileName+" was not deleted");
					//System.out.println("the file with the name "+fileNameUser+" was not deleted");
				}
			}
			
			
			fileWriter = new FileWriter(file);
			
			String osname=System.getProperty("os.name").toLowerCase();
			
			for(String header: headerArray)
			{
				
				
				fileWriter.write(header);
				if(osname.contains("windows"))
				{
				
				
				fileWriter.write("\r\n");
				}
				else if(osname.contains("linux"))
				{
					
					
					fileWriter.write("\n");
				}
				
				
				
			}





			logger.info("Header file is created");

			

			fileWriter.flush();

			fileWriter.close();
		}
		catch(Exception e)
		{
			logger.error(e.getMessage());
		}

		finally
		{
			try {
				if (fileWriter != null)
				{
					fileWriter.close();
				}
			} catch (Exception e) 
			{
				logger.error(e.getMessage());
			}

		}
	}

}
