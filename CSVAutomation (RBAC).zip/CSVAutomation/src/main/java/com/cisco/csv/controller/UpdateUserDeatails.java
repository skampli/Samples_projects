package com.cisco.csv.controller;

import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import org.apache.log4j.Logger;

import com.mysql.jdbc.Connection;

public class UpdateUserDeatails {

	private final static Logger logger = Logger.getLogger(UpdateUserDeatails.class);

	void update(String uName, String uPasskey) {
		try {
			Class.forName("com.mysql.jdbc.Driver");
			Connection con = (Connection) DriverManager.getConnection("jdbc:mysql://localhost:3306/sample","root","cisco123");
			con.setAutoCommit(true);
			PreparedStatement pstm_user = null;
			PreparedStatement pstm_userrole = null;

			String insertUser = "INSERT INTO users(username,password,enabled) VALUES ('"+uName+ "','"+uPasskey+"',"+"true)";
			logger.info("insertUser Query: "+insertUser);
			String insertUserRole = "INSERT INTO user_roles (username, role) VALUES ('"+uName+"','USER')";
			logger.info("insertUserRole Query: "+insertUserRole);
			pstm_user = (PreparedStatement) con.prepareStatement(insertUser.toString());
			pstm_user.execute();

			pstm_userrole = (PreparedStatement) con.prepareStatement(insertUserRole.toString());
			pstm_userrole.execute();

			pstm_user.close();
			pstm_userrole.close();

			con.close();
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		}

	}

}
