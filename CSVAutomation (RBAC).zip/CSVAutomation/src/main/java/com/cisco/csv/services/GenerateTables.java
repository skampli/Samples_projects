package com.cisco.csv.services;

import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.net.InetAddress;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.Set;

import org.apache.log4j.Logger;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;

import com.mysql.jdbc.DatabaseMetaData;

public class GenerateTables {
	private final static Logger logger = Logger.getLogger(GenerateTables.class);

	public String excuteMethod( String fileNameUser) throws ClassNotFoundException, SQLException{

		Authentication auth = SecurityContextHolder.getContext().getAuthentication();
		String sessionUser = auth.getName(); //get logged in username
		
		Class.forName("com.mysql.jdbc.Driver");
		Connection con = (Connection) DriverManager.getConnection("jdbc:mysql://localhost:3306/sample","root","cisco123");
		con.setAutoCommit(true);
		PreparedStatement pstm = null;
		
		String message="";
		String errorSubstringMessage="";
		String absolutePath="";
		
		try {
			Properties props=new Properties();
			String propsName="/config.properties";
			InputStream inputStr = this.getClass().getResourceAsStream(propsName);
			props.load(inputStr);
			
			/*read xlsx file*/ 
			//File file=new File("/tmp/"+fileNameUser); 

			InetAddress ip;
			String hostname;
			ip = InetAddress.getLocalHost();
			hostname = ip.getHostName();

			if(hostname.equalsIgnoreCase("SKAMPLI-80MHF"))
			{
				Set<Object> configKeys=props.keySet();
				for(Object obj:configKeys)
				{
					String configKey=(String)obj;
					if(configKey.equalsIgnoreCase("filePath_local"))
					{
						String pathName=props.getProperty(configKey);
						absolutePath=pathName+fileNameUser;
					}
				}
			}
			else
			{
				absolutePath=props.getProperty("filePath_server")+fileNameUser;
			}


			//File file = new File("C:\\Users\\djhalani\\file\\"+fileNameUser);
			File file = new File(absolutePath);   
			//File file = new File(fileNameUser);
			String fileName1=file.getName();
			if(!(fileName1.endsWith(".xlsx")))
			{
				message="Please upload the file with the .xlsx extension";
				return message;
			}
			else
			{
				InputStream inputStream = new FileInputStream(file);
				XSSFWorkbook  wb = new XSSFWorkbook(inputStream);
				//XSSFSheet sheet = wb.getSheetAt(0);


				//create database sample 	
				try {
					StringBuilder sql_dbase = new StringBuilder();
					sql_dbase.append("create database sample");
					pstm = (PreparedStatement) con.prepareStatement(sql_dbase.toString());
					pstm.execute();
					//con.close();
					//System.out.println("c");
					logger.info("Database created successfully");
				} catch (Exception e1) {
					logger.error(e1.getMessage());
				}

				// get tables and delete those tables of logged in user
				try {
					DatabaseMetaData md = (DatabaseMetaData) con.getMetaData();
					ResultSet rs = md.getTables(null, null,sessionUser+"%", null);
					List<String> tblNames = new ArrayList<>();
					while (rs.next()) {
						//System.out.println(rs.getString(3));
						if(rs.getString(3).startsWith(sessionUser)){
							tblNames.add(rs.getString(3));
						}

					} 

					for(String tn:tblNames){
						try {
							StringBuilder sql_drop = new StringBuilder();
							sql_drop.append("drop table "+tn);
							pstm = (PreparedStatement) con.prepareStatement(sql_drop.toString());
							pstm.execute();
						} catch (Exception e2) {
							// TODO Auto-generated catch block
							//System.out.println("table doesnot exits to delete:"+e2.getMessage());
							logger.error("table doesnot exits to delete:"+e2.getMessage());
						}
					}

				} catch (Exception e) {
					//System.out.println(""+e.getMessage());
					logger.error(e.getMessage());
				}


				//read xlsx sheet header row
				ArrayList<String> sNames = new ArrayList<String>();
				
				for(int j = wb.getNumberOfSheets() - 1; j >= 0; j--){
					List<String> columnNames=new ArrayList<>();
					XSSFSheet sheet = wb.getSheetAt(j);
					sNames.add(sheet.getSheetName());
					
					//prepare data for sheetname table
					Map<String, List<String>> snMap = new HashMap<String, List<String>>();
					ArrayList<String> snList = new ArrayList<String>();
					snList.add(sheet.getSheetName().replaceAll("[^\\w]", ""));
					snList.add("1");
					snList.add(sessionUser+"_"+sheet.getSheetName().replaceAll("[^\\w]", "").toLowerCase());
					snMap.put(sheet.getSheetName().replaceAll("[^a-zA-Z0-9]", ""), snList);
					
					// iteration dmap data 
					for(String k : snMap.keySet()){
						//System.out.println("Key = " + k + " Values = " + snMap.get(k).toString());
					}
					
					XSSFRow row; 
					XSSFCell cell;
					Iterator<Row> rows = sheet.rowIterator();
					boolean skiprow =true;
					List<String> hrow= new ArrayList<String>();

					List<String> errorMessages=new ArrayList<String>();

					while (rows.hasNext() && skiprow )
					{
						row=(XSSFRow) rows.next();
						Iterator<Cell> cells = row.cellIterator();
						while (cells.hasNext())
						{	
							cell=(XSSFCell) cells.next();
							//hrow.add(cell.getStringCellValue().trim().replaceAll("[^a-zA-Z0-9]", ""));

							//System.out.println("the coln name in generate tables****"+cell.getStringCellValue());

							if(columnNames.contains(cell.getStringCellValue().trim().replaceAll("[^a-zA-Z0-9]", "")))
							{
								message="duplicate column "+cell.getStringCellValue().trim().replaceAll("[^a-zA-Z0-9]", "").toLowerCase();
								return message;
							}
							else
							{
								columnNames.add(cell.getStringCellValue().trim().replaceAll("[^a-zA-Z0-9]", "")     );
							}

							for(int i=0;i<columnNames.size();i++)
							{
								String colNameLower=columnNames.get(i).toLowerCase();
								String cellvalueLower=cell.getStringCellValue().trim().replaceAll("[^a-zA-Z0-9]", "").toLowerCase();

								if( (   colNameLower.contains(cellvalueLower )    )    || (   cellvalueLower.contains(colNameLower ) )   )

								{
									//System.out.println("entering for checking the substring");
									logger.debug("entering for checking the substring");
									if(colNameLower.equalsIgnoreCase(cellvalueLower)    )
									{
										hrow.add(cell.getStringCellValue().trim().replaceAll("[^a-zA-Z0-9]", ""));
										//System.out.println("entering its not the substring");
										logger.debug("entering its not the substring");
										//hrow.add(cell.getStringCellValue().trim().replaceAll("[^a-zA-Z0-9]", ""));
									}
									else
									{
										//System.out.println("its the substring");
										logger.debug("its the substring");
										//System.out.println("cols are subtstring of each other the name of cols are***************"+columnNames.get(i).replaceAll("\\s+","").toLowerCase()+" and "+cell.getStringCellValue().replaceAll("\\s+","").toLowerCase());
										logger.debug("cols are subtstring of each other the name of cols are***************"+columnNames.get(i).trim().replaceAll("[^a-zA-Z0-9]", "").toLowerCase()+" and "+cell.getStringCellValue().trim().replaceAll("[^a-zA-Z0-9]", "").toLowerCase());
										message="The column names  "+colNameLower+"  and "+cellvalueLower+" are subtsring of each other.Please upload the raw data with different column names";
										//errorSubstringMessage="The column names  "+colNameLower+"  and "+cellvalueLower+" are subtsring of each other.Please upload the raw data with different column names";
										//errorMessages.add(errorSubstringMessage);
										return message;
									}
								}
							}
							//System.out.println("names present in list******"+columnNames);
							//hrow.add(cell.getStringCellValue().replaceAll("\\s+",""));
						}
						skiprow = false;
						//System.out.println();
					}
					Collections.sort(sNames, String.CASE_INSENSITIVE_ORDER);
					//System.out.println("sheetNames --:"+sNames);	
					logger.debug("sheetNames --:"+sNames);
					//System.out.println("header columns:"+hrow);		

					//create sheet table
					try {
						StringBuilder sql_crttbl = new StringBuilder();
						sql_crttbl.append("create table sample."+sessionUser+"_sheetnames").append("(\n");
						sql_crttbl.append(" `id` integer NOT NULL AUTO_INCREMENT,");
						sql_crttbl.append(" `sheetname` VARCHAR(250) NOT NULL,");
						sql_crttbl.append(" `startingrow` integer NOT NULL,");
						sql_crttbl.append(" `sheetnametables` VARCHAR(250) NOT NULL,");
						sql_crttbl.append("PRIMARY KEY (id)").append(");");
						logger.info("create query: "+sql_crttbl);
						pstm = (PreparedStatement) con.prepareStatement(sql_crttbl.toString());
						pstm.execute();
					} catch (Exception e1) {
						logger.error(" Error in creating sheetnames table:"+e1.getMessage());
					}	


					/*create dynamic tables with header row ..*/
					try {
						StringBuilder sql = new StringBuilder();
						sql.append("CREATE TABLE sample."+ sessionUser+"_"+sheet.getSheetName().replaceAll("[^\\w]", "")+"(\n");
						sql.append(" `SerialNumber` integer NOT NULL AUTO_INCREMENT,");
						for (String hclmns : hrow) // or sArray
						{
							//System.out.println( hclmns );
							sql.append(hclmns).append(" ").append("VARCHAR(250) NOT NULL,");
						}
						sql.append("PRIMARY KEY (SerialNumber)");
						String withoutLastComma = sql.substring( 0, sql.length( )-1);
						String sqlcreate = withoutLastComma + "));";
						pstm = (PreparedStatement) con.prepareStatement(sqlcreate.toString());
						pstm.execute();
						//con.close();
						//System.out.println("table created successfully");
						logger.debug("table created successfully");
					} catch (Exception e1) {
						//System.out.println("Error in table creation:"+e1.getMessage());
						logger.error("Error in table creation:"+e1.getMessage());
					}

					/*Read data records*/
					Map<String, List<String>> map = new HashMap<String, List<String>>();
					String key="#";

					Row frow = sheet.getRow(0);
					/*short lastrowcell = sheet.getRow(0).getLastCellNum();
						Cell lcell = frow.getCell(lastrowcell);
						System.out.println("last cell of first row"+lcell);*/	

					for (int rowNumber = 1;rowNumber <= sheet.getLastRowNum(); rowNumber++) {
						Row drow = sheet.getRow(rowNumber);
						List<String> dynamiclist = new ArrayList<>();
						if (drow == null) {
							// This row is completely empty
						} else {
							// The row has data
							short firstvar = 0;
							short secvar = (short) (frow.getLastCellNum()-1);

							for (int cellNumber = firstvar;cellNumber <= secvar; cellNumber++) {
								Cell dcell = drow.getCell(cellNumber);
								if (dcell == null || dcell.getCellType() == Cell.CELL_TYPE_BLANK) {
									// This cell is empty
									dynamiclist.add("");
								}else {
									// This cell has data in it
									dcell.setCellType(Cell.CELL_TYPE_STRING);
									dynamiclist.add(dcell.getStringCellValue().replace("'", ""));
								}
							}
							map.put(key,dynamiclist);
							//print to check row data
							for(String k : map.keySet()){
								//System.out.println("Key = " + k + " Values = " + map.get(k).toString());

								logger.debug("Key = " + k + " Values = " + map.get(k).toString());
							}				

						}

						try {
							StringBuilder sqlinsert = new StringBuilder();
							StringBuilder in_sql = new StringBuilder();
							sqlinsert.append("INSERT INTO sample."+ sessionUser+"_"+sheet.getSheetName().replaceAll("[^\\w]", "")+" (");					
							for (String hclmns : hrow) // or sArray
							{
								sqlinsert.append(hclmns).append(",");
							}
							String rcomma = sqlinsert.substring(0, sqlinsert.length( )-1);
							String insert_sql = rcomma + ")" +" "+"VALUES(";
							in_sql.append(insert_sql);
							for(String k : map.keySet()){
								for(String v :map.get(k)){
									in_sql.append("'").append(v).append("'").append(",");
								}
							}
							String removecomma = in_sql.substring(0, in_sql.length()-1);
							//String sqlinserts = removecomma.concat(");");
							String sqlinserts = removecomma.replace("+", "\\+").concat(");");
							//System.out.println("final insert query:"+sqlinserts);
							logger.debug("final insert query:"+sqlinserts);
							pstm = (PreparedStatement) con.prepareStatement(sqlinserts);
							pstm.execute();
							//con.close();
							//System.out.println("Records inserted");
							//	logger.info("Records inserted");
							logger.debug("Records inserted");
						} catch (Exception e) {
							//System.out.println("Error in insertinig Records:"+e.getMessage());
							logger.error("Error in insertinig Records:"+e.getMessage());
						}
					}
					//finally insert sheet names values to sheetnames table
					try {
							StringBuilder sqlinsert = new StringBuilder();
							sqlinsert.append("INSERT INTO sample."+sessionUser+"_sheetnames(sheetname,startingrow,sheetnametables) VALUES(");
							//sqlinsert.append("'").append(sheetnms).append("'");	
							for(String snkey : snMap.keySet()){
								for(String v :snMap.get(snkey)){
									sqlinsert.append("'").append(v).append("'").append(",");
								}
							}
							String removecomma = sqlinsert.substring(0, sqlinsert.length()-1);
							String iSN_sql = removecomma + ")";
						//	System.out.println("final insert query:"+iSN_sql);
							pstm = (PreparedStatement) con.prepareStatement(iSN_sql.toString());
							pstm.execute();
							//System.out.println("sheetnames Records inserted");
					} catch (Exception e) {
						// TODO Auto-generated catch block
						//System.err.println("Error in  inserting:"+e.getMessage());
						logger.error(e.getMessage());
					}

				}

				

				pstm.close();
				con.close();
				return message;
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			logger.error("Error in excuteMethod:"+e.getMessage());
		}finally {
		    if (pstm!= null) {
		        try {
		        	pstm.close();
		        	//System.out.println("closing pstm connections");
		        	logger.info("closing pstm connections");
		        } catch (SQLException e) { }
		    }
		    if (con != null) {
		        try {
		            con.close();
		            //System.out.println("closing all opened connections");
		            logger.info("closing pstm connections");
		        } catch (SQLException e) { }
		    }
		}
		return message;
	}
}
