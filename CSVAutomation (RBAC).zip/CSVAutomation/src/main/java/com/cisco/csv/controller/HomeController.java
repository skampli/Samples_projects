package com.cisco.csv.controller;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.InetAddress;
import java.security.Principal;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.Set;

import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.ModelAndView;

import com.cisco.model.UploadedFile;

/**
 * Handles requests for the application home page.
 */
@Controller
public class HomeController  extends HttpServlet{

	private final static Logger logger = Logger.getLogger(HomeController.class);


	@RequestMapping(value="/", method=RequestMethod.GET)
	public ModelAndView visitHome(){
		//System.out.println("in controller");
		//logger.info("in controller");
		logger.debug("in controller");
		return new ModelAndView("home");

	}



	@RequestMapping(value="/user", method=RequestMethod.GET)
	public ModelAndView userLogin()
	{

		//System.out.println("in login controller");
		//logger.info("in login controller");

		logger.debug("in login controller");
		return new ModelAndView("user");
	}

	@RequestMapping(value="/csvGen" ,method=RequestMethod.GET)
	public ModelAndView csvGenerate()
	//public ModelAndView csvGenerate(@RequestParam  (value = "messageDisplayed", required = false )List<String>messageDisplayed)
	{

		Authentication auth = SecurityContextHolder.getContext().getAuthentication();
		String sessionUser = auth.getName(); //get logged in username
		ModelAndView modelCsvGen=new ModelAndView("csvGen");
		List<String> csvNames=new ArrayList<>();

		Properties props=new Properties();

		String xmlConfigFilePath="";

		String xmlConfig="xml-configs";

		logger.debug("in csv generator");
		//logger.info("in csv generator");

		try {

			/*Getting the hostName*/
			InetAddress ip;
			String hostname;
			ip = InetAddress.getLocalHost();
			hostname = ip.getHostName();

			/*For reading the config properties*/
			String propsName="/config.properties";
			InputStream inputStr = this.getClass().getResourceAsStream(propsName);
			props.load(inputStr);

			if(hostname.equalsIgnoreCase("SKAMPLI-80MHF"))
			{
				Set<Object> configKeys=props.keySet();

				for(Object obj:configKeys)
				{
					String configKey=(String)obj;

					if(configKey.equalsIgnoreCase("filePath_local"))
					{

						String pathName=props.getProperty(configKey);

						xmlConfigFilePath=pathName+"xml-configs";

					}

				}
			}
			else
			{
				xmlConfigFilePath=props.getProperty("filePath_server")+xmlConfig;

			}



			/*For getting all the xml files from the xml-configs folder*/
			File folder = new File(xmlConfigFilePath);

			File[] listOfFiles = folder.listFiles();

			for(int i = 0; i < listOfFiles.length; i++)
			{
				String configName = listOfFiles[i].getName();

				if(configName.endsWith(".xml")||configName.endsWith(".XML"))
				{
					if(configName.contains(sessionUser))
					{
						//if(!(configName.contains("CommonConfig")))
						if(!(configName.contains("CommonConfig"))  )
						{
							if(!(configName.contains("master_sheet_info")   ))
							{

								int sizeOfUnderScore=configName.indexOf('_')+1;

								int xmlIndex1=configName.indexOf("xml")-1;

								String csvName=configName.substring(sizeOfUnderScore, xmlIndex1);
								//System.out.println("csv file name is*************"+csvName);
								csvNames.add(csvName);
							}
						}
					}
				}
			}





			/*		PathMatchingResourcePatternResolver loader = new PathMatchingResourcePatternResolver();
			Resource[] resources;

			resources = loader.getResources("classpath:/*.xml");
			for (Resource resource : resources) 
			{
				//System.out.println("file names in resources is*******"+resource.getFile().getName());

				String configName=resource.getFile().getName();
				if(configName.contains(sessionUser))
				{
					//if(!(configName.contains("CommonConfig")))
					if(!(configName.contains("CommonConfig"))  )
					{
						if(!(configName.contains("master_sheet_info")   ))
						{

						int sizeOfUnderScore=configName.indexOf('_')+1;

						int xmlIndex1=configName.indexOf("xml")-1;

						String csvName=configName.substring(sizeOfUnderScore, xmlIndex1);
						//System.out.println("csv file name is*************"+csvName);
						csvNames.add(csvName);
						}
					}
				}
			}*/




			modelCsvGen.addObject("csvNames", csvNames);
			//modelCsvGen.addObject("messageDisplayed",messageDisplayed);




		} 
		catch (IOException e) {
			// TODO Auto-generated catch block

			logger.error(e.getMessage());
			//e.printStackTrace();
		}


		return modelCsvGen;

	}





	@RequestMapping(value="/txtGen" ,method=RequestMethod.GET)
	public ModelAndView txtGenerate()
	//public ModelAndView txtGenerate(@RequestParam  (value = "messageDisplayed", required = false )List<String>messageDisplayed)
	{
		Authentication auth = SecurityContextHolder.getContext().getAuthentication();
		String sessionUser = auth.getName(); //get logged in username
		ModelAndView modelTxtGen=new ModelAndView("txtGen");
		List<String> csvNames=new ArrayList<>();
		Properties props=new Properties();
		String xmlConfig="xml-configs";
		String xmlConfigFilePath="";
		logger.debug("in txt generator");


		try {
			/*Getting the hostName*/
			InetAddress ip;
			String hostname;
			ip = InetAddress.getLocalHost();
			hostname = ip.getHostName();

			/*For reading the config properties*/
			String propsName="/config.properties";
			InputStream inputStr = this.getClass().getResourceAsStream(propsName);
			props.load(inputStr);

			if(hostname.equalsIgnoreCase("SKAMPLI-80MHF"))
			{
				Set<Object> configKeys=props.keySet();

				for(Object obj:configKeys)
				{
					String configKey=(String)obj;

					if(configKey.equalsIgnoreCase("filePath_local"))
					{

						String pathName=props.getProperty(configKey);

						xmlConfigFilePath=pathName+"xml-configs";

					}

				}
			}
			else
			{
				xmlConfigFilePath=props.getProperty("filePath_server")+xmlConfig;

			}



			/*For getting all the xml files from the xml-configs folder*/
			File folder = new File(xmlConfigFilePath);

			File[] listOfFiles = folder.listFiles();

			for(int i = 0; i < listOfFiles.length; i++)
			{
				String configName = listOfFiles[i].getName();

				if(configName.endsWith(".xml")||configName.endsWith(".XML"))
				{
					if(configName.contains(sessionUser))
					{
						//if(!(configName.contains("CommonConfig")))
						if(!(configName.contains("CommonConfig"))  )
						{
							if(!(configName.contains("master_sheet_info")   ))
							{

								int sizeOfUnderScore=configName.indexOf('_')+1;

								int xmlIndex1=configName.indexOf("xml")-1;

								String csvName=configName.substring(sizeOfUnderScore, xmlIndex1);
								//System.out.println("csv file name is*************"+csvName);
								csvNames.add(csvName);
							}
						}
					}
				}
			}



			/*		PathMatchingResourcePatternResolver loader = new PathMatchingResourcePatternResolver();
			Resource[] resources;

			resources = loader.getResources("classpath:/*.xml");
			for (Resource resource : resources) 
			{
				//System.out.println("file names in resources is*******"+resource.getFile().getName());

				String configName=resource.getFile().getName();
				if(configName.contains(sessionUser))
				{
					if(!(configName.contains("CommonConfig")))
					{

						int sizeOfUnderScore=configName.indexOf('_')+1;

						int xmlIndex1=configName.indexOf("xml")-1;

						String csvName=configName.substring(sizeOfUnderScore, xmlIndex1);
						//System.out.println("csv file name is*************"+csvName);
						csvNames.add(csvName);
					}
				}
			}*/


			modelTxtGen.addObject("csvNames", csvNames);
			//modelTxtGen.addObject("messageDisplayed",messageDisplayed);


		} 
		catch (Exception e) {
			// TODO Auto-generated catch block

			logger.error(e.getMessage());
			//e.printStackTrace();
		}


		//System.out.println("in csv generator");

		return modelTxtGen;
	}

	@RequestMapping(value = "/userRegister", method = RequestMethod.GET)
	public ModelAndView newuserregister() {
		ModelAndView model = new ModelAndView();		
		model.setViewName("userRegister");
		return model;

	}

	@RequestMapping(value = "/registerProcess", method = RequestMethod.POST)
	public ModelAndView addUser(HttpServletRequest request, HttpServletResponse response) {

		String uName =request.getParameter("newusername");
		String uPasskey =request.getParameter("newpasskey");

		ModelAndView model = new ModelAndView();

		if(uName != null && uPasskey != null) {
			UpdateUserDeatails uud = new UpdateUserDeatails();
			uud.update(uName, uPasskey);
			model.setViewName("userRegisterSuccess");
		}else {
			model.setViewName("userRegister");
		}
		return model;
	}


	@RequestMapping(value = "/login", method = RequestMethod.GET)
	public ModelAndView login(
			@RequestParam(value = "error", required = false) String error,
			@RequestParam(value = "logout", required = false) String logout) {

		ModelAndView model = new ModelAndView();
		if (error != null) {
			model.addObject("error", "Invalid username and password!");
		}

		if (logout != null) {
			model.addObject("msg", "You've been logged out successfully.");
		}
		model.setViewName("login");

		return model;

	}

	// for 403 access denied page
	@RequestMapping(value = "/403", method = RequestMethod.GET)
	public ModelAndView accesssDenied(Principal user) {

		ModelAndView model = new ModelAndView();

		if (user != null) {
			model.addObject("msg", "Hi " + user.getName() 
			+ ", you do not have permission to access this page!");
		} else {
			model.addObject("msg", 
					"You do not have permission to access this page!");
		}

		model.setViewName("403");
		return model;

	}


	@RequestMapping(value="/patchFile", method=RequestMethod.GET)
	public ModelAndView patchfile()
	{
		logger.debug("in home controller");
		return new ModelAndView("patchFile");
	}


	@RequestMapping( value="/patchsuccess" ,method=RequestMethod.POST)
	public ModelAndView fileUpload(@ModelAttribute("uploadedFile") UploadedFile uploadedFile, BindingResult result
			,HttpServletResponse response,HttpServletRequest request) throws IllegalStateException, IOException 		  
	{
		
		MultipartFile srcfile = uploadedFile.getFile();
		File convFile = new File( srcfile.getOriginalFilename());
		srcfile.transferTo(convFile);
		
		String destDirpath = request.getParameter("dstpath");
		
		System.out.println("check file.." + uploadedFile.getFile().getOriginalFilename());

		logger.debug("in home controller -patchExcute");		
		ExecutePatchController epc = new ExecutePatchController();
		epc.excute(convFile,destDirpath);

		return  new ModelAndView("patchSuccess");
	}




	/*	@RequestMapping(value="/upload" ,method=RequestMethod.GET)
	public ModelAndView uploadFile()
	{
		System.out.println("in  upload");
		return new ModelAndView("upload");
	}*/

	@RequestMapping(value="/fetchRecords" ,method=RequestMethod.GET)
	public ModelAndView fetchRecords()
	{
		//logger.info("infetchRecords");
		logger.debug("infetchRecords");

		return new ModelAndView("fetchRecords");
	}
	@RequestMapping(value="/success" ,method=RequestMethod.GET)
	public ModelAndView successpage()
	{
		//logger.info("in success");

		logger.debug("in success");
		return new ModelAndView("success");
	}

	/*@RequestMapping(value="/deleteRecord",  method = RequestMethod.GET)
	public ModelAndView deleteRecord(@RequestParam("serialNum") String serialNum,@RequestParam("seltblName") String seltblName)
	{	
		ModifyRecordController recordmodify = new ModifyRecordController();
		recordmodify.deleteRecord(serialNum,seltblName);
		logger.info("in deleteRecord");
		return new ModelAndView("fetchRecords");
	}
	 */

	@RequestMapping(value="/deleteRecord",  method = RequestMethod.GET)
	public ModelAndView deleteRecord(HttpServletRequest request , HttpServletResponse response , HttpSession session)
	{	

		String serialNum =request.getParameter("serialNum");		
		String stable =request.getParameter("seltblName");

		ArrayList<String> tn = new ArrayList<String>();						
		tn = ((ArrayList<String>) session.getAttribute("tblNames"));					
		ArrayList<String> sname = new ArrayList<String>();					
		sname = ((ArrayList<String>) session.getAttribute("shtname"));					

		Map<String,String> mpp = new HashMap<String,String>();
		for(int i=0;i<sname.size();i++ ){
			mpp.put(sname.get(i), tn.get(i));
		}
		for (String key: mpp.keySet()) {
			if(key.equalsIgnoreCase(stable)){
				String deltble = mpp.get(stable);
				ModifyRecordController recordmodify = new ModifyRecordController();
				recordmodify.deleteRecord(serialNum,deltble);
			}
		}
		//logger.info("in deleteRecord");

		logger.debug("in deleteRecord");
		return new ModelAndView("fetchRecords");
	}


	@RequestMapping(value="/editRecord" ,method=RequestMethod.GET)
	public ModelAndView editRecord(@RequestParam("serialNum") String serialNum )
	{
		//logger.info("in editRecord");
		logger.debug("in editRecord");

		return new ModelAndView("editRecord");
	}

	/*@RequestMapping(value="/updateRecord",  method = RequestMethod.GET)
	public ModelAndView updateRecord(@RequestParam("serialNum") String serialNum ,@RequestParam("input_values") List<String> input_values)
	{	
		ModifyRecordController recordmodify = new ModifyRecordController();
		recordmodify.updateRecord(serialNum ,input_values);
 		//System.out.println("in update record..");
		logger.info("in  update record..");
		return new ModelAndView("editRecord");
	}*/

	@RequestMapping(value="/updateRecord" ,method=RequestMethod.GET)
	public ModelAndView updateRecord(HttpServletRequest request ,@RequestParam("input_values") List<String> input_values ,HttpSession session)
	{	
		String updateId =request.getParameter("serialNum");		
		String stable = (String)session.getAttribute("selTbl");

		ArrayList<String> tn = new ArrayList<String>();						
		tn = ((ArrayList<String>) session.getAttribute("tblNames"));					
		ArrayList<String> sname = new ArrayList<String>();					
		sname = ((ArrayList<String>) session.getAttribute("shtname"));					

		Map<String,String> mpp = new HashMap<String,String>();
		for(int i=0;i<sname.size();i++ ){
			mpp.put(sname.get(i), tn.get(i));
		}
		for (String key: mpp.keySet()) {
			if(key.equalsIgnoreCase(stable)){
				String deltble = mpp.get(stable);
				ModifyRecordController recordmodify = new ModifyRecordController();
				recordmodify.updateRecord(updateId, deltble, input_values);
			}
		}
		//logger.info("in  update record..");

		logger.debug("in  update record..");

		return new ModelAndView("editRecord");
	}





	@RequestMapping(value="/getTables" ,method=RequestMethod.GET)
	public ModelAndView getTables(HttpServletRequest request , HttpServletResponse response , HttpSession session) throws ClassNotFoundException, SQLException
	{
		SchemaTablesContoller<?, ?> stc = new SchemaTablesContoller<Object, Object>();
		stc.getTables(request,response,session);
		//logger.info("in getTables");

		logger.debug("in getTables");


		return new ModelAndView("fetchRecords");
	}


	@RequestMapping(value="/downloadFile" ,method=RequestMethod.GET)
	public  ModelAndView fileDownload()
	{
		Authentication auth = SecurityContextHolder.getContext().getAuthentication();
		String sessionUser = auth.getName(); //get logged in username
		ModelAndView modeldownloadFile=new ModelAndView("downloadFile");
		List<String> fileNames=new ArrayList<>();

		Properties props=new Properties();

		String filePath="";

		try
		{
			/*Getting the hostName*/
			InetAddress ip;
			String hostname;
			ip = InetAddress.getLocalHost();
			hostname = ip.getHostName();

			/*For reading the config properties*/
			String propsName="/config.properties";
			InputStream inputStr = this.getClass().getResourceAsStream(propsName);
			props.load(inputStr);

			if(hostname.equalsIgnoreCase("SKAMPLI-80MHF"))
			{
				Set<Object> configKeys=props.keySet();

				for(Object obj:configKeys)
				{
					String configKey=(String)obj;

					if(configKey.equalsIgnoreCase("filePath_local"))
					{

						String pathName=props.getProperty(configKey);

						filePath=pathName+sessionUser;

					}

				}
			}
			else
			{
				filePath=props.getProperty("filePath_server")+sessionUser;

			}


			/*For getting all the error and csv files from the folder*/
			File folder = new File(filePath);

			File[] listOfFiles = folder.listFiles();

			for(int i = 0; i < listOfFiles.length; i++)
			{
				String fileName = listOfFiles[i].getName();

				System.out.println(fileName);

				if(fileName.endsWith(".csv")||fileName.endsWith(".CSV")||fileName.endsWith(".log")||fileName.endsWith(".LOG")||fileName.endsWith(".txt")||fileName.endsWith(".TXT"))
				{

					//if(!(configName.contains("CommonConfig")))
					if(!(fileName.contains("header"))  )
					{



						//int indexOfDot=fileName.indexOf('.');



						//String fileNameSaved=fileName.substring(0, indexOfDot);
						//System.out.println("csv file name is*************"+csvName);
						fileNames.add(fileName);

					}

				}
			}

			modeldownloadFile.addObject("fileNames", fileNames);
		}
		catch(Exception e)
		{
			logger.error(e.getMessage());
		}

		return modeldownloadFile;
	}
}



