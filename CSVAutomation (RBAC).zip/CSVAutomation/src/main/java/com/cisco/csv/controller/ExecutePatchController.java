package com.cisco.csv.controller;

import java.io.File;
import java.io.IOException;

import org.apache.commons.io.FileUtils;
import org.apache.log4j.Logger;

public class ExecutePatchController {

	private final static Logger logger = Logger.getLogger(ExecutePatchController.class);

	public void excute(File srcFile , String dirPath) {
		//String parentDestination = "/usr/tomcat/apache-tomcat-7.0.52/webapps/csv/";

		File sourceFile = srcFile;
		String destination = dirPath;
		File destinationDirectory = new File(destination);	
		logger.info("move sourceFile "+sourceFile +" to destination path "+ destination);
		
		try {
			ExecutePatchController.copyFileUsingApacheCommonsIO(sourceFile, destinationDirectory);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}		
	private static void copyFileUsingApacheCommonsIO(File source, File dest) throws IOException {
		FileUtils.copyFileToDirectory(source, dest);
		System.out.println("file moved to dir...");
		logger.info("file moved to dir...");
	}
	
}
