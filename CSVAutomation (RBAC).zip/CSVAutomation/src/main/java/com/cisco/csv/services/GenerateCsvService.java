package com.cisco.csv.services;

import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.apache.log4j.Logger;
import org.springframework.context.annotation.ComponentScan;
import org.w3c.dom.Document;

import com.cisco.csv.writer.CsvWriter;
import com.cisco.csv.writer.ErrorWriter;


@ComponentScan("com.cisco.csv")
public class GenerateCsvService implements Runnable {
	
	private final static Logger logger = Logger.getLogger(GenerateCsvService.class);
	

	
	
	private Document document;
	
	private String fileName;
	
	private Document documentCommon ;
	
	private String absolutePathError;
	
	private String absolutePathCsv;
	
	private String sessionUser;
	
	public GenerateCsvService()
	{
		
	}
	
	public GenerateCsvService(Document document,String fileName, Document documentCommon , String absolutePathError , String absolutePathCsv,String sessionUser ) {
		
		this.document=document;
		this.fileName=fileName;
		this.documentCommon=documentCommon;
		this.absolutePathCsv=absolutePathCsv;
		this.absolutePathError=absolutePathError;
		this.sessionUser=sessionUser;
		
	}
	
	



	@Override
	public void run() {
		
		
		UserDaoImpl userDAO = new UserDaoImpl();
		
		CsvWriter csvWriter=new CsvWriter();
		
		ErrorWriter errorWriter=new ErrorWriter();
		
		
		
		List<Map<String, String>> listMapGet=null;
		
		List<String> message=new ArrayList<>();
		
		//String message="";
		
		try
		{
			

		listMapGet=userDAO.UserCsvGen(document, fileName, documentCommon,sessionUser);
			
			
			
			for(Map<String, String> messageValue: listMapGet)
			{
				Set<String> keysMessageValue= new LinkedHashSet<>();
				keysMessageValue=messageValue.keySet();
			
				for(String key:keysMessageValue)
				{
					if(key.matches("[0-9]+"))
					{
						message.add(messageValue.get(key));
					}
				}
			}
			
			if(!(message.isEmpty() ))
			{
				
				errorWriter.createErrorFileSave(listMapGet,absolutePathError);
					
			}
			else
			{
				csvWriter.createCsvSave(listMapGet, absolutePathCsv);
			}
			
		
			
	
			
		}
		catch(Exception e)
		{
			logger.error(e.getMessage());
		}
		
	}
	
	
	

	


}
