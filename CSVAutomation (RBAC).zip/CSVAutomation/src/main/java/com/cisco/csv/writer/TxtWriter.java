package com.cisco.csv.writer;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.servlet.ServletOutputStream;

import org.apache.log4j.Logger;

public class TxtWriter {


	private final static Logger logger = Logger.getLogger(TxtWriter.class);

	


	public void createTxt(List<Map<String, String>> listMapGetValues, ServletOutputStream out, String fileName)throws IOException
	{
		File file=null;
		
		List<String> fileHeader=null;
		
		fileHeader=new ArrayList<>();

		//logger.info("File name is"+fileName);
		logger.debug("File name is"+fileName);

		file=new File(fileName);

		int count=0;
		int countContent=0;

		if(!(file.exists()))
		{
			file.createNewFile();

		}
		FileWriter fileWriter=new FileWriter(file);
		//PrintWriter pw=response.getWriter();

		for(Map<String, String> mapCsvValues:listMapGetValues)
		{
			Set<String> keys=mapCsvValues.keySet();

			for(String key:keys)
			{
				fileHeader.add(key);
			}
			break;
		}

		//for writing the file header

		//StringBuffer sb=new StringBuffer();
		StringBuilder sb=new StringBuilder();

		for(String header:fileHeader)
		{

			sb.append(header);

			while(count<(fileHeader.size()-1))
			{

				sb.append("\t\t");

				count=count+1;
				break;
			}

		}
		//sb.append("\n"); 
		//sb.append(System.getProperty("line.separator")); 
		
		String osname=System.getProperty("os.name").toLowerCase();
		
		if(osname.contains("windows"))
		{
		sb.append("\r\n");
		}
		else if(osname.contains("linux"))
		{
			sb.append("\n");
		}

		out.print(sb.toString());
		sb.delete(0, sb.length());
		//sb.append(System.getProperty("line.separator")); 

		for(Map<String, String> mapCsvWrite : listMapGetValues)
		{
			Set<String> keysWrite=mapCsvWrite.keySet();
			for(String keyWrite : keysWrite)
			{
				for(String fileHeadKey: fileHeader)
				{
					if(fileHeadKey.equalsIgnoreCase(keyWrite))
					{
						//if(mapCsvWrite.get(fileHeadKey).contains(" ")) 
						//{

							//sb.append("\"" + mapCsvWrite.get(fileHeadKey) + "\"");
						//}
						//else
						//{
							sb.append(mapCsvWrite.get(fileHeadKey));
						//}
						while(countContent<(fileHeader.size()-1))
						{

							sb.append("\t");

							countContent=countContent+1;
							break;
						}
					}
				}

			}
			countContent=0;
			if(osname.contains("windows"))
			{
			sb.append("\r\n");
			}
			else if(osname.contains("linux"))
			{
				sb.append("\n");
			}
		}

		out.print(sb.toString());
		fileWriter.close();
	}
	
	public String createTxtSave(List<Map<String, String>> listMapGetValues, String txtFileName)
	{
		File file=null;
		
		List<String> fileHeader=null;
		
		FileWriter fr = null;
		
        BufferedWriter br = null;
        
        String message="";
		
		try
		{
			fileHeader=new ArrayList<>();
			
			file=new File(txtFileName);
			
			int count=0;
			int countContent=0;

			if(!(file.exists()))
			{
				file.createNewFile();

			}
			
			logger.info("Writing in the txt file for saving");
			
			fr = new FileWriter(file);
			
            br = new BufferedWriter(fr);
            
            for(Map<String, String> mapCsvValues:listMapGetValues)
    		{
    			Set<String> keys=mapCsvValues.keySet();

    			for(String key:keys)
    			{
    				fileHeader.add(key);
    			}
    			break;
    		}
            
            StringBuilder sb=new StringBuilder();
            
            for(String header:fileHeader)
    		{

    			sb.append(header);

    			while(count<(fileHeader.size()-1))
    			{

    				sb.append("\t\t");

    				count=count+1;
    				break;
    			}

    		}
            
            String osname=System.getProperty("os.name").toLowerCase();
    		
    		if(osname.contains("windows"))
    		{
    		sb.append("\r\n");
    		}
    		else if(osname.contains("linux"))
    		{
    			sb.append("\n");
    		}
    		
    		br.write(sb.toString());
			
			sb.delete(0, sb.length());
			
			for(Map<String, String> mapCsvWrite : listMapGetValues)
			{
				Set<String> keysWrite=mapCsvWrite.keySet();
				for(String keyWrite : keysWrite)
				{
					for(String fileHeadKey: fileHeader)
					{
						if(fileHeadKey.equalsIgnoreCase(keyWrite))
						{
							//if(mapCsvWrite.get(fileHeadKey).contains(" ")) 
							//{

								//sb.append("\"" + mapCsvWrite.get(fileHeadKey) + "\"");
							//}
							//else
							//{
								sb.append(mapCsvWrite.get(fileHeadKey));
							//}
							while(countContent<(fileHeader.size()-1))
							{

								sb.append("\t");

								countContent=countContent+1;
								break;
							}
						}
					}

				}
				countContent=0;
				if(osname.contains("windows"))
				{
				sb.append("\r\n");
				}
				else if(osname.contains("linux"))
				{
					sb.append("\n");
				}
			}
			
			logger.info("Txt file is created and saved");
			
			message="The Csv file got processed and is saved at:"+txtFileName;
			
			br.write(sb.toString());
            
            
		}
		catch(Exception e)
		{
			logger.error(e.getMessage());
		}
		
		finally
		{
			try
			{
				br.close();
				fr.close();
			}
			catch(Exception e)
			{
				logger.error(e.getMessage());
			}
		}
		return message;
		
		
	}
	
	

}
