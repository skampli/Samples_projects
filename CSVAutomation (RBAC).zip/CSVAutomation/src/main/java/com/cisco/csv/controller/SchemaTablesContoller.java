package com.cisco.csv.controller;

import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.mysql.jdbc.ResultSetMetaData;
import com.mysql.jdbc.Statement;

public class SchemaTablesContoller<k, v> extends HttpServlet  {
	private static final long serialVersionUID = 1L;
	private final static Logger logger = Logger.getLogger(ModifyRecordController.class);

	@RequestMapping(value="/getTables" , method=RequestMethod.GET)
	//public String getTables(@PathVariable("selectedTbl")String selectedTbl) 
	public String getTables(HttpServletRequest request , HttpServletResponse response ,HttpSession session) throws ClassNotFoundException, SQLException
	{	
		String stable =request.getParameter("tblSelect");


		//System.out.println("map vlaues from jsp:");
		Class.forName("com.mysql.jdbc.Driver");
		java.sql.Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/sample", "root",	"cisco123");
		Statement st = (Statement) con.createStatement();
		try {	

			Map<String,String> maptblsht = new HashMap<String,String>();

			maptblsht = (Map<String, String>) session.getAttribute("tblshtmap");
			for (String key: maptblsht.keySet()) {
				if(key.equalsIgnoreCase(stable)){
					String seltble = maptblsht.get(stable);
					System.out.println("value : " + seltble);

					String query = "select * from "+seltble;
					ResultSet rs = st.executeQuery(query);
					ResultSetMetaData metaData = (ResultSetMetaData) rs.getMetaData();

					int columnCount = metaData.getColumnCount();
					List<Map<String, Object>> rows = new ArrayList<Map<String, Object>>();
					while (rs.next()) {
						Map<String, Object> columns = new LinkedHashMap<String, Object>();
						for (int i = 1; i <= columnCount; i++) {
							columns.put(metaData.getColumnLabel(i), rs.getObject(i));
						}
						rows.add(columns);
					}
					List<String> tableColNames = new ArrayList<String>();
					for (int i = 1; i <= columnCount; i++) {
						String columnName = metaData.getColumnName(i);
						tableColNames.add(columnName);
					}
					request.setAttribute("rdata", rows);
					request.setAttribute("TblList", tableColNames);
					//request.setAttribute("selTbl", stable);
					session.setAttribute("selTbl", stable);
					st.close();
					con.close();
				}
			}
		}catch(Exception e2){			
			//logger.info("dError in getting selected table "+e2.getMessage());
			
			logger.error(e2.getMessage());
			
			//e2.printStackTrace();
			//System.out.println(" Error in getting selected table:" + e2.getMessage());
		}finally {
		    if (st!= null) {
		        try {
		        	st.close();
		        	//System.out.println("closing pstm connections");
		        	logger.info("closing pstm connections");
		        } catch (SQLException e) { }
		    }
		    if (con != null) {
		        try {
		            con.close();
		           // System.out.println("closing all opened connections");
		            logger.info("closing pstm connections");
		        } catch (SQLException e) { }
		    }
		}
		return "redirect:/fetchRecords";

	}	
}
