package com.cisco.csv.services;

import java.util.List;




public interface UserDAO {
	
	//public int getUser(String sessionUser,String tableName);
	//public List<String> getColNames(String sessionUser,String tableName);
	
	

}