package com.cisco.csv.controller;

import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.io.PrintWriter;
import java.net.InetAddress;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;
import java.util.Set;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;



@Controller
public class fileDownloadController {
	
	private final static Logger logger = Logger.getLogger(fileDownloadController.class);
	
	@RequestMapping(value="/fileDownload" , method=RequestMethod.GET)
	public void downloadFile(HttpServletRequest request , HttpServletResponse response,final RedirectAttributes redirectAttributes)
	{
		Authentication auth = SecurityContextHolder.getContext().getAuthentication();
		
		String sessionUser = auth.getName(); //get logged in username
		
		String type=request.getParameter("type");
		
		List<String> fileNames=new ArrayList<>();

		Properties props=new Properties();
		
		String filePath="";
		
	
		
		try
		{
			/*Getting the hostName*/
			InetAddress ip;
			String hostname;
			ip = InetAddress.getLocalHost();
			hostname = ip.getHostName();
			
			/*For reading the config properties*/
			String propsName="/config.properties";
			InputStream inputStr = this.getClass().getResourceAsStream(propsName);
			props.load(inputStr);

			if(hostname.equalsIgnoreCase("SKAMPLI-80MHF"))
			{
				Set<Object> configKeys=props.keySet();

				for(Object obj:configKeys)
				{
					String configKey=(String)obj;

					if(configKey.equalsIgnoreCase("filePath_local"))
					{

						String pathName=props.getProperty(configKey);

						filePath=pathName+sessionUser;
						
						
					}

				}
			}
			else
			{
				filePath=props.getProperty("filePath_server")+sessionUser;

			}
			
			/*For getting all the error and csv files from the folder*/
			File folder = new File(filePath);

			File[] listOfFiles = folder.listFiles();

			for(int i = 0; i < listOfFiles.length; i++)
			{
				String fileName = listOfFiles[i].getName();
				
				
				
				System.out.println(fileName);
				
				if(fileName.contains(type))
				{
					System.out.println(type);
					
					String absoluteFilePath=listOfFiles[i].getAbsolutePath();
					
					System.out.println(absoluteFilePath);
					
					File file = new File(absoluteFilePath);
					
					
					response.setContentType("text/html");  
					PrintWriter out = response.getWriter();  
					
					response.setContentType("APPLICATION/OCTET-STREAM");  
					
					response.setHeader("Content-Disposition","attachment;filename="+fileName);
					
					FileInputStream fileInputStream = new FileInputStream(file); 
					
					int j;   
					while ((j=fileInputStream.read()) != -1) {  
					out.write(j);   
					} 
					
					fileInputStream.close();   
					out.close();   
				}


			}
			
			
			
			
			
			
		}
		catch(Exception e)
		{
			logger.error(e.getMessage());
		}
	}

}
