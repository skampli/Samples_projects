package com.cisco.csv.writer;

import java.io.*;

import javax.servlet.ServletOutputStream;

import org.apache.commons.compress.utils.IOUtils;
import org.apache.commons.compress.archivers.ArchiveOutputStream;
import org.apache.commons.compress.archivers.ArchiveStreamFactory;
import org.apache.commons.compress.archivers.tar.TarArchiveEntry;
import org.apache.log4j.Logger;



public class TarWriter {

	private final static Logger logger = Logger.getLogger(TarWriter.class);
	public void createTar(String absolutePathHeader, String headerFileName, String absolutePathCsv , String fullFileNameTar,ServletOutputStream out, String tarFileName)
	{

		File file=null;

		

		try
		{

			file= new File(tarFileName);
			//OutputStream outputStream = new FileOutputStream(file);
			
			FileWriter fileWriter= new FileWriter(file);
			
			
			logger.info("Writing in the header and csv  for tar");


			ArchiveOutputStream archiveOutputSream = new ArchiveStreamFactory().createArchiveOutputStream(ArchiveStreamFactory.TAR, out);
			
		


			File tarInputFileHeader= new File(absolutePathHeader);
			
			


			TarArchiveEntry tar_file = new TarArchiveEntry(tarInputFileHeader,headerFileName);
			
			

			tar_file.setSize(tarInputFileHeader.length());
			archiveOutputSream.putArchiveEntry(tar_file);


			IOUtils.copy(new FileInputStream(tarInputFileHeader), archiveOutputSream);



			archiveOutputSream.closeArchiveEntry();

			File   tarInputFileCsv= new File(absolutePathCsv);
			
			tar_file = new TarArchiveEntry(tarInputFileCsv,fullFileNameTar);
			
			tar_file.setSize(tarInputFileCsv.length());
			
			archiveOutputSream.putArchiveEntry(tar_file);
			
			IOUtils.copy(new FileInputStream(tarInputFileCsv), archiveOutputSream);

			archiveOutputSream.closeArchiveEntry();
			
			archiveOutputSream.finish(); 


			logger.info("Tar file is created");

			out.close();
			
			fileWriter.close();

		
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}

		

	}

}
