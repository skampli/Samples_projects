package com.cisco.model;

public class ConflictColAttribute {
	
	private String sheetName;
	
	private String columnName;
	
	private String columnValue;
	
	private String attributeColumn;
	
	private int row;

	public String getSheetName() {
		return sheetName;
	}

	public void setSheetName(String sheetName) {
		this.sheetName = sheetName;
	}

	public String getColumnName() {
		return columnName;
	}

	public void setColumnName(String columnName) {
		this.columnName = columnName;
	}

	public String getColumnValue() {
		return columnValue;
	}

	public void setColumnValue(String columnValue) {
		this.columnValue = columnValue;
	}

	public String getAttributeColumn() {
		return attributeColumn;
	}

	public void setAttributeColumn(String attributeColumn) {
		this.attributeColumn = attributeColumn;
	}

	public int getRow() {
		return row;
	}

	public void setRow(int row) {
		this.row = row;
	}
	
	

}
