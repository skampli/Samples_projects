package com.cisco.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="User")
public class User {
	
	@Id
	@Column(name="userId")
	private String userId;
	private String firstname;
	private String lastName;
	private String directoryNumber;
	private String department;
	private String ciscoServicesFramework;
	private String macAddress;
	private String lineCss;
	private String routePartition;
	private String deviceType;
	private String devicePool;
	private String extensionMobility;
	private String non_did_number;
	private String voicemailProfile;
	private String softkeyTemplate;
	private String maxnumcalss;
	private String busyTrigger;
	private String alwaysUsePrimeLineForVoiceMessages ;
	private String privacySettings;
	private String managerUserId;
	private String dummy;
	private String test1;
	private String test2;
	
	
	
	
	public String getTest1() {
		return test1;
	}
	public void setTest1(String test1) {
		this.test1 = test1;
	}
	public String getTest2() {
		return test2;
	}
	public void setTest2(String test2) {
		this.test2 = test2;
	}
	public String getDummy() {
		return dummy;
	}
	public void setDummy(String dummy) {
		this.dummy = dummy;
	}
	public String getDepartment() {
		return department;
	}
	public void setDepartment(String department) {
		this.department = department;
	}
	public String getCiscoServicesFramework() {
		return ciscoServicesFramework;
	}
	public void setCiscoServicesFramework(String ciscoServicesFramework) {
		this.ciscoServicesFramework = ciscoServicesFramework;
	}
	public String getNon_did_number() {
		return non_did_number;
	}
	public void setNon_did_number(String non_did_number) {
		this.non_did_number = non_did_number;
	}
	public String getSoftkeyTemplate() {
		return softkeyTemplate;
	}
	public void setSoftkeyTemplate(String softkeyTemplate) {
		this.softkeyTemplate = softkeyTemplate;
	}
	public String getManagerUserId() {
		return managerUserId;
	}
	public void setManagerUserId(String managerUserId) {
		this.managerUserId = managerUserId;
	}
	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	public String getFirstname() {
		return firstname;
	}
	public void setFirstname(String firstname) {
		this.firstname = firstname;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public String getDirectoryNumber() {
		return directoryNumber;
	}
	public void setDirectoryNumber(String directoryNumber) {
		this.directoryNumber = directoryNumber;
	}
	public String getMacAddress() {
		return macAddress;
	}
	public void setMacAddress(String macAddress) {
		this.macAddress = macAddress;
	}
	public String getLineCss() {
		return lineCss;
	}
	public void setLineCss(String lineCss) {
		this.lineCss = lineCss;
	}
	public String getRoutePartition() {
		return routePartition;
	}
	public void setRoutePartition(String routePartition) {
		this.routePartition = routePartition;
	}
	public String getDeviceType() {
		return deviceType;
	}
	public void setDeviceType(String deviceType) {
		this.deviceType = deviceType;
	}
	public String getDevicePool() {
		return devicePool;
	}
	public void setDevicePool(String devicePool) {
		this.devicePool = devicePool;
	}
	public String getExtensionMobility() {
		return extensionMobility;
	}
	public void setExtensionMobility(String extensionMobility) {
		this.extensionMobility = extensionMobility;
	}
	public String getVoicemailProfile() {
		return voicemailProfile;
	}
	public void setVoicemailProfile(String voicemailProfile) {
		this.voicemailProfile = voicemailProfile;
	}
	public String getMaxnumcalss() {
		return maxnumcalss;
	}
	public void setMaxnumcalss(String maxnumcalss) {
		this.maxnumcalss = maxnumcalss;
	}
	public String getBusyTrigger() {
		return busyTrigger;
	}
	public void setBusyTrigger(String busyTrigger) {
		this.busyTrigger = busyTrigger;
	}
	public String getAlwaysUsePrimeLineForVoiceMessages() {
		return alwaysUsePrimeLineForVoiceMessages;
	}
	public void setAlwaysUsePrimeLineForVoiceMessages(
			String alwaysUsePrimeLineForVoiceMessages) {
		this.alwaysUsePrimeLineForVoiceMessages = alwaysUsePrimeLineForVoiceMessages;
	}
	public String getPrivacySettings() {
		return privacySettings;
	}
	public void setPrivacySettings(String privacySettings) {
		this.privacySettings = privacySettings;
	}
	
	
	
	
	
	
	

}
