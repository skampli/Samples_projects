package com.cisco.model;

public class IsColSubStringAttribute {
	
	private String ColName;
	
	public String getColName() {
		return ColName;
	}
	public void setColName(String colName) {
		ColName = colName;
	}
	public String getAttributeColumn() {
		return attributeColumn;
	}
	public void setAttributeColumn(String attributeColumn) {
		this.attributeColumn = attributeColumn;
	}
	public String getAttributeColValue() {
		return attributeColValue;
	}
	public void setAttributeColValue(String attributeColValue) {
		this.attributeColValue = attributeColValue;
	}
	public String getColValue() {
		return colValue;
	}
	public void setColValue(String colValue) {
		this.colValue = colValue;
	}
	public String getTableName() {
		return tableName;
	}
	public void setTableName(String tableName) {
		this.tableName = tableName;
	}
	public int getRow() {
		return row;
	}
	public void setRow(int row) {
		this.row = row;
	}
	private String attributeColumn;
	
	private String attributeColValue;
	
	private String colValue;
	
	private String tableName;
	private int row;
	
	
	

}
