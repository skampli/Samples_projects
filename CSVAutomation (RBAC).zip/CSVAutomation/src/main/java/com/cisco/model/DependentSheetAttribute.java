package com.cisco.model;

public class DependentSheetAttribute {
	
	private int row;
	
	private String identifierName;
	
	private String tableName;
	
	private String dependentSheet;
	
	private String colValue;

	public String getColValue() {
		return colValue;
	}

	public void setColValue(String colValue) {
		this.colValue = colValue;
	}

	public int getRow() {
		return row;
	}

	public void setRow(int row) {
		this.row = row;
	}

	

	public String getIdentifierName() {
		return identifierName;
	}

	public void setIdentifierName(String identifierName) {
		this.identifierName = identifierName;
	}

	public String getTableName() {
		return tableName;
	}

	public void setTableName(String tableName) {
		this.tableName = tableName;
	}

	public String getDependentSheet() {
		return dependentSheet;
	}

	public void setDependentSheet(String dependentSheet) {
		this.dependentSheet = dependentSheet;
	}
	
	
	

}
