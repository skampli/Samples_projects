package com.cisco.model;

public class DuplicateAttribute {
	
	private String sheetName;
	
	private String ColumnName;
	
	private String ColumnValue;
	
	private String attributeValue;
	
	public String getAttributeValue() {
		return attributeValue;
	}

	public void setAttributeValue(String attributeValue) {
		this.attributeValue = attributeValue;
	}

	private int rowNumber;
	
	public String getColumnValue() {
		return ColumnValue;
	}

	public void setColumnValue(String columnValue) {
		ColumnValue = columnValue;
	}

	

	public String getSheetName() {
		return sheetName;
	}

	public void setSheetName(String sheetName) {
		this.sheetName = sheetName;
	}

	public String getColumnName() {
		return ColumnName;
	}

	public void setColumnName(String columnName) {
		ColumnName = columnName;
	}

	public int getRowNumber() {
		return rowNumber;
	}

	public void setRowNumber(int rowNumber) {
		this.rowNumber = rowNumber;
	}
	
	
	
	

}
