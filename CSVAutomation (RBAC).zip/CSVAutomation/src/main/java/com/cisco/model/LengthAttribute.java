package com.cisco.model;

public class LengthAttribute {
	
	
	private String sheetName;
	
	private String ColumnName;
	
	private int rowNumber;
	
	private int actualColLength;
	
	private String specifiedColLength;
	
	
	public int getActualColLength() {
		return actualColLength;
	}
	
	
	public void setActualColLength(int actualColLength) {
		this.actualColLength = actualColLength;
	}
	
	
	public String getSpecifiedColLength() {
		return specifiedColLength;
	}
	
	
	public void setSpecifiedColLength(String specifiedColLength) {
		this.specifiedColLength = specifiedColLength;
	}
	
	
	public String getSheetName() {
		return sheetName;
	}
	
	
	public void setSheetName(String sheetName) {
		this.sheetName = sheetName;
	}
	
	
	public String getColumnName() {
		return ColumnName;
	}
	
	
	public void setColumnName(String columnName) {
		ColumnName = columnName;
	}
	
	
	public int getRowNumber() {
		return rowNumber;
	}
	
	
	public void setRowNumber(int rowNumber) {
		this.rowNumber = rowNumber;
	}
	
	

}
