package com.cisco.model;

import org.springframework.web.multipart.MultipartFile;

public class UploadedFile {
	MultipartFile file;
	
	public String usexml; 
	
	public String autoMapping;
	
	

	public String getAutoMapping() {
		return autoMapping;
	}

	public void setAutoMapping(String autoMapping) {
		this.autoMapping = autoMapping;
	}

	public String getUsexml() {
		return usexml;
	}

	public void setUsexml(String usexml) {
		this.usexml = usexml;
	}

	public MultipartFile getFile() {
		return file;
	}

	public void setFile(MultipartFile file) {
		this.file = file;
	}
	
	

}
