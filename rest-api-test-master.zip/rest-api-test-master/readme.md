How to test a REST API with JUnit and RESTEasy 3.0
--------------------------------------------------

This sample project is a demo how to test a REST API using JUnit. The REST API itself is provided by the project.

When testing, a tiny web server is started that handles all the requests in-memory.