/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package source;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.StringTokenizer;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

/**
 *
 * @author Shgandla
 */
public class ExcelOperations {

	Map<String, Integer> graphMap = new HashMap<String, Integer>();
	StringTokenizer intgrList;

	public Map<String, Integer> readAndWriteToExcel(String fileName, String closedValue, String junkedValue, String heldValue, 
			String sev3Value, String releaseName, String btagData, String etagData, String tag[], String f[],String c[], String cmkeys[], String fmkeys[],String selbtnep){
		try {
			//graphics declaration
			List<String> graphList = new ArrayList<String>();

			//write operation declaration
			Map<Integer, Object[]> output_data = new HashMap<Integer, Object[]>();
			int index = 1;
			//   output_data.put(index, new Object[]{"Download: 23-FEB-2016 01:18:24PST \n"
			//         + " BUGID (Must be Column A)", "A/C SPECIFIC SEVERITY \n"
			//       + " (0-7, 0=Show Stopper, 7=Info only) \n"
			//     + " (Must be Column B)", "MASTER PROJECT COMMENTS \n"
			//   + " (Must be Column C)", "INCLUDE/EXCLUDE BUG \n"
			// + " (Must be Column D) \n"
			//      + " Blank - Include for this project only \n"
			//    + " FR - Flagged to Review", "As Internal Comments", "SME REVIEWED \n"
			//     + " Blank - no review \n"
			//      + " REVIEW - SME reviewed (no update needed) \n"
			//    + " RNE - SME reviewed (RNE updated) \n"
			//  + " ENG - SME reviewed (Eng-note updated) \n"
			//  + " AS - SME reviewed (AS Internal Comment updated) \n"
			//         + "OTHER - SME reviewed (other enclosure updated)", "LINK TO INTERNAL COMMENTS", "STATE", "SEVERITY", "COMPONENT", "HEADLINE", "VERSIONS-FOUND", "VERSION-INTEGRATED", " SORA HIGHLIGHTED THIS BUG BECAUSE", "AS HISTORY", "RELEASE-NOTE", "ENGNOTES", "SSEVALUATION", "SSREVIEW", "ATTACHMENTS", "CARE-TICKETS", "DUPLICATED BY", "DUPLICATE OF", "FOUND", "AGE", "PRODUCT", " HARDWARE", "KEYWORD", "ATTRIBUTE", "VERSION-TO-BE-FIXED", "VERSION-APPLY-TO", "PROJECT", "EMAIL DE", "TAG", "AS RISK SCORE", "TAG LAST UPDATED BY", "TAG COMMENTS", "COMMON TAG", "LAST MODIFIED BY", "SMU ID", "ELEMENT NAME"});



			//reading operation declaring
			FileInputStream xlFile = new FileInputStream(new File("C:\\Uploads\\" + fileName));
			XSSFWorkbook wbook = new XSSFWorkbook(xlFile);
			XSSFSheet sheet = wbook.getSheetAt(0);
			Iterator<Row> rowIterator = sheet.iterator();
			Cell cell = null;
			Row row = null;
			int rowCounter = 0;

			//intgrated release check variable
			String xcelintRls = null;

			while (rowIterator.hasNext()) {

				row = rowIterator.next();
				Iterator<Cell> cellIterator = row.cellIterator();
				while (cellIterator.hasNext()) {
					cell = cellIterator.next();
				}

				if (cell != null) {

					//#############closed issue logic########################################################
					if (cell.getRow().getCell(6).toString().equalsIgnoreCase(closedValue)) {
						if (Integer.parseInt(cell.getRow().getCell(19).toString()) < 2) {

							index++;
							output_data.put(index, new Object[]{cell.getRow().getCell(0).toString(), cell.getRow().getCell(1).toString(), btagData + " \n As per Golden Rule,This is closed issue with less than 2 service requests \n" + etagData, cell.getRow().getCell(3).toString(), cell.getRow().getCell(4).toString(), cell.getRow().getCell(5).toString(), cell.getRow().getCell(6).toString(), cell.getRow().getCell(7).toString(), cell.getRow().getCell(8).toString(), cell.getRow().getCell(9).toString(), cell.getRow().getCell(10).toString(), cell.getRow().getCell(11).toString(), cell.getRow().getCell(12).toString(), cell.getRow().getCell(13).toString(), cell.getRow().getCell(14).toString(), cell.getRow().getCell(15).toString(), cell.getRow().getCell(16).toString(), cell.getRow().getCell(17).toString(), cell.getRow().getCell(18).toString(), cell.getRow().getCell(19).toString(), cell.getRow().getCell(20).toString(), cell.getRow().getCell(21).toString(), cell.getRow().getCell(22).toString(), cell.getRow().getCell(23).toString(), cell.getRow().getCell(24).toString(), cell.getRow().getCell(25).toString(), cell.getRow().getCell(26).toString(), cell.getRow().getCell(27).toString(), cell.getRow().getCell(28).toString(), cell.getRow().getCell(29).toString(), cell.getRow().getCell(30).toString(), cell.getRow().getCell(31).toString(), cell.getRow().getCell(32).toString(), cell.getRow().getCell(33).toString(), cell.getRow().getCell(34).toString(), cell.getRow().getCell(35).toString(), cell.getRow().getCell(36).toString(), cell.getRow().getCell(37).toString(), cell.getRow().getCell(38).toString(), cell.getRow().getCell(39).toString()

							});

							graphList.add("c");
						} else {
							if (sev3Value.equalsIgnoreCase("y")) {
								if (cell.getRow().getCell(7).toString().equalsIgnoreCase("3")) {
									if (Integer.parseInt(cell.getRow().getCell(19).toString()) == 0) {
										index++;
										output_data.put(index, new Object[]{cell.getRow().getCell(0).toString(), cell.getRow().getCell(1).toString(), btagData + " \n As per Golden Rule,This is Severity 3 Closed issue \n" + etagData, cell.getRow().getCell(3).toString(), cell.getRow().getCell(4).toString(), cell.getRow().getCell(5).toString(), cell.getRow().getCell(6).toString(), cell.getRow().getCell(7).toString(), cell.getRow().getCell(8).toString(), cell.getRow().getCell(9).toString(), cell.getRow().getCell(10).toString(), cell.getRow().getCell(11).toString(), cell.getRow().getCell(12).toString(), cell.getRow().getCell(13).toString(), cell.getRow().getCell(14).toString(), cell.getRow().getCell(15).toString(), cell.getRow().getCell(16).toString(), cell.getRow().getCell(17).toString(), cell.getRow().getCell(18).toString(), cell.getRow().getCell(19).toString(), cell.getRow().getCell(20).toString(), cell.getRow().getCell(21).toString(), cell.getRow().getCell(22).toString(), cell.getRow().getCell(23).toString(), cell.getRow().getCell(24).toString(), cell.getRow().getCell(25).toString(), cell.getRow().getCell(26).toString(), cell.getRow().getCell(27).toString(), cell.getRow().getCell(28).toString(), cell.getRow().getCell(29).toString(), cell.getRow().getCell(30).toString(), cell.getRow().getCell(31).toString(), cell.getRow().getCell(32).toString(), cell.getRow().getCell(33).toString(), cell.getRow().getCell(34).toString(), cell.getRow().getCell(35).toString(), cell.getRow().getCell(36).toString(), cell.getRow().getCell(37).toString(), cell.getRow().getCell(38).toString(), cell.getRow().getCell(39).toString()

										});

										graphList.add("sev3");
									} else {
										index++;
										output_data.put(index, new Object[]{cell.getRow().getCell(0).toString(), cell.getRow().getCell(1).toString(), btagData + " \n " + cell.getRow().getCell(2).toString() + "\n" + etagData, cell.getRow().getCell(3).toString(), cell.getRow().getCell(4).toString(), cell.getRow().getCell(5).toString(), cell.getRow().getCell(6).toString(), cell.getRow().getCell(7).toString(), cell.getRow().getCell(8).toString(), cell.getRow().getCell(9).toString(), cell.getRow().getCell(10).toString(), cell.getRow().getCell(11).toString(), cell.getRow().getCell(12).toString(), cell.getRow().getCell(13).toString(), cell.getRow().getCell(14).toString(), cell.getRow().getCell(15).toString(), cell.getRow().getCell(16).toString(), cell.getRow().getCell(17).toString(), cell.getRow().getCell(18).toString(), cell.getRow().getCell(19).toString(), cell.getRow().getCell(20).toString(), cell.getRow().getCell(21).toString(), cell.getRow().getCell(22).toString(), cell.getRow().getCell(23).toString(), cell.getRow().getCell(24).toString(), cell.getRow().getCell(25).toString(), cell.getRow().getCell(26).toString(), cell.getRow().getCell(27).toString(), cell.getRow().getCell(28).toString(), cell.getRow().getCell(29).toString(), cell.getRow().getCell(30).toString(), cell.getRow().getCell(31).toString(), cell.getRow().getCell(32).toString(), cell.getRow().getCell(33).toString(), cell.getRow().getCell(34).toString(), cell.getRow().getCell(35).toString(), cell.getRow().getCell(36).toString(), cell.getRow().getCell(37).toString(), cell.getRow().getCell(38).toString(), cell.getRow().getCell(39).toString()

										});
									}

								} else {
									if (!releaseName.equalsIgnoreCase("")) {
										intgrList = new StringTokenizer(cell.getRow().getCell(11).toString(), ",");
										int count = 0;
										while (intgrList.hasMoreTokens()) {
											xcelintRls = intgrList.nextToken();

											if (xcelintRls.equalsIgnoreCase(releaseName)) {
												//write logic
												System.out.println("IR is :" + xcelintRls);
												index++;
												output_data.put(index, new Object[]{cell.getRow().getCell(0).toString(), cell.getRow().getCell(1).toString(), btagData + " \n Issue Is Fixed in " + xcelintRls + "\n" + etagData, cell.getRow().getCell(3).toString(), cell.getRow().getCell(4).toString(), cell.getRow().getCell(5).toString(), cell.getRow().getCell(6).toString(), cell.getRow().getCell(7).toString(), cell.getRow().getCell(8).toString(), cell.getRow().getCell(9).toString(), cell.getRow().getCell(10).toString(), cell.getRow().getCell(11).toString(), cell.getRow().getCell(12).toString(), cell.getRow().getCell(13).toString(), cell.getRow().getCell(14).toString(), cell.getRow().getCell(15).toString(), cell.getRow().getCell(16).toString(), cell.getRow().getCell(17).toString(), cell.getRow().getCell(18).toString(), cell.getRow().getCell(19).toString(), cell.getRow().getCell(20).toString(), cell.getRow().getCell(21).toString(), cell.getRow().getCell(22).toString(), cell.getRow().getCell(23).toString(), cell.getRow().getCell(24).toString(), cell.getRow().getCell(25).toString(), cell.getRow().getCell(26).toString(), cell.getRow().getCell(27).toString(), cell.getRow().getCell(28).toString(), cell.getRow().getCell(29).toString(), cell.getRow().getCell(30).toString(), cell.getRow().getCell(31).toString(), cell.getRow().getCell(32).toString(), cell.getRow().getCell(33).toString(), cell.getRow().getCell(34).toString(), cell.getRow().getCell(35).toString(), cell.getRow().getCell(36).toString(), cell.getRow().getCell(37).toString(), cell.getRow().getCell(38).toString(), cell.getRow().getCell(39).toString()

												});

												graphList.add("Int Release");
												count++;
												break;
											}

										}
										if (count == 0) {
											index++;
											output_data.put(index, new Object[]{
													cell.getRow().getCell(0).toString(), 
													cell.getRow().getCell(1).toString(), 
													btagData + " \n " + cell.getRow().getCell(2).toString() + "\n" + etagData, 
													cell.getRow().getCell(3).toString(),  cell.getRow().getCell(4).toString(), 
													cell.getRow().getCell(5).toString(),  cell.getRow().getCell(6).toString(), 
													cell.getRow().getCell(7).toString(),  cell.getRow().getCell(8).toString(), 
													cell.getRow().getCell(9).toString(),  cell.getRow().getCell(10).toString(), 
													cell.getRow().getCell(11).toString(), cell.getRow().getCell(12).toString(), 
													cell.getRow().getCell(13).toString(), cell.getRow().getCell(14).toString(), 
													cell.getRow().getCell(15).toString(), cell.getRow().getCell(16).toString(), 
													cell.getRow().getCell(17).toString(), cell.getRow().getCell(18).toString(), 
													cell.getRow().getCell(19).toString(), cell.getRow().getCell(20).toString(), 
													cell.getRow().getCell(21).toString(), cell.getRow().getCell(22).toString(), 
													cell.getRow().getCell(23).toString(), cell.getRow().getCell(24).toString(), 
													cell.getRow().getCell(25).toString(), cell.getRow().getCell(26).toString(), 
													cell.getRow().getCell(27).toString(), cell.getRow().getCell(28).toString(), 
													cell.getRow().getCell(29).toString(), cell.getRow().getCell(30).toString(), 
													cell.getRow().getCell(31).toString(), cell.getRow().getCell(32).toString(), 
													cell.getRow().getCell(33).toString(), cell.getRow().getCell(34).toString(), 
													cell.getRow().getCell(35).toString(), cell.getRow().getCell(36).toString(), 
													cell.getRow().getCell(37).toString(), cell.getRow().getCell(38).toString(), 
													cell.getRow().getCell(39).toString()
											});
										}

									}

								}
							}
							if (sev3Value.equalsIgnoreCase("na")) {

								if (!releaseName.equalsIgnoreCase("")) {
									intgrList = new StringTokenizer(cell.getRow().getCell(11).toString(), ",");
									int count = 0;
									while (intgrList.hasMoreTokens()) {
										xcelintRls = intgrList.nextToken();

										if (xcelintRls.equalsIgnoreCase(releaseName)) {
											//write logic
											System.out.println("IR is :" + xcelintRls);
											index++;
											output_data.put(index, new Object[]{cell.getRow().getCell(0).toString(), cell.getRow().getCell(1).toString(), btagData + " \n Issue Is Fixed in " + xcelintRls + "\n" + etagData, cell.getRow().getCell(3).toString(), cell.getRow().getCell(4).toString(), cell.getRow().getCell(5).toString(), cell.getRow().getCell(6).toString(), cell.getRow().getCell(7).toString(), cell.getRow().getCell(8).toString(), cell.getRow().getCell(9).toString(), cell.getRow().getCell(10).toString(), cell.getRow().getCell(11).toString(), cell.getRow().getCell(12).toString(), cell.getRow().getCell(13).toString(), cell.getRow().getCell(14).toString(), cell.getRow().getCell(15).toString(), cell.getRow().getCell(16).toString(), cell.getRow().getCell(17).toString(), cell.getRow().getCell(18).toString(), cell.getRow().getCell(19).toString(), cell.getRow().getCell(20).toString(), cell.getRow().getCell(21).toString(), cell.getRow().getCell(22).toString(), cell.getRow().getCell(23).toString(), cell.getRow().getCell(24).toString(), cell.getRow().getCell(25).toString(), cell.getRow().getCell(26).toString(), cell.getRow().getCell(27).toString(), cell.getRow().getCell(28).toString(), cell.getRow().getCell(29).toString(), cell.getRow().getCell(30).toString(), cell.getRow().getCell(31).toString(), cell.getRow().getCell(32).toString(), cell.getRow().getCell(33).toString(), cell.getRow().getCell(34).toString(), cell.getRow().getCell(35).toString(), cell.getRow().getCell(36).toString(), cell.getRow().getCell(37).toString(), cell.getRow().getCell(38).toString(), cell.getRow().getCell(39).toString()

											});

											graphList.add("Int Release");
											count++;
											break;
										}
									}
									if (count == 0) {
										index++;
										output_data.put(index, new Object[]{cell.getRow().getCell(0).toString(), cell.getRow().getCell(1).toString(), btagData + " \n " + cell.getRow().getCell(2).toString() + "\n" + etagData, cell.getRow().getCell(3).toString(), cell.getRow().getCell(4).toString(), cell.getRow().getCell(5).toString(), cell.getRow().getCell(6).toString(), cell.getRow().getCell(7).toString(), cell.getRow().getCell(8).toString(), cell.getRow().getCell(9).toString(), cell.getRow().getCell(10).toString(), cell.getRow().getCell(11).toString(), cell.getRow().getCell(12).toString(), cell.getRow().getCell(13).toString(), cell.getRow().getCell(14).toString(), cell.getRow().getCell(15).toString(), cell.getRow().getCell(16).toString(), cell.getRow().getCell(17).toString(), cell.getRow().getCell(18).toString(), cell.getRow().getCell(19).toString(), cell.getRow().getCell(20).toString(), cell.getRow().getCell(21).toString(), cell.getRow().getCell(22).toString(), cell.getRow().getCell(23).toString(), cell.getRow().getCell(24).toString(), cell.getRow().getCell(25).toString(), cell.getRow().getCell(26).toString(), cell.getRow().getCell(27).toString(), cell.getRow().getCell(28).toString(), cell.getRow().getCell(29).toString(), cell.getRow().getCell(30).toString(), cell.getRow().getCell(31).toString(), cell.getRow().getCell(32).toString(), cell.getRow().getCell(33).toString(), cell.getRow().getCell(34).toString(), cell.getRow().getCell(35).toString(), cell.getRow().getCell(36).toString(), cell.getRow().getCell(37).toString(), cell.getRow().getCell(38).toString(), cell.getRow().getCell(39).toString()

										});
									}
								}

							}

						}

					}
					
					
					
					//###################Junked issue logic#################################################################
					if (cell.getRow().getCell(6).toString().equalsIgnoreCase(junkedValue)) {

						if (Integer.parseInt(cell.getRow().getCell(19).toString()) < 2) {
							index++;
							output_data.put(index, new Object[]{cell.getRow().getCell(0).toString(), cell.getRow().getCell(1).toString(), btagData + " \n As per Golden Rule,This is Junked issue with less than 2 service requests \n" + etagData, cell.getRow().getCell(3).toString(), cell.getRow().getCell(4).toString(), cell.getRow().getCell(5).toString(), cell.getRow().getCell(6).toString(), cell.getRow().getCell(7).toString(), cell.getRow().getCell(8).toString(), cell.getRow().getCell(9).toString(), cell.getRow().getCell(10).toString(), cell.getRow().getCell(11).toString(), cell.getRow().getCell(12).toString(), cell.getRow().getCell(13).toString(), cell.getRow().getCell(14).toString(), cell.getRow().getCell(15).toString(), cell.getRow().getCell(16).toString(), cell.getRow().getCell(17).toString(), cell.getRow().getCell(18).toString(), cell.getRow().getCell(19).toString(), cell.getRow().getCell(20).toString(), cell.getRow().getCell(21).toString(), cell.getRow().getCell(22).toString(), cell.getRow().getCell(23).toString(), cell.getRow().getCell(24).toString(), cell.getRow().getCell(25).toString(), cell.getRow().getCell(26).toString(), cell.getRow().getCell(27).toString(), cell.getRow().getCell(28).toString(), cell.getRow().getCell(29).toString(), cell.getRow().getCell(30).toString(), cell.getRow().getCell(31).toString(), cell.getRow().getCell(32).toString(), cell.getRow().getCell(33).toString(), cell.getRow().getCell(34).toString(), cell.getRow().getCell(35).toString(), cell.getRow().getCell(36).toString(), cell.getRow().getCell(37).toString(), cell.getRow().getCell(38).toString(), cell.getRow().getCell(39).toString()

							});

							graphList.add("j");
						} else {
							if (sev3Value.equalsIgnoreCase("y")) {
								if (cell.getRow().getCell(7).toString().equalsIgnoreCase("3")) {
									if (Integer.parseInt(cell.getRow().getCell(19).toString()) == 0) {
										index++;
										output_data.put(index, new Object[]{cell.getRow().getCell(0).toString(), cell.getRow().getCell(1).toString(), btagData + " \n As per Golden Rule,This is Severity 3 Junked issue \n" + etagData, cell.getRow().getCell(3).toString(), cell.getRow().getCell(4).toString(), cell.getRow().getCell(5).toString(), cell.getRow().getCell(6).toString(), cell.getRow().getCell(7).toString(), cell.getRow().getCell(8).toString(), cell.getRow().getCell(9).toString(), cell.getRow().getCell(10).toString(), cell.getRow().getCell(11).toString(), cell.getRow().getCell(12).toString(), cell.getRow().getCell(13).toString(), cell.getRow().getCell(14).toString(), cell.getRow().getCell(15).toString(), cell.getRow().getCell(16).toString(), cell.getRow().getCell(17).toString(), cell.getRow().getCell(18).toString(), cell.getRow().getCell(19).toString(), cell.getRow().getCell(20).toString(), cell.getRow().getCell(21).toString(), cell.getRow().getCell(22).toString(), cell.getRow().getCell(23).toString(), cell.getRow().getCell(24).toString(), cell.getRow().getCell(25).toString(), cell.getRow().getCell(26).toString(), cell.getRow().getCell(27).toString(), cell.getRow().getCell(28).toString(), cell.getRow().getCell(29).toString(), cell.getRow().getCell(30).toString(), cell.getRow().getCell(31).toString(), cell.getRow().getCell(32).toString(), cell.getRow().getCell(33).toString(), cell.getRow().getCell(34).toString(), cell.getRow().getCell(35).toString(), cell.getRow().getCell(36).toString(), cell.getRow().getCell(37).toString(), cell.getRow().getCell(38).toString(), cell.getRow().getCell(39).toString()

										});

										graphList.add("sev3");
									} else {
										index++;
										output_data.put(index, new Object[]{cell.getRow().getCell(0).toString(), cell.getRow().getCell(1).toString(), btagData + " \n " + cell.getRow().getCell(2).toString() + "\n" + etagData, cell.getRow().getCell(3).toString(), cell.getRow().getCell(4).toString(), cell.getRow().getCell(5).toString(), cell.getRow().getCell(6).toString(), cell.getRow().getCell(7).toString(), cell.getRow().getCell(8).toString(), cell.getRow().getCell(9).toString(), cell.getRow().getCell(10).toString(), cell.getRow().getCell(11).toString(), cell.getRow().getCell(12).toString(), cell.getRow().getCell(13).toString(), cell.getRow().getCell(14).toString(), cell.getRow().getCell(15).toString(), cell.getRow().getCell(16).toString(), cell.getRow().getCell(17).toString(), cell.getRow().getCell(18).toString(), cell.getRow().getCell(19).toString(), cell.getRow().getCell(20).toString(), cell.getRow().getCell(21).toString(), cell.getRow().getCell(22).toString(), cell.getRow().getCell(23).toString(), cell.getRow().getCell(24).toString(), cell.getRow().getCell(25).toString(), cell.getRow().getCell(26).toString(), cell.getRow().getCell(27).toString(), cell.getRow().getCell(28).toString(), cell.getRow().getCell(29).toString(), cell.getRow().getCell(30).toString(), cell.getRow().getCell(31).toString(), cell.getRow().getCell(32).toString(), cell.getRow().getCell(33).toString(), cell.getRow().getCell(34).toString(), cell.getRow().getCell(35).toString(), cell.getRow().getCell(36).toString(), cell.getRow().getCell(37).toString(), cell.getRow().getCell(38).toString(), cell.getRow().getCell(39).toString()

										});
									}

								} else {
									if (!releaseName.equalsIgnoreCase("")) {
										intgrList = new StringTokenizer(cell.getRow().getCell(11).toString(), ",");
										int count = 0;
										while (intgrList.hasMoreTokens()) {
											xcelintRls = intgrList.nextToken();

											if (xcelintRls.equalsIgnoreCase(releaseName)) {
												//write logic
												System.out.println("IR is :" + xcelintRls);
												index++;
												output_data.put(index, new Object[]{cell.getRow().getCell(0).toString(), cell.getRow().getCell(1).toString(), btagData + " \n Issue Is Fixed in " + xcelintRls + "\n" + etagData, cell.getRow().getCell(3).toString(), cell.getRow().getCell(4).toString(), cell.getRow().getCell(5).toString(), cell.getRow().getCell(6).toString(), cell.getRow().getCell(7).toString(), cell.getRow().getCell(8).toString(), cell.getRow().getCell(9).toString(), cell.getRow().getCell(10).toString(), cell.getRow().getCell(11).toString(), cell.getRow().getCell(12).toString(), cell.getRow().getCell(13).toString(), cell.getRow().getCell(14).toString(), cell.getRow().getCell(15).toString(), cell.getRow().getCell(16).toString(), cell.getRow().getCell(17).toString(), cell.getRow().getCell(18).toString(), cell.getRow().getCell(19).toString(), cell.getRow().getCell(20).toString(), cell.getRow().getCell(21).toString(), cell.getRow().getCell(22).toString(), cell.getRow().getCell(23).toString(), cell.getRow().getCell(24).toString(), cell.getRow().getCell(25).toString(), cell.getRow().getCell(26).toString(), cell.getRow().getCell(27).toString(), cell.getRow().getCell(28).toString(), cell.getRow().getCell(29).toString(), cell.getRow().getCell(30).toString(), cell.getRow().getCell(31).toString(), cell.getRow().getCell(32).toString(), cell.getRow().getCell(33).toString(), cell.getRow().getCell(34).toString(), cell.getRow().getCell(35).toString(), cell.getRow().getCell(36).toString(), cell.getRow().getCell(37).toString(), cell.getRow().getCell(38).toString(), cell.getRow().getCell(39).toString()

												});

												graphList.add("Int Release");
												count++;
												break;
											}
										}
										if (count == 0) {
											index++;
											output_data.put(index, new Object[]{cell.getRow().getCell(0).toString(), cell.getRow().getCell(1).toString(), btagData + " \n " + cell.getRow().getCell(2).toString() + "\n" + etagData, cell.getRow().getCell(3).toString(), cell.getRow().getCell(4).toString(), cell.getRow().getCell(5).toString(), cell.getRow().getCell(6).toString(), cell.getRow().getCell(7).toString(), cell.getRow().getCell(8).toString(), cell.getRow().getCell(9).toString(), cell.getRow().getCell(10).toString(), cell.getRow().getCell(11).toString(), cell.getRow().getCell(12).toString(), cell.getRow().getCell(13).toString(), cell.getRow().getCell(14).toString(), cell.getRow().getCell(15).toString(), cell.getRow().getCell(16).toString(), cell.getRow().getCell(17).toString(), cell.getRow().getCell(18).toString(), cell.getRow().getCell(19).toString(), cell.getRow().getCell(20).toString(), cell.getRow().getCell(21).toString(), cell.getRow().getCell(22).toString(), cell.getRow().getCell(23).toString(), cell.getRow().getCell(24).toString(), cell.getRow().getCell(25).toString(), cell.getRow().getCell(26).toString(), cell.getRow().getCell(27).toString(), cell.getRow().getCell(28).toString(), cell.getRow().getCell(29).toString(), cell.getRow().getCell(30).toString(), cell.getRow().getCell(31).toString(), cell.getRow().getCell(32).toString(), cell.getRow().getCell(33).toString(), cell.getRow().getCell(34).toString(), cell.getRow().getCell(35).toString(), cell.getRow().getCell(36).toString(), cell.getRow().getCell(37).toString(), cell.getRow().getCell(38).toString(), cell.getRow().getCell(39).toString()

											});
										}
									}

								}
							}
							if (sev3Value.equalsIgnoreCase("na")) {

								if (!releaseName.equalsIgnoreCase("")) {
									intgrList = new StringTokenizer(cell.getRow().getCell(11).toString(), ",");
									int count = 0;
									while (intgrList.hasMoreTokens()) {
										xcelintRls = intgrList.nextToken();

										if (xcelintRls.equalsIgnoreCase(releaseName)) {
											//write logic
											System.out.println("IR is :" + xcelintRls);
											index++;
											output_data.put(index, new Object[]{cell.getRow().getCell(0).toString(), cell.getRow().getCell(1).toString(), btagData + " \n Issue Is Fixed in " + xcelintRls + "\n" + etagData, cell.getRow().getCell(3).toString(), cell.getRow().getCell(4).toString(), cell.getRow().getCell(5).toString(), cell.getRow().getCell(6).toString(), cell.getRow().getCell(7).toString(), cell.getRow().getCell(8).toString(), cell.getRow().getCell(9).toString(), cell.getRow().getCell(10).toString(), cell.getRow().getCell(11).toString(), cell.getRow().getCell(12).toString(), cell.getRow().getCell(13).toString(), cell.getRow().getCell(14).toString(), cell.getRow().getCell(15).toString(), cell.getRow().getCell(16).toString(), cell.getRow().getCell(17).toString(), cell.getRow().getCell(18).toString(), cell.getRow().getCell(19).toString(), cell.getRow().getCell(20).toString(), cell.getRow().getCell(21).toString(), cell.getRow().getCell(22).toString(), cell.getRow().getCell(23).toString(), cell.getRow().getCell(24).toString(), cell.getRow().getCell(25).toString(), cell.getRow().getCell(26).toString(), cell.getRow().getCell(27).toString(), cell.getRow().getCell(28).toString(), cell.getRow().getCell(29).toString(), cell.getRow().getCell(30).toString(), cell.getRow().getCell(31).toString(), cell.getRow().getCell(32).toString(), cell.getRow().getCell(33).toString(), cell.getRow().getCell(34).toString(), cell.getRow().getCell(35).toString(), cell.getRow().getCell(36).toString(), cell.getRow().getCell(37).toString(), cell.getRow().getCell(38).toString(), cell.getRow().getCell(39).toString()

											});

											graphList.add("Int Release");
											count++;
											break;
										}
									}
									if (count == 0) {
										index++;
										output_data.put(index, new Object[]{cell.getRow().getCell(0).toString(), cell.getRow().getCell(1).toString(), btagData + " \n " + cell.getRow().getCell(2).toString() + "\n" + etagData, cell.getRow().getCell(3).toString(), cell.getRow().getCell(4).toString(), cell.getRow().getCell(5).toString(), cell.getRow().getCell(6).toString(), cell.getRow().getCell(7).toString(), cell.getRow().getCell(8).toString(), cell.getRow().getCell(9).toString(), cell.getRow().getCell(10).toString(), cell.getRow().getCell(11).toString(), cell.getRow().getCell(12).toString(), cell.getRow().getCell(13).toString(), cell.getRow().getCell(14).toString(), cell.getRow().getCell(15).toString(), cell.getRow().getCell(16).toString(), cell.getRow().getCell(17).toString(), cell.getRow().getCell(18).toString(), cell.getRow().getCell(19).toString(), cell.getRow().getCell(20).toString(), cell.getRow().getCell(21).toString(), cell.getRow().getCell(22).toString(), cell.getRow().getCell(23).toString(), cell.getRow().getCell(24).toString(), cell.getRow().getCell(25).toString(), cell.getRow().getCell(26).toString(), cell.getRow().getCell(27).toString(), cell.getRow().getCell(28).toString(), cell.getRow().getCell(29).toString(), cell.getRow().getCell(30).toString(), cell.getRow().getCell(31).toString(), cell.getRow().getCell(32).toString(), cell.getRow().getCell(33).toString(), cell.getRow().getCell(34).toString(), cell.getRow().getCell(35).toString(), cell.getRow().getCell(36).toString(), cell.getRow().getCell(37).toString(), cell.getRow().getCell(38).toString(), cell.getRow().getCell(39).toString()

										});
									}
								}

							}

						}
					}
					
					
					//#############held issue logic#################################################################

					if (cell.getRow().getCell(6).toString().equalsIgnoreCase(heldValue)) {
						if (Integer.parseInt(cell.getRow().getCell(19).toString()) < 2) {
							index++;
							output_data.put(index, new Object[]{cell.getRow().getCell(0).toString(), cell.getRow().getCell(1).toString(), btagData + " \n As per Golden Rule,This is Held issue with less than 2 service requests \n" + etagData, cell.getRow().getCell(3).toString(), cell.getRow().getCell(4).toString(), cell.getRow().getCell(5).toString(), cell.getRow().getCell(6).toString(), cell.getRow().getCell(7).toString(), cell.getRow().getCell(8).toString(), cell.getRow().getCell(9).toString(), cell.getRow().getCell(10).toString(), cell.getRow().getCell(11).toString(), cell.getRow().getCell(12).toString(), cell.getRow().getCell(13).toString(), cell.getRow().getCell(14).toString(), cell.getRow().getCell(15).toString(), cell.getRow().getCell(16).toString(), cell.getRow().getCell(17).toString(), cell.getRow().getCell(18).toString(), cell.getRow().getCell(19).toString(), cell.getRow().getCell(20).toString(), cell.getRow().getCell(21).toString(), cell.getRow().getCell(22).toString(), cell.getRow().getCell(23).toString(), cell.getRow().getCell(24).toString(), cell.getRow().getCell(25).toString(), cell.getRow().getCell(26).toString(), cell.getRow().getCell(27).toString(), cell.getRow().getCell(28).toString(), cell.getRow().getCell(29).toString(), cell.getRow().getCell(30).toString(), cell.getRow().getCell(31).toString(), cell.getRow().getCell(32).toString(), cell.getRow().getCell(33).toString(), cell.getRow().getCell(34).toString(), cell.getRow().getCell(35).toString(), cell.getRow().getCell(36).toString(), cell.getRow().getCell(37).toString(), cell.getRow().getCell(38).toString(), cell.getRow().getCell(39).toString()

							});

							graphList.add("h");
						} else {
							if (sev3Value.equalsIgnoreCase("y")) {
								if (cell.getRow().getCell(7).toString().equalsIgnoreCase("3")) {
									if (Integer.parseInt(cell.getRow().getCell(19).toString()) == 0) {
										index++;
										output_data.put(index, new Object[]{cell.getRow().getCell(0).toString(), cell.getRow().getCell(1).toString(), btagData + " \n As per Golden Rule,This is Severity 3 Held issue\n" + etagData, cell.getRow().getCell(3).toString(), cell.getRow().getCell(4).toString(), cell.getRow().getCell(5).toString(), cell.getRow().getCell(6).toString(), cell.getRow().getCell(7).toString(), cell.getRow().getCell(8).toString(), cell.getRow().getCell(9).toString(), cell.getRow().getCell(10).toString(), cell.getRow().getCell(11).toString(), cell.getRow().getCell(12).toString(), cell.getRow().getCell(13).toString(), cell.getRow().getCell(14).toString(), cell.getRow().getCell(15).toString(), cell.getRow().getCell(16).toString(), cell.getRow().getCell(17).toString(), cell.getRow().getCell(18).toString(), cell.getRow().getCell(19).toString(), cell.getRow().getCell(20).toString(), cell.getRow().getCell(21).toString(), cell.getRow().getCell(22).toString(), cell.getRow().getCell(23).toString(), cell.getRow().getCell(24).toString(), cell.getRow().getCell(25).toString(), cell.getRow().getCell(26).toString(), cell.getRow().getCell(27).toString(), cell.getRow().getCell(28).toString(), cell.getRow().getCell(29).toString(), cell.getRow().getCell(30).toString(), cell.getRow().getCell(31).toString(), cell.getRow().getCell(32).toString(), cell.getRow().getCell(33).toString(), cell.getRow().getCell(34).toString(), cell.getRow().getCell(35).toString(), cell.getRow().getCell(36).toString(), cell.getRow().getCell(37).toString(), cell.getRow().getCell(38).toString(), cell.getRow().getCell(39).toString()

										});

										graphList.add("sev3");
									} else {
										index++;
										output_data.put(index, new Object[]{cell.getRow().getCell(0).toString(), cell.getRow().getCell(1).toString(), btagData + " \n " + cell.getRow().getCell(2).toString() + "\n" + etagData, cell.getRow().getCell(3).toString(), cell.getRow().getCell(4).toString(), cell.getRow().getCell(5).toString(), cell.getRow().getCell(6).toString(), cell.getRow().getCell(7).toString(), cell.getRow().getCell(8).toString(), cell.getRow().getCell(9).toString(), cell.getRow().getCell(10).toString(), cell.getRow().getCell(11).toString(), cell.getRow().getCell(12).toString(), cell.getRow().getCell(13).toString(), cell.getRow().getCell(14).toString(), cell.getRow().getCell(15).toString(), cell.getRow().getCell(16).toString(), cell.getRow().getCell(17).toString(), cell.getRow().getCell(18).toString(), cell.getRow().getCell(19).toString(), cell.getRow().getCell(20).toString(), cell.getRow().getCell(21).toString(), cell.getRow().getCell(22).toString(), cell.getRow().getCell(23).toString(), cell.getRow().getCell(24).toString(), cell.getRow().getCell(25).toString(), cell.getRow().getCell(26).toString(), cell.getRow().getCell(27).toString(), cell.getRow().getCell(28).toString(), cell.getRow().getCell(29).toString(), cell.getRow().getCell(30).toString(), cell.getRow().getCell(31).toString(), cell.getRow().getCell(32).toString(), cell.getRow().getCell(33).toString(), cell.getRow().getCell(34).toString(), cell.getRow().getCell(35).toString(), cell.getRow().getCell(36).toString(), cell.getRow().getCell(37).toString(), cell.getRow().getCell(38).toString(), cell.getRow().getCell(39).toString()

										});
									}

								} else {
									if (!releaseName.equalsIgnoreCase("")) {
										intgrList = new StringTokenizer(cell.getRow().getCell(11).toString(), ",");
										int count = 0;
										while (intgrList.hasMoreTokens()) {
											xcelintRls = intgrList.nextToken();

											if (xcelintRls.equalsIgnoreCase(releaseName)) {
												//write logic
												System.out.println("IR is :" + xcelintRls);
												index++;
												output_data.put(index, new Object[]{cell.getRow().getCell(0).toString(), cell.getRow().getCell(1).toString(), btagData + " \n Issue Is Fixed in " + xcelintRls + "\n" + etagData, cell.getRow().getCell(3).toString(), cell.getRow().getCell(4).toString(), cell.getRow().getCell(5).toString(), cell.getRow().getCell(6).toString(), cell.getRow().getCell(7).toString(), cell.getRow().getCell(8).toString(), cell.getRow().getCell(9).toString(), cell.getRow().getCell(10).toString(), cell.getRow().getCell(11).toString(), cell.getRow().getCell(12).toString(), cell.getRow().getCell(13).toString(), cell.getRow().getCell(14).toString(), cell.getRow().getCell(15).toString(), cell.getRow().getCell(16).toString(), cell.getRow().getCell(17).toString(), cell.getRow().getCell(18).toString(), cell.getRow().getCell(19).toString(), cell.getRow().getCell(20).toString(), cell.getRow().getCell(21).toString(), cell.getRow().getCell(22).toString(), cell.getRow().getCell(23).toString(), cell.getRow().getCell(24).toString(), cell.getRow().getCell(25).toString(), cell.getRow().getCell(26).toString(), cell.getRow().getCell(27).toString(), cell.getRow().getCell(28).toString(), cell.getRow().getCell(29).toString(), cell.getRow().getCell(30).toString(), cell.getRow().getCell(31).toString(), cell.getRow().getCell(32).toString(), cell.getRow().getCell(33).toString(), cell.getRow().getCell(34).toString(), cell.getRow().getCell(35).toString(), cell.getRow().getCell(36).toString(), cell.getRow().getCell(37).toString(), cell.getRow().getCell(38).toString(), cell.getRow().getCell(39).toString()

												});

												graphList.add("Int Release");
												count++;
												break;
											}
										}
										if (count == 0) {
											index++;
											output_data.put(index, new Object[]{cell.getRow().getCell(0).toString(), cell.getRow().getCell(1).toString(), btagData + " \n " + cell.getRow().getCell(2).toString() + "\n" + etagData, cell.getRow().getCell(3).toString(), cell.getRow().getCell(4).toString(), cell.getRow().getCell(5).toString(), cell.getRow().getCell(6).toString(), cell.getRow().getCell(7).toString(), cell.getRow().getCell(8).toString(), cell.getRow().getCell(9).toString(), cell.getRow().getCell(10).toString(), cell.getRow().getCell(11).toString(), cell.getRow().getCell(12).toString(), cell.getRow().getCell(13).toString(), cell.getRow().getCell(14).toString(), cell.getRow().getCell(15).toString(), cell.getRow().getCell(16).toString(), cell.getRow().getCell(17).toString(), cell.getRow().getCell(18).toString(), cell.getRow().getCell(19).toString(), cell.getRow().getCell(20).toString(), cell.getRow().getCell(21).toString(), cell.getRow().getCell(22).toString(), cell.getRow().getCell(23).toString(), cell.getRow().getCell(24).toString(), cell.getRow().getCell(25).toString(), cell.getRow().getCell(26).toString(), cell.getRow().getCell(27).toString(), cell.getRow().getCell(28).toString(), cell.getRow().getCell(29).toString(), cell.getRow().getCell(30).toString(), cell.getRow().getCell(31).toString(), cell.getRow().getCell(32).toString(), cell.getRow().getCell(33).toString(), cell.getRow().getCell(34).toString(), cell.getRow().getCell(35).toString(), cell.getRow().getCell(36).toString(), cell.getRow().getCell(37).toString(), cell.getRow().getCell(38).toString(), cell.getRow().getCell(39).toString()

											});
										}
									}

								}
							}
							if (sev3Value.equalsIgnoreCase("na")) {

								if (!releaseName.equalsIgnoreCase("")) {
									intgrList = new StringTokenizer(cell.getRow().getCell(11).toString(), ",");
									int count = 0;
									while (intgrList.hasMoreTokens()) {
										xcelintRls = intgrList.nextToken();

										if (xcelintRls.equalsIgnoreCase(releaseName)) {
											//write logic
											System.out.println("IR is :" + xcelintRls);
											index++;
											output_data.put(index, new Object[]{cell.getRow().getCell(0).toString(), cell.getRow().getCell(1).toString(), btagData + " \n Issue Is Fixed in " + xcelintRls + "\n" + etagData, cell.getRow().getCell(3).toString(), cell.getRow().getCell(4).toString(), cell.getRow().getCell(5).toString(), cell.getRow().getCell(6).toString(), cell.getRow().getCell(7).toString(), cell.getRow().getCell(8).toString(), cell.getRow().getCell(9).toString(), cell.getRow().getCell(10).toString(), cell.getRow().getCell(11).toString(), cell.getRow().getCell(12).toString(), cell.getRow().getCell(13).toString(), cell.getRow().getCell(14).toString(), cell.getRow().getCell(15).toString(), cell.getRow().getCell(16).toString(), cell.getRow().getCell(17).toString(), cell.getRow().getCell(18).toString(), cell.getRow().getCell(19).toString(), cell.getRow().getCell(20).toString(), cell.getRow().getCell(21).toString(), cell.getRow().getCell(22).toString(), cell.getRow().getCell(23).toString(), cell.getRow().getCell(24).toString(), cell.getRow().getCell(25).toString(), cell.getRow().getCell(26).toString(), cell.getRow().getCell(27).toString(), cell.getRow().getCell(28).toString(), cell.getRow().getCell(29).toString(), cell.getRow().getCell(30).toString(), cell.getRow().getCell(31).toString(), cell.getRow().getCell(32).toString(), cell.getRow().getCell(33).toString(), cell.getRow().getCell(34).toString(), cell.getRow().getCell(35).toString(), cell.getRow().getCell(36).toString(), cell.getRow().getCell(37).toString(), cell.getRow().getCell(38).toString(), cell.getRow().getCell(39).toString()

											});

											graphList.add("Int Release");
											count++;
											break;
										}
									}
									if (count == 0) {
										index++;
										output_data.put(index, new Object[]{cell.getRow().getCell(0).toString(), cell.getRow().getCell(1).toString(), btagData + " \n " + cell.getRow().getCell(2).toString() + "\n" + etagData, cell.getRow().getCell(3).toString(), cell.getRow().getCell(4).toString(), cell.getRow().getCell(5).toString(), cell.getRow().getCell(6).toString(), cell.getRow().getCell(7).toString(), cell.getRow().getCell(8).toString(), cell.getRow().getCell(9).toString(), cell.getRow().getCell(10).toString(), cell.getRow().getCell(11).toString(), cell.getRow().getCell(12).toString(), cell.getRow().getCell(13).toString(), cell.getRow().getCell(14).toString(), cell.getRow().getCell(15).toString(), cell.getRow().getCell(16).toString(), cell.getRow().getCell(17).toString(), cell.getRow().getCell(18).toString(), cell.getRow().getCell(19).toString(), cell.getRow().getCell(20).toString(), cell.getRow().getCell(21).toString(), cell.getRow().getCell(22).toString(), cell.getRow().getCell(23).toString(), cell.getRow().getCell(24).toString(), cell.getRow().getCell(25).toString(), cell.getRow().getCell(26).toString(), cell.getRow().getCell(27).toString(), cell.getRow().getCell(28).toString(), cell.getRow().getCell(29).toString(), cell.getRow().getCell(30).toString(), cell.getRow().getCell(31).toString(), cell.getRow().getCell(32).toString(), cell.getRow().getCell(33).toString(), cell.getRow().getCell(34).toString(), cell.getRow().getCell(35).toString(), cell.getRow().getCell(36).toString(), cell.getRow().getCell(37).toString(), cell.getRow().getCell(38).toString(), cell.getRow().getCell(39).toString()

										});
									}
								}

							}

						}
					}
					if (sev3Value.equalsIgnoreCase("y")) {
						if (!(cell.getRow().getCell(6).toString().equalsIgnoreCase(closedValue) || cell.getRow().getCell(6).toString().equalsIgnoreCase(junkedValue) || cell.getRow().getCell(6).toString().equalsIgnoreCase(heldValue))) {
							if (cell.getRow().getCell(7).toString().equalsIgnoreCase("3")) {
								if (Integer.parseInt(cell.getRow().getCell(19).toString()) == 0) {
									index++;
									output_data.put(index, new Object[]{cell.getRow().getCell(0).toString(), cell.getRow().getCell(1).toString(), btagData + " \n As per Golden Rule,This is Severity 3 issue \n" + etagData, cell.getRow().getCell(3).toString(), cell.getRow().getCell(4).toString(), cell.getRow().getCell(5).toString(), cell.getRow().getCell(6).toString(), cell.getRow().getCell(7).toString(), cell.getRow().getCell(8).toString(), cell.getRow().getCell(9).toString(), cell.getRow().getCell(10).toString(), cell.getRow().getCell(11).toString(), cell.getRow().getCell(12).toString(), cell.getRow().getCell(13).toString(), cell.getRow().getCell(14).toString(), cell.getRow().getCell(15).toString(), cell.getRow().getCell(16).toString(), cell.getRow().getCell(17).toString(), cell.getRow().getCell(18).toString(), cell.getRow().getCell(19).toString(), cell.getRow().getCell(20).toString(), cell.getRow().getCell(21).toString(), cell.getRow().getCell(22).toString(), cell.getRow().getCell(23).toString(), cell.getRow().getCell(24).toString(), cell.getRow().getCell(25).toString(), cell.getRow().getCell(26).toString(), cell.getRow().getCell(27).toString(), cell.getRow().getCell(28).toString(), cell.getRow().getCell(29).toString(), cell.getRow().getCell(30).toString(), cell.getRow().getCell(31).toString(), cell.getRow().getCell(32).toString(), cell.getRow().getCell(33).toString(), cell.getRow().getCell(34).toString(), cell.getRow().getCell(35).toString(), cell.getRow().getCell(36).toString(), cell.getRow().getCell(37).toString(), cell.getRow().getCell(38).toString(), cell.getRow().getCell(39).toString()

									});

									graphList.add("sev3");
								} 

								else 
								{
									if (!releaseName.equalsIgnoreCase("")) {
										intgrList = new StringTokenizer(cell.getRow().getCell(11).toString(), ",");
										int count = 0;
										int reslt = 0;
										while (intgrList.hasMoreTokens()) {
											xcelintRls = intgrList.nextToken();

											if (xcelintRls.equalsIgnoreCase(releaseName)) {
												//write logic
												System.out.println("IR is :" + xcelintRls);
												index++;
												output_data.put(index, new Object[]{cell.getRow().getCell(0).toString(), cell.getRow().getCell(1).toString(), btagData + " \n Issue Is Fixed in " + xcelintRls + "\n" + etagData, cell.getRow().getCell(3).toString(), cell.getRow().getCell(4).toString(), cell.getRow().getCell(5).toString(), cell.getRow().getCell(6).toString(), cell.getRow().getCell(7).toString(), cell.getRow().getCell(8).toString(), cell.getRow().getCell(9).toString(), cell.getRow().getCell(10).toString(), cell.getRow().getCell(11).toString(), cell.getRow().getCell(12).toString(), cell.getRow().getCell(13).toString(), cell.getRow().getCell(14).toString(), cell.getRow().getCell(15).toString(), cell.getRow().getCell(16).toString(), cell.getRow().getCell(17).toString(), cell.getRow().getCell(18).toString(), cell.getRow().getCell(19).toString(), cell.getRow().getCell(20).toString(), cell.getRow().getCell(21).toString(), cell.getRow().getCell(22).toString(), cell.getRow().getCell(23).toString(), cell.getRow().getCell(24).toString(), cell.getRow().getCell(25).toString(), cell.getRow().getCell(26).toString(), cell.getRow().getCell(27).toString(), cell.getRow().getCell(28).toString(), cell.getRow().getCell(29).toString(), cell.getRow().getCell(30).toString(), cell.getRow().getCell(31).toString(), cell.getRow().getCell(32).toString(), cell.getRow().getCell(33).toString(), cell.getRow().getCell(34).toString(), cell.getRow().getCell(35).toString(), cell.getRow().getCell(36).toString(), cell.getRow().getCell(37).toString(), cell.getRow().getCell(38).toString(), cell.getRow().getCell(39).toString()

												});

												graphList.add("Int Release");
												count++;
												reslt++;
												break;
											}
										}
										int ite = 0;
										int countnew = 0;

										if (tag != null || f != null) {

											for (int i = 0; i < tag.length; i++) {
												if (reslt == 0){
													if (cell.getRow().getCell(32).toString().toLowerCase().contains(tag[i])) {
														index++;
														output_data.put(index, new Object[]{cell.getRow().getCell(0).toString(), cell.getRow().getCell(1).toString(), btagData + " \n Exclude : As per Tag - " + tag[i] + " issue.      \n" + etagData, cell.getRow().getCell(3).toString(), cell.getRow().getCell(4).toString(), cell.getRow().getCell(5).toString(), cell.getRow().getCell(6).toString(), cell.getRow().getCell(7).toString(), cell.getRow().getCell(8).toString(), cell.getRow().getCell(9).toString(), cell.getRow().getCell(10).toString(), cell.getRow().getCell(11).toString(), cell.getRow().getCell(12).toString(), cell.getRow().getCell(13).toString(), cell.getRow().getCell(14).toString(), cell.getRow().getCell(15).toString(), cell.getRow().getCell(16).toString(), cell.getRow().getCell(17).toString(), cell.getRow().getCell(18).toString(), cell.getRow().getCell(19).toString(), cell.getRow().getCell(20).toString(), cell.getRow().getCell(21).toString(), cell.getRow().getCell(22).toString(), cell.getRow().getCell(23).toString(), cell.getRow().getCell(24).toString(), cell.getRow().getCell(25).toString(), cell.getRow().getCell(26).toString(), cell.getRow().getCell(27).toString(), cell.getRow().getCell(28).toString(), cell.getRow().getCell(29).toString(), cell.getRow().getCell(30).toString(), cell.getRow().getCell(31).toString(), cell.getRow().getCell(32).toString(), cell.getRow().getCell(33).toString(), cell.getRow().getCell(34).toString(), cell.getRow().getCell(35).toString(), cell.getRow().getCell(36).toString(), cell.getRow().getCell(37).toString(), cell.getRow().getCell(38).toString(), cell.getRow().getCell(39).toString()
														});
														graphList.add("tagc");
														ite++;
														continue;
													}
												}
											}
											if(ite == 0){
												String fval[] = null;
												try {
													if(selbtnep.equalsIgnoreCase("configflist")){
														fval= c;
													}else if(selbtnep.equalsIgnoreCase("featurelist")){
														fval =f;
													}
												} catch (Exception e) {
													System.out.println("chcek fval size "+e.getMessage());
												}

												for (int x = 0; x < fval.length; x++) {

													if ( ( cell.getRow().getCell(9).toString().toLowerCase().contains(fval[x]) && 
															cell.getRow().getCell(14).toString().toLowerCase().matches("(?s)(.*)conditions:(.*)"+fval[x]+"(?s)(.*)workaround:(.*)") && 
															!((cell.getRow().getCell(9).toString().toLowerCase().contains("/"+fval[x])) || 
																	cell.getRow().getCell(9).toString().toLowerCase().contains(fval[x]+"/") || 
																	(cell.getRow().getCell(9).toString().toLowerCase().contains("/ "+fval[x])) || 
																	cell.getRow().getCell(9).toString().toLowerCase().contains(fval[x]+" /") || 
																	cell.getRow().getCell(9).toString().toLowerCase().contains(" or ")) )
															|| cell.getRow().getCell(32).toString().toLowerCase().contains(fval[x])   ) {

														//exclude bug if it is configured for both protocols
														String mprotocol = fval[x].toLowerCase().trim();
														boolean skipEx = false;														


														if(selbtnep.equalsIgnoreCase("configflist")){
															//iterate mprotocol with matched config keyset 
															for(int y = 0; y < cmkeys.length; y++){
																if(cell.getRow().getCell(9).toString().toLowerCase().contains(cmkeys[y]) && 
																		cell.getRow().getCell(9).toString().toLowerCase().contains(mprotocol)){
																	skipEx = true;
																	break;
																}else if(cell.getRow().getCell(14).toString().toLowerCase().contains(cmkeys[y]) && 
																		cell.getRow().getCell(14).toString().toLowerCase().contains(mprotocol)){
																	skipEx = true;
																	break;
																}else if(cell.getRow().getCell(32).toString().toLowerCase().contains(cmkeys[y]) && 
																		cell.getRow().getCell(32).toString().toLowerCase().contains(mprotocol)){
																	skipEx = true;
																	break;
																}
															}
														}else if(selbtnep.equalsIgnoreCase("featurelist")){
															//iterate mprotocol with matched config keyset 
															for(int z = 0; z < fmkeys.length; z++){
																if(cell.getRow().getCell(9).toString().toLowerCase().contains(fmkeys[z]) && 
																		cell.getRow().getCell(9).toString().toLowerCase().contains(mprotocol)){
																	skipEx = true;
																	break;
																}else if(cell.getRow().getCell(14).toString().toLowerCase().contains(fmkeys[z]) && 
																		cell.getRow().getCell(14).toString().toLowerCase().contains(mprotocol)){
																	skipEx = true;
																	break;
																}else if(cell.getRow().getCell(32).toString().toLowerCase().contains(fmkeys[z]) && 
																		cell.getRow().getCell(32).toString().toLowerCase().contains(mprotocol)){
																	skipEx = true;
																	break;
																}
															}
														}



														if(skipEx == false){
															index++;
															output_data.put(index, new Object[]{cell.getRow().getCell(0).toString(), 
																	cell.getRow().getCell(1).toString(), 
																	btagData + " \n Exclude :  " + fval[x] + " not used.      \n" + etagData, 
																	cell.getRow().getCell(3).toString(),cell.getRow().getCell(4).toString(), 
																	cell.getRow().getCell(5).toString(),cell.getRow().getCell(6).toString(), 
																	cell.getRow().getCell(7).toString(),cell.getRow().getCell(8).toString(), 
																	cell.getRow().getCell(9).toString(),cell.getRow().getCell(10).toString(), 
																	cell.getRow().getCell(11).toString(),cell.getRow().getCell(12).toString(), 
																	cell.getRow().getCell(13).toString(),cell.getRow().getCell(14).toString(),
																	cell.getRow().getCell(15).toString(), 
																	cell.getRow().getCell(16).toString(),cell.getRow().getCell(17).toString(), 
																	cell.getRow().getCell(18).toString(),cell.getRow().getCell(19).toString(), 
																	cell.getRow().getCell(20).toString(),cell.getRow().getCell(21).toString(), 
																	cell.getRow().getCell(22).toString(),cell.getRow().getCell(23).toString(), 
																	cell.getRow().getCell(24).toString(),cell.getRow().getCell(25).toString(), 
																	cell.getRow().getCell(26).toString(),cell.getRow().getCell(27).toString(), 
																	cell.getRow().getCell(28).toString(),cell.getRow().getCell(29).toString(), 
																	cell.getRow().getCell(30).toString(),cell.getRow().getCell(31).toString(), 
																	cell.getRow().getCell(32).toString(),cell.getRow().getCell(33).toString(), 
																	cell.getRow().getCell(34).toString(),cell.getRow().getCell(35).toString(), 
																	cell.getRow().getCell(36).toString(),cell.getRow().getCell(37).toString(), 
																	cell.getRow().getCell(38).toString(),cell.getRow().getCell(39).toString()
															});
															graphList.add("f");
															countnew++;
															continue;
														}

													}
												}
											}
										}
										if (count == 0 && countnew == 0 && ite == 0) {
											index++;
											output_data.put(index, new Object[]{cell.getRow().getCell(0).toString(), cell.getRow().getCell(1).toString(), btagData + " \n " + cell.getRow().getCell(2).toString() + "\n" + etagData, cell.getRow().getCell(3).toString(), cell.getRow().getCell(4).toString(), cell.getRow().getCell(5).toString(), cell.getRow().getCell(6).toString(), cell.getRow().getCell(7).toString(), cell.getRow().getCell(8).toString(), cell.getRow().getCell(9).toString(), cell.getRow().getCell(10).toString(), cell.getRow().getCell(11).toString(), cell.getRow().getCell(12).toString(), cell.getRow().getCell(13).toString(), cell.getRow().getCell(14).toString(), cell.getRow().getCell(15).toString(), cell.getRow().getCell(16).toString(), cell.getRow().getCell(17).toString(), cell.getRow().getCell(18).toString(), cell.getRow().getCell(19).toString(), cell.getRow().getCell(20).toString(), cell.getRow().getCell(21).toString(), cell.getRow().getCell(22).toString(), cell.getRow().getCell(23).toString(), cell.getRow().getCell(24).toString(), cell.getRow().getCell(25).toString(), cell.getRow().getCell(26).toString(), cell.getRow().getCell(27).toString(), cell.getRow().getCell(28).toString(), cell.getRow().getCell(29).toString(), cell.getRow().getCell(30).toString(), cell.getRow().getCell(31).toString(), cell.getRow().getCell(32).toString(), cell.getRow().getCell(33).toString(), cell.getRow().getCell(34).toString(), cell.getRow().getCell(35).toString(), cell.getRow().getCell(36).toString(), cell.getRow().getCell(37).toString(), cell.getRow().getCell(38).toString(), cell.getRow().getCell(39).toString()

											});
										}
									}


								}

							} else {
								if (!releaseName.equalsIgnoreCase("")) {
									intgrList = new StringTokenizer(cell.getRow().getCell(11).toString(), ",");
									int count = 0;
									int reslt = 0;
									while (intgrList.hasMoreTokens()) {
										xcelintRls = intgrList.nextToken();

										if (xcelintRls.equalsIgnoreCase(releaseName)) {
											//write logic
											System.out.println("IR is :" + xcelintRls);
											index++;
											output_data.put(index, new Object[]{cell.getRow().getCell(0).toString(), cell.getRow().getCell(1).toString(), btagData + " \n Issue Is Fixed in " + xcelintRls + "\n" + etagData, cell.getRow().getCell(3).toString(), cell.getRow().getCell(4).toString(), cell.getRow().getCell(5).toString(), cell.getRow().getCell(6).toString(), cell.getRow().getCell(7).toString(), cell.getRow().getCell(8).toString(), cell.getRow().getCell(9).toString(), cell.getRow().getCell(10).toString(), cell.getRow().getCell(11).toString(), cell.getRow().getCell(12).toString(), cell.getRow().getCell(13).toString(), cell.getRow().getCell(14).toString(), cell.getRow().getCell(15).toString(), cell.getRow().getCell(16).toString(), cell.getRow().getCell(17).toString(), cell.getRow().getCell(18).toString(), cell.getRow().getCell(19).toString(), cell.getRow().getCell(20).toString(), cell.getRow().getCell(21).toString(), cell.getRow().getCell(22).toString(), cell.getRow().getCell(23).toString(), cell.getRow().getCell(24).toString(), cell.getRow().getCell(25).toString(), cell.getRow().getCell(26).toString(), cell.getRow().getCell(27).toString(), cell.getRow().getCell(28).toString(), cell.getRow().getCell(29).toString(), cell.getRow().getCell(30).toString(), cell.getRow().getCell(31).toString(), cell.getRow().getCell(32).toString(), cell.getRow().getCell(33).toString(), cell.getRow().getCell(34).toString(), cell.getRow().getCell(35).toString(), cell.getRow().getCell(36).toString(), cell.getRow().getCell(37).toString(), cell.getRow().getCell(38).toString(), cell.getRow().getCell(39).toString()

											});

											graphList.add("Int Release");
											count++;
											reslt++;
											break;
										}
									}
									int ite = 0;
									int countnew = 0;

									if (tag != null || f != null) {
										if (reslt == 0){
											for (int i = 0; i < tag.length; i++) {

												if (cell.getRow().getCell(32).toString().toLowerCase().contains(tag[i])) {
													index++;
													output_data.put(index, new Object[]{cell.getRow().getCell(0).toString(), cell.getRow().getCell(1).toString(), btagData + " \n Exclude : As per Tag - " + tag[i] + " issue.      \n" + etagData, cell.getRow().getCell(3).toString(), cell.getRow().getCell(4).toString(), cell.getRow().getCell(5).toString(), cell.getRow().getCell(6).toString(), cell.getRow().getCell(7).toString(), cell.getRow().getCell(8).toString(), cell.getRow().getCell(9).toString(), cell.getRow().getCell(10).toString(), cell.getRow().getCell(11).toString(), cell.getRow().getCell(12).toString(), cell.getRow().getCell(13).toString(), cell.getRow().getCell(14).toString(), cell.getRow().getCell(15).toString(), cell.getRow().getCell(16).toString(), cell.getRow().getCell(17).toString(), cell.getRow().getCell(18).toString(), cell.getRow().getCell(19).toString(), cell.getRow().getCell(20).toString(), cell.getRow().getCell(21).toString(), cell.getRow().getCell(22).toString(), cell.getRow().getCell(23).toString(), cell.getRow().getCell(24).toString(), cell.getRow().getCell(25).toString(), cell.getRow().getCell(26).toString(), cell.getRow().getCell(27).toString(), cell.getRow().getCell(28).toString(), cell.getRow().getCell(29).toString(), cell.getRow().getCell(30).toString(), cell.getRow().getCell(31).toString(), cell.getRow().getCell(32).toString(), cell.getRow().getCell(33).toString(), cell.getRow().getCell(34).toString(), cell.getRow().getCell(35).toString(), cell.getRow().getCell(36).toString(), cell.getRow().getCell(37).toString(), cell.getRow().getCell(38).toString(), cell.getRow().getCell(39).toString()
													});
													graphList.add("tagc");
													ite++;
													continue;
												}
											}
										}


										if(ite == 0){

											String fval[] = null;
											try {
												if(selbtnep.equalsIgnoreCase("configflist")){
													fval= c;
												}else if(selbtnep.equalsIgnoreCase("featurelist")){
													fval =f;
												}
											} catch (Exception e) {
												System.out.println("chcek fval size "+e.getMessage());
											}

											for (int x = 0; x < fval.length; x++) {

												if ( ( cell.getRow().getCell(9).toString().toLowerCase().contains(fval[x]) && 
														cell.getRow().getCell(14).toString().toLowerCase().matches("(?s)(.*)conditions:(.*)"+fval[x]+"(?s)(.*)workaround:(.*)") && 
														!((cell.getRow().getCell(9).toString().toLowerCase().contains("/"+fval[x])) || 
																cell.getRow().getCell(9).toString().toLowerCase().contains(fval[x]+"/") || 
																(cell.getRow().getCell(9).toString().toLowerCase().contains("/ "+fval[x])) || 
																cell.getRow().getCell(9).toString().toLowerCase().contains(fval[x]+" /") || 
																cell.getRow().getCell(9).toString().toLowerCase().contains(" or ")) )
														|| cell.getRow().getCell(32).toString().toLowerCase().contains(fval[x])   ) {

													//exclude bug if it is configured for both protocols
													String mprotocol = fval[x].toLowerCase().trim();
													boolean skipEx = false;														


													if(selbtnep.equalsIgnoreCase("configflist")){
														//iterate mprotocol with matched config keyset 
														for(int y = 0; y < cmkeys.length; y++){
															if(cell.getRow().getCell(9).toString().toLowerCase().contains(cmkeys[y]) && 
																	cell.getRow().getCell(9).toString().toLowerCase().contains(mprotocol)){
																skipEx = true;
																break;
															}else if(cell.getRow().getCell(14).toString().toLowerCase().contains(cmkeys[y]) && 
																	cell.getRow().getCell(14).toString().toLowerCase().contains(mprotocol)){
																skipEx = true;
																break;
															}else if(cell.getRow().getCell(32).toString().toLowerCase().contains(cmkeys[y]) && 
																	cell.getRow().getCell(32).toString().toLowerCase().contains(mprotocol)){
																skipEx = true;
																break;
															}
														}
													}else if(selbtnep.equalsIgnoreCase("featurelist")){
														//iterate mprotocol with matched config keyset 
														for(int z = 0; z < fmkeys.length; z++){
															if(cell.getRow().getCell(9).toString().toLowerCase().contains(fmkeys[z]) && 
																	cell.getRow().getCell(9).toString().toLowerCase().contains(mprotocol)){
																skipEx = true;
																break;
															}else if(cell.getRow().getCell(14).toString().toLowerCase().contains(fmkeys[z]) && 
																	cell.getRow().getCell(14).toString().toLowerCase().contains(mprotocol)){
																skipEx = true;
																break;
															}else if(cell.getRow().getCell(32).toString().toLowerCase().contains(fmkeys[z]) && 
																	cell.getRow().getCell(32).toString().toLowerCase().contains(mprotocol)){
																skipEx = true;
																break;
															}
														}
													}

													if(skipEx == false){
														index++;
														output_data.put(index, new Object[]{cell.getRow().getCell(0).toString(), cell.getRow().getCell(1).toString(), btagData + " \n Exclude :  " + fval[x] + " not used.      \n" + etagData, cell.getRow().getCell(3).toString(), cell.getRow().getCell(4).toString(), cell.getRow().getCell(5).toString(), cell.getRow().getCell(6).toString(), cell.getRow().getCell(7).toString(), cell.getRow().getCell(8).toString(), cell.getRow().getCell(9).toString(), cell.getRow().getCell(10).toString(), cell.getRow().getCell(11).toString(), cell.getRow().getCell(12).toString(), cell.getRow().getCell(13).toString(), cell.getRow().getCell(14).toString(), cell.getRow().getCell(15).toString(), cell.getRow().getCell(16).toString(), cell.getRow().getCell(17).toString(), cell.getRow().getCell(18).toString(), cell.getRow().getCell(19).toString(), cell.getRow().getCell(20).toString(), cell.getRow().getCell(21).toString(), cell.getRow().getCell(22).toString(), cell.getRow().getCell(23).toString(), cell.getRow().getCell(24).toString(), cell.getRow().getCell(25).toString(), cell.getRow().getCell(26).toString(), cell.getRow().getCell(27).toString(), cell.getRow().getCell(28).toString(), cell.getRow().getCell(29).toString(), cell.getRow().getCell(30).toString(), cell.getRow().getCell(31).toString(), cell.getRow().getCell(32).toString(), cell.getRow().getCell(33).toString(), cell.getRow().getCell(34).toString(), cell.getRow().getCell(35).toString(), cell.getRow().getCell(36).toString(), cell.getRow().getCell(37).toString(), cell.getRow().getCell(38).toString(), cell.getRow().getCell(39).toString()
														});
														graphList.add("f");
														countnew++;
														continue;
													}
												}
											}
										}
									}
									if (count == 0 && countnew == 0 && ite == 0) {
										index++;
										output_data.put(index, new Object[]{cell.getRow().getCell(0).toString(), cell.getRow().getCell(1).toString(), btagData + " \n " + cell.getRow().getCell(2).toString() + "\n" + etagData, cell.getRow().getCell(3).toString(), cell.getRow().getCell(4).toString(), cell.getRow().getCell(5).toString(), cell.getRow().getCell(6).toString(), cell.getRow().getCell(7).toString(), cell.getRow().getCell(8).toString(), cell.getRow().getCell(9).toString(), cell.getRow().getCell(10).toString(), cell.getRow().getCell(11).toString(), cell.getRow().getCell(12).toString(), cell.getRow().getCell(13).toString(), cell.getRow().getCell(14).toString(), cell.getRow().getCell(15).toString(), cell.getRow().getCell(16).toString(), cell.getRow().getCell(17).toString(), cell.getRow().getCell(18).toString(), cell.getRow().getCell(19).toString(), cell.getRow().getCell(20).toString(), cell.getRow().getCell(21).toString(), cell.getRow().getCell(22).toString(), cell.getRow().getCell(23).toString(), cell.getRow().getCell(24).toString(), cell.getRow().getCell(25).toString(), cell.getRow().getCell(26).toString(), cell.getRow().getCell(27).toString(), cell.getRow().getCell(28).toString(), cell.getRow().getCell(29).toString(), cell.getRow().getCell(30).toString(), cell.getRow().getCell(31).toString(), cell.getRow().getCell(32).toString(), cell.getRow().getCell(33).toString(), cell.getRow().getCell(34).toString(), cell.getRow().getCell(35).toString(), cell.getRow().getCell(36).toString(), cell.getRow().getCell(37).toString(), cell.getRow().getCell(38).toString(), cell.getRow().getCell(39).toString()

										});
									}
								}

							}
						}

					}
					if (sev3Value.equalsIgnoreCase("na")) {

						if (!(cell.getRow().getCell(6).toString().equalsIgnoreCase(closedValue) || cell.getRow().getCell(6).toString().equalsIgnoreCase(junkedValue) || cell.getRow().getCell(6).toString().equalsIgnoreCase(heldValue))) {

							if (!releaseName.equalsIgnoreCase("")) {

								intgrList = new StringTokenizer(cell.getRow().getCell(11).toString(), ",");
								int count = 0;
								int reslt = 0;
								while (intgrList.hasMoreTokens()) {
									xcelintRls = intgrList.nextToken();

									if (xcelintRls.equalsIgnoreCase(releaseName)) {
										//write logic

										System.out.println("IR is :" + xcelintRls);
										index++;
										output_data.put(index, new Object[]{cell.getRow().getCell(0).toString(), cell.getRow().getCell(1).toString(), btagData + " \n Issue Is Fixed in " + xcelintRls + "\n" + etagData, cell.getRow().getCell(3).toString(), cell.getRow().getCell(4).toString(), cell.getRow().getCell(5).toString(), cell.getRow().getCell(6).toString(), cell.getRow().getCell(7).toString(), cell.getRow().getCell(8).toString(), cell.getRow().getCell(9).toString(), cell.getRow().getCell(10).toString(), cell.getRow().getCell(11).toString(), cell.getRow().getCell(12).toString(), cell.getRow().getCell(13).toString(), cell.getRow().getCell(14).toString(), cell.getRow().getCell(15).toString(), cell.getRow().getCell(16).toString(), cell.getRow().getCell(17).toString(), cell.getRow().getCell(18).toString(), cell.getRow().getCell(19).toString(), cell.getRow().getCell(20).toString(), cell.getRow().getCell(21).toString(), cell.getRow().getCell(22).toString(), cell.getRow().getCell(23).toString(), cell.getRow().getCell(24).toString(), cell.getRow().getCell(25).toString(), cell.getRow().getCell(26).toString(), cell.getRow().getCell(27).toString(), cell.getRow().getCell(28).toString(), cell.getRow().getCell(29).toString(), cell.getRow().getCell(30).toString(), cell.getRow().getCell(31).toString(), cell.getRow().getCell(32).toString(), cell.getRow().getCell(33).toString(), cell.getRow().getCell(34).toString(), cell.getRow().getCell(35).toString(), cell.getRow().getCell(36).toString(), cell.getRow().getCell(37).toString(), cell.getRow().getCell(38).toString(), cell.getRow().getCell(39).toString()

										});

										graphList.add("Int Release");
										count++;
										reslt++;
										break;
									}
								}

								int ite = 0;
								int countnew = 0;

								if (tag != null || f != null) {

									if (reslt == 0){
										for (int i = 0; i < tag.length; i++) {

											if (cell.getRow().getCell(32).toString().toLowerCase().contains(tag[i])) {
												index++;
												output_data.put(index, new Object[]{cell.getRow().getCell(0).toString(), cell.getRow().getCell(1).toString(), btagData + " \n Exclude : As per Tag - " + tag[i] + " issue.      \n" + etagData, cell.getRow().getCell(3).toString(), cell.getRow().getCell(4).toString(), cell.getRow().getCell(5).toString(), cell.getRow().getCell(6).toString(), cell.getRow().getCell(7).toString(), cell.getRow().getCell(8).toString(), cell.getRow().getCell(9).toString(), cell.getRow().getCell(10).toString(), cell.getRow().getCell(11).toString(), cell.getRow().getCell(12).toString(), cell.getRow().getCell(13).toString(), cell.getRow().getCell(14).toString(), cell.getRow().getCell(15).toString(), cell.getRow().getCell(16).toString(), cell.getRow().getCell(17).toString(), cell.getRow().getCell(18).toString(), cell.getRow().getCell(19).toString(), cell.getRow().getCell(20).toString(), cell.getRow().getCell(21).toString(), cell.getRow().getCell(22).toString(), cell.getRow().getCell(23).toString(), cell.getRow().getCell(24).toString(), cell.getRow().getCell(25).toString(), cell.getRow().getCell(26).toString(), cell.getRow().getCell(27).toString(), cell.getRow().getCell(28).toString(), cell.getRow().getCell(29).toString(), cell.getRow().getCell(30).toString(), cell.getRow().getCell(31).toString(), cell.getRow().getCell(32).toString(), cell.getRow().getCell(33).toString(), cell.getRow().getCell(34).toString(), cell.getRow().getCell(35).toString(), cell.getRow().getCell(36).toString(), cell.getRow().getCell(37).toString(), cell.getRow().getCell(38).toString(), cell.getRow().getCell(39).toString()
												});
												graphList.add("tagc");
												ite++;
												continue;
											}
										}
									}
									if(ite == 0){

										String fval[] = null;
										try {
											if(selbtnep.equalsIgnoreCase("configflist")){
												fval= c;
											}else if(selbtnep.equalsIgnoreCase("featurelist")){
												fval =f;
											}
										} catch (Exception e) {
											System.out.println("chcek fval size "+e.getMessage());
										}

										for (int x = 0; x < fval.length; x++) {

											if ( ( cell.getRow().getCell(9).toString().toLowerCase().contains(fval[x]) && 
													cell.getRow().getCell(14).toString().toLowerCase().matches("(?s)(.*)conditions:(.*)"+fval[x]+"(?s)(.*)workaround:(.*)") && 
													!((cell.getRow().getCell(9).toString().toLowerCase().contains("/"+fval[x])) || 
															cell.getRow().getCell(9).toString().toLowerCase().contains(fval[x]+"/") || 
															(cell.getRow().getCell(9).toString().toLowerCase().contains("/ "+fval[x])) || 
															cell.getRow().getCell(9).toString().toLowerCase().contains(fval[x]+" /") || 
															cell.getRow().getCell(9).toString().toLowerCase().contains(" or ")) )
													|| cell.getRow().getCell(32).toString().toLowerCase().contains(fval[x])   ) {

												//exclude bug if it is configured for both protocols
												String mprotocol = fval[x].toLowerCase().trim();
												boolean skipEx = false;														


												if(selbtnep.equalsIgnoreCase("configflist")){
													//iterate mprotocol with matched config keyset 
													for(int y = 0; y < cmkeys.length; y++){
														if(cell.getRow().getCell(9).toString().toLowerCase().contains(cmkeys[y]) && 
																cell.getRow().getCell(9).toString().toLowerCase().contains(mprotocol)){
															skipEx = true;
															break;
														}else if(cell.getRow().getCell(14).toString().toLowerCase().contains(cmkeys[y]) && 
																cell.getRow().getCell(14).toString().toLowerCase().contains(mprotocol)){
															skipEx = true;
															break;
														}else if(cell.getRow().getCell(32).toString().toLowerCase().contains(cmkeys[y]) && 
																cell.getRow().getCell(32).toString().toLowerCase().contains(mprotocol)){
															skipEx = true;
															break;
														}
													}
												}else if(selbtnep.equalsIgnoreCase("featurelist")){
													//iterate mprotocol with matched config keyset 
													for(int z = 0; z < fmkeys.length; z++){
														if(cell.getRow().getCell(9).toString().toLowerCase().contains(fmkeys[z]) && 
																cell.getRow().getCell(9).toString().toLowerCase().contains(mprotocol)){
															skipEx = true;
															break;
														}else if(cell.getRow().getCell(14).toString().toLowerCase().contains(fmkeys[z]) && 
																cell.getRow().getCell(14).toString().toLowerCase().contains(mprotocol)){
															skipEx = true;
															break;
														}else if(cell.getRow().getCell(32).toString().toLowerCase().contains(fmkeys[z]) && 
																cell.getRow().getCell(32).toString().toLowerCase().contains(mprotocol)){
															skipEx = true;
															break;
														}
													}
												}


												if(skipEx == false){
													index++;
													output_data.put(index, new Object[]{cell.getRow().getCell(0).toString(), cell.getRow().getCell(1).toString(), btagData + " \n Exclude :  " + fval[x] + " not used.      \n" + etagData, cell.getRow().getCell(3).toString(), cell.getRow().getCell(4).toString(), cell.getRow().getCell(5).toString(), cell.getRow().getCell(6).toString(), cell.getRow().getCell(7).toString(), cell.getRow().getCell(8).toString(), cell.getRow().getCell(9).toString(), cell.getRow().getCell(10).toString(), cell.getRow().getCell(11).toString(), cell.getRow().getCell(12).toString(), cell.getRow().getCell(13).toString(), cell.getRow().getCell(14).toString(), cell.getRow().getCell(15).toString(), cell.getRow().getCell(16).toString(), cell.getRow().getCell(17).toString(), cell.getRow().getCell(18).toString(), cell.getRow().getCell(19).toString(), cell.getRow().getCell(20).toString(), cell.getRow().getCell(21).toString(), cell.getRow().getCell(22).toString(), cell.getRow().getCell(23).toString(), cell.getRow().getCell(24).toString(), cell.getRow().getCell(25).toString(), cell.getRow().getCell(26).toString(), cell.getRow().getCell(27).toString(), cell.getRow().getCell(28).toString(), cell.getRow().getCell(29).toString(), cell.getRow().getCell(30).toString(), cell.getRow().getCell(31).toString(), cell.getRow().getCell(32).toString(), cell.getRow().getCell(33).toString(), cell.getRow().getCell(34).toString(), cell.getRow().getCell(35).toString(), cell.getRow().getCell(36).toString(), cell.getRow().getCell(37).toString(), cell.getRow().getCell(38).toString(), cell.getRow().getCell(39).toString()
													});
													graphList.add("f");
													countnew++;
													continue;
												}
											}
										}
									}
								}
								if (count == 0 && countnew == 0 && ite == 0) {
									index++;
									output_data.put(index, new Object[]{cell.getRow().getCell(0).toString(), cell.getRow().getCell(1).toString(), btagData + " \n " + cell.getRow().getCell(2).toString() + "\n" + etagData, cell.getRow().getCell(3).toString(), cell.getRow().getCell(4).toString(), cell.getRow().getCell(5).toString(), cell.getRow().getCell(6).toString(), cell.getRow().getCell(7).toString(), cell.getRow().getCell(8).toString(), cell.getRow().getCell(9).toString(), cell.getRow().getCell(10).toString(), cell.getRow().getCell(11).toString(), cell.getRow().getCell(12).toString(), cell.getRow().getCell(13).toString(), cell.getRow().getCell(14).toString(), cell.getRow().getCell(15).toString(), cell.getRow().getCell(16).toString(), cell.getRow().getCell(17).toString(), cell.getRow().getCell(18).toString(), cell.getRow().getCell(19).toString(), cell.getRow().getCell(20).toString(), cell.getRow().getCell(21).toString(), cell.getRow().getCell(22).toString(), cell.getRow().getCell(23).toString(), cell.getRow().getCell(24).toString(), cell.getRow().getCell(25).toString(), cell.getRow().getCell(26).toString(), cell.getRow().getCell(27).toString(), cell.getRow().getCell(28).toString(), cell.getRow().getCell(29).toString(), cell.getRow().getCell(30).toString(), cell.getRow().getCell(31).toString(), cell.getRow().getCell(32).toString(), cell.getRow().getCell(33).toString(), cell.getRow().getCell(34).toString(), cell.getRow().getCell(35).toString(), cell.getRow().getCell(36).toString(), cell.getRow().getCell(37).toString(), cell.getRow().getCell(38).toString(), cell.getRow().getCell(39).toString()

									});
								}

								/*        if (count == 0) {
                                 index++;
                                 output_data.put(index, new Object[]{cell.getRow().getCell(0).toString(), cell.getRow().getCell(1).toString(), btagData + " \n " + cell.getRow().getCell(2).toString() + "\n" + etagData, cell.getRow().getCell(3).toString(), cell.getRow().getCell(4).toString(), cell.getRow().getCell(5).toString(), cell.getRow().getCell(6).toString(), cell.getRow().getCell(7).toString(), cell.getRow().getCell(8).toString(), cell.getRow().getCell(9).toString(), cell.getRow().getCell(10).toString(), cell.getRow().getCell(11).toString(), cell.getRow().getCell(12).toString(), cell.getRow().getCell(13).toString(), cell.getRow().getCell(14).toString(), cell.getRow().getCell(15).toString(), cell.getRow().getCell(16).toString(), cell.getRow().getCell(17).toString(), cell.getRow().getCell(18).toString(), cell.getRow().getCell(19).toString(), cell.getRow().getCell(20).toString(), cell.getRow().getCell(21).toString(), cell.getRow().getCell(22).toString(), cell.getRow().getCell(23).toString(), cell.getRow().getCell(24).toString(), cell.getRow().getCell(25).toString(), cell.getRow().getCell(26).toString(), cell.getRow().getCell(27).toString(), cell.getRow().getCell(28).toString(), cell.getRow().getCell(29).toString(), cell.getRow().getCell(30).toString(), cell.getRow().getCell(31).toString(), cell.getRow().getCell(32).toString(), cell.getRow().getCell(33).toString(), cell.getRow().getCell(34).toString(), cell.getRow().getCell(35).toString(), cell.getRow().getCell(36).toString(), cell.getRow().getCell(37).toString(), cell.getRow().getCell(38).toString(), cell.getRow().getCell(39).toString()

                                 });
                                 } */
							}

						}

					}


				}

				rowCounter++;

			}
			System.out.println("output_data map size: " + output_data.size());
			System.out.println("graphList/excludedBug size: "+graphList.size());

			xlFile.close();

			//Graphics Implementation            
			int cKey = 0, hKey = 0, jKey = 0, sevKey = 0, ReleaseKey = 0, tag1 = 0, fe = 0;

			for (String value : graphList) {
				if (value.equalsIgnoreCase("c")) {
					cKey++;
				}
				if (value.equalsIgnoreCase("tagc")) {
					tag1++;
				}

				if (value.equalsIgnoreCase("f")) {
					fe++;
				}

				if (value.equalsIgnoreCase("j")) {
					jKey++;
				}
				if (value.equalsIgnoreCase("h")) {
					hKey++;
				}
				if (value.equalsIgnoreCase("sev3")) {
					sevKey++;
				}
				if (value.equalsIgnoreCase("Int Release")) {
					ReleaseKey++;
				}

			}
			System.out.println("total rows printin:(row countewr) " + rowCounter);
			graphMap.put("cKey", cKey);
			graphMap.put("jKey", jKey);
			graphMap.put("tag1", tag1);
			graphMap.put("fe", fe);

			graphMap.put("hKey", hKey);
			graphMap.put("sevKey", sevKey);
			graphMap.put("ReleaseKey", ReleaseKey);
			graphMap.put("totalrows", --rowCounter);

			//write to new file
			XSSFWorkbook wwbook = new XSSFWorkbook();
			XSSFSheet wsheet = wwbook.createSheet("AllBugs-" + fileName);
			Set<Integer> keySet = output_data.keySet();

			int rownum = 0;
			for (int key : keySet) {
				row = wsheet.createRow(rownum++);

				Object[] objArr = output_data.get(key);
				int cellnum = 0;
				for (Object obj : objArr) {
					cell = row.createCell(cellnum++);
					if (obj instanceof String) {
						//3900 char max count taken by SORA excel so trimming it to 3899
						if(((String) obj).length() <3899){
							cell.setCellValue((String) obj);							
						}else{
							cell.setCellValue((String) obj.toString().subSequence(0, 3899));
						}
					}
				}

			}
			String downloadPath = "C:\\Downloads\\";
			File downloadFile = new File(downloadPath);
			if (!downloadFile.exists()) {
				downloadFile.mkdirs();
			}
			FileOutputStream out = new FileOutputStream(new File(downloadPath + "AllBugs-" + fileName));
			wwbook.write(out);
			out.close();

		} catch (FileNotFoundException e) {
			System.out.println(e.getMessage());
		} catch (IOException e) {
			System.out.println(e.getMessage());
		}

		return graphMap;
	}

}
