/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package source;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.OutputStream;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author karkala
 */
@WebServlet(name = "IncludeDownloadServlet", urlPatterns = {"/IncludeDownloadServlet"})
public class IncludeDownloadServlet extends HttpServlet {

 @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        // reads input file from an absolute path
        String fileName = request.getParameter("fileName");        
        String filePath = "C:\\Downloads\\";
        File fileDownload = new File(filePath + "IncludedBugs-" + fileName);
        FileInputStream istream = null;
        OutputStream outStream = null;
        try {

            istream = new FileInputStream(fileDownload);
            ServletContext context = getServletContext();
            String mimeType = context.getMimeType(filePath + "IncludedBugs-" + fileName);
            if (mimeType == null) {
                // set to binary type if MIME mapping not found
                mimeType = "application/vnd.ms-excel";
            }

            // modifies response
            response.setContentType(mimeType);
            response.setContentLength((int) (fileDownload.length()));

            // forces download
            String headerKey = "Content-Disposition";
            String headerValue = String.format("attachment; filename=\"%s\"", fileDownload.getName());
            response.setHeader(headerKey, headerValue);

            // obtains response's output stream
            outStream = response.getOutputStream();
            int bytesRead = -1;
            while ((bytesRead = istream.read()) != -1) {
                outStream.write(bytesRead);

            }

           //getServletContext().getRequestDispatcher("/result.jsp").forward(request, response);
        } catch (IOException e) {
        } finally {
            istream.close();
            outStream.close();
        }

    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
