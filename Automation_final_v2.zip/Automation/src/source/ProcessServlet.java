/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package source;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

/**
 *
 * @author karkala
 */
@WebServlet(name = "ProcessServlet", urlPatterns = {"/ProcessServlet"})
public class ProcessServlet extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String fileName = request.getParameter("fileName");       
        String closedValue = request.getParameter("closedValue");
        String junkValue = request.getParameter("junkValue");
        String heldValue = request.getParameter("heldValue");
        String sev3Value = request.getParameter("sev3Value");
        String releaseName = request.getParameter("releaseName");
        String btagData = request.getParameter("btagData");
        String etagData = request.getParameter("etagData");
        String tag[]= request.getParameterValues("tag");
        String f[]= request.getParameterValues("f");
        
        String c[]= request.getParameterValues("c");
        
        String selbtnep = request.getParameter("flist");
        
        String fmkeys[]= request.getParameterValues("fmp");
        
        String cmkeys[]= request.getParameterValues("cmp");
        
        

        System.out.println("tag data is :" + btagData + " " + etagData);
        if (btagData.equalsIgnoreCase("<Begin Tag>")) {
            btagData = "";
        }
        if (etagData.equalsIgnoreCase("<end Tag>")) {
            etagData = "";
        }

        if (!fileName.equals("null")) {

            //call read methodby passing
          /*  ExcelOperations rw = new ExcelOperations();
            Map<String, Integer> resultMap = rw.readAndWriteToExcel(fileName, closedValue, junkValue, heldValue, 
            		sev3Value, releaseName, btagData, etagData, tag, f);*/
            
        	
        	//code get hclms size 
        	FileInputStream uploadedfile = new FileInputStream(new File("C:\\Uploads\\" + fileName));
        	XSSFWorkbook wb = new XSSFWorkbook(uploadedfile);
    		XSSFSheet sheet = wb.getSheetAt(0);
    		XSSFRow row = null ; 
    		XSSFCell cell;

    		Iterator<Row> rows = sheet.rowIterator();
    		boolean skiprow =true;
    		List<String> hrow= new ArrayList<String>();
    		while (rows.hasNext() && skiprow ){
    			row=(XSSFRow) rows.next();
    			Iterator<Cell> cells = row.cellIterator();

    			while (cells.hasNext())
    			{
    				cell=(XSSFCell) cells.next();
    				hrow.add(cell.getStringCellValue().replaceAll("\\s+",""));
    			}
    			skiprow = false;
    		}
    		uploadedfile.close();
    		System.out.println("Hcolumn size: "+hrow.size());
    		
    		Map<String, Integer> resultMap = new HashMap<String, Integer>();
    		
    		if(hrow.size() == 40){
    			ExcelOperations rw = new ExcelOperations();
    			resultMap= rw.readAndWriteToExcel(fileName, closedValue, junkValue, heldValue,sev3Value, releaseName, btagData, etagData, tag, f, c, cmkeys, fmkeys, selbtnep);
    		}else if(hrow.size() == 41){
    			BugFilteringProcess re = new BugFilteringProcess();
    			resultMap = re.readAndWriteToExcel(fileName, closedValue, junkValue, heldValue, sev3Value, releaseName, btagData, etagData, tag, f, c, cmkeys, fmkeys, selbtnep);
    		}
        	
            if (!resultMap.isEmpty()) {
                request.setAttribute("fileName", fileName);
                request.setAttribute("resultMap", resultMap);

                int csum = (Integer) resultMap.get("cKey");
                int jsum = (Integer) resultMap.get("jKey");
                int hsum = (Integer) resultMap.get("hKey");
                int fet = (Integer) resultMap.get("fe");
                int tagd = (Integer) resultMap.get("tag1");
                int sevsum = (Integer) resultMap.get("sevKey");
                int releasesum = (Integer) resultMap.get("ReleaseKey");

                int bugsExcluded = csum + jsum + hsum + sevsum + releasesum + tagd + fet ;
                int toatalRows = (Integer) resultMap.get("totalrows");
                float exclPercent = (bugsExcluded * 100) / toatalRows;
                int bugsAnalyzed = toatalRows - bugsExcluded;

                request.setAttribute("bugsAnalyzed", bugsAnalyzed);
                request.setAttribute("bugsExcluded", bugsExcluded);
                request.setAttribute("exclPercent", exclPercent);
                request.setAttribute("totalRows", toatalRows);

                IncludeExcelOperation ieo = new IncludeExcelOperation();
                
                if(selbtnep.equalsIgnoreCase("featurelist")){
                	 ieo.readAndWriteToExcel(fileName, closedValue, junkValue, heldValue, sev3Value, releaseName, btagData, etagData, tag, f);
                }else if(selbtnep.equalsIgnoreCase("configflist")){
                	 ieo.readAndWriteToExcel(fileName, closedValue, junkValue, heldValue, sev3Value, releaseName, btagData, etagData, tag, c);
                }
               

                getServletContext().getRequestDispatcher("/result.jsp").forward(request, response);

            }

        }

    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
