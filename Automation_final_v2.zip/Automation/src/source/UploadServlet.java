/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package source;

import java.io.File;
import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;

import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.Part;

/**
 *
 * @author karkala
 */
@WebServlet("/UploadServlet")
@MultipartConfig(fileSizeThreshold = 1024 * 1024 * 10, // 10 MB 
        maxFileSize = 1024 * 1024 * 50, // 50 MB
        maxRequestSize = 1024 * 1024 * 100)      // 100 MB)
public class UploadServlet extends HttpServlet {

    private final String filepath = "C:\\Uploads\\";

     
    @Override
    protected void doPost(
            HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        File uploadingFile = new File(filepath);

        if (!uploadingFile.exists()) {
            uploadingFile.mkdirs();
        }

        String fileName = null;

        for (Part part : request.getParts()) {
           
            fileName = getFileName(part);
            part.write(filepath + File.separator + fileName);
            request.setAttribute("filename", fileName);
            getServletContext().getRequestDispatcher("/index.jsp").forward(
                    request, response);

        }
        
    }

    private String getFileName(Part part) {

        String contentDisp = part.getHeader("content-disposition");

        String tokens[] = contentDisp.split(";");
        for (String token : tokens) {

            if (token.trim().startsWith("filename")) {
                return token.substring(token.indexOf("=") + 2, token.length() - 1);
            }
        }
        return "";
    }

}
