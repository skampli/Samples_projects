/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package source;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;
import java.util.StringTokenizer;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.apache.poi.xssf.usermodel.XSSFFont;
import org.apache.poi.xssf.usermodel.XSSFCellStyle;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRichTextString;

/**
 *
 * @author Shgandla
 */
public class IncludeExcelOperation {

    StringTokenizer intgrList;

    public void readAndWriteToExcel(String fileName, String closedValue, String junkedValue, String heldValue, String sev3Value, String releaseName, String btagData, String etagData, String tag[], String f[]) {
        try {
            //graphics declaration

            //write operation declaration
            Map<Integer, Object[]> output_data = new HashMap<Integer, Object[]>();
            int index = 1;
            /**
             * output_data.put(index, new Object[]{"Download: 23-FEB-2016
             * 01:18:24PST \n" + " BUGID (Must be Column A)", "A/C SPECIFIC
             * SEVERITY \n" + " (0-7, 0=Show Stopper, 7=Info only) \n" + " (Must
             * be Column B)", "MASTER PROJECT COMMENTS \n" + " (Must be Column
             * C)", "INCLUDE/EXCLUDE BUG \n" + " (Must be Column D) \n" + "
             * Blank - Include for this project only \n" + " FR - Flagged to
             * Review", "SME REVIEWED \n" + " Blank - no review \n" + " REVIEW -
             * SME reviewed (no update needed) \n" + " RNE - SME reviewed (RNE
             * updated) \n" + " ENG - SME reviewed (Eng-note updated) \n" + " AS
             * - SME reviewed (AS Internal Comment updated) \n" + " OTHER - SME
             * reviewed (other enclosure updated)", "LINK TO INTERNAL COMMENTS",
             * "STATE", "SEVERITY", "COMPONENT", "HEADLINE", "VERSIONS-FOUND",
             * "VERSION-INTEGRATED", " SORA HIGHLIGHTED THIS BUG BECAUSE", "AS
             * HISTORY", "RELEASE-NOTE", "ENGNOTES", "SSEVALUATION", "SSREVIEW",
             * "ATTACHMENTS", "CARE-TICKETS", "DUPLICATED BY", "DUPLICATE OF",
             * "FOUND", "AGE", "PRODUCT", " HARDWARE", "KEYWORD", "ATTRIBUTE",
             * "VERSION-TO-BE-FIXED", "VERSION-APPLY-TO", "PROJECT", "EMAIL DE",
             * "TAG", "AS RISK SCORE", "TAG LAST UPDATED BY", "TAG COMMENTS",
             * "COMMON TAG", "LAST MODIFIED BY", "SMU ID", "ELEMENT NAME"});
             *
             */
            //reading operation declaring
            FileInputStream xlFile = new FileInputStream(new File("C:\\Uploads\\" + fileName));
            XSSFWorkbook wbook = new XSSFWorkbook(xlFile);
            XSSFSheet sheet = wbook.getSheetAt(0);
            Iterator<Row> rowIterator = sheet.iterator();
            Cell cell = null;
            Row row = null;
            int rowCounter = 0;            
            int rowNum = sheet.getLastRowNum() + 1;
            int colNum = sheet.getRow(0).getLastCellNum();
            sheet.setColumnWidth(0, 1000);
            sheet.setColumnWidth(1, 1000);
            sheet.setColumnWidth(2, 1000);
            XSSFFont font = wbook.createFont();
            font.setColor(XSSFFont.COLOR_RED);
            font.setBoldweight(XSSFFont.BOLDWEIGHT_BOLD);
            // Create the style
            XSSFCellStyle cellStyle = wbook.createCellStyle();
            cellStyle.setFont(font);
            for (int i = 0; i < rowNum; i++) {
                XSSFRow Row = sheet.getRow(i);

                for (int j = 0; j < colNum; j++) {
                    XSSFCell Cell = Row.getCell(j);
                    Cell.setCellStyle(cellStyle);

                    //System.out.println("the value is " + value);
                }
            }

            //intgrated release check variable
            String xcelintRls = null;

            while (rowIterator.hasNext()) {

                row = rowIterator.next();
                Iterator<Cell> cellIterator = row.cellIterator();
                while (cellIterator.hasNext()) {
                    cell = cellIterator.next();

                }

                
                if (cell != null) {
                    
                    
                    //closed issue logic
                    if (cell.getRow().getCell(6).toString().equalsIgnoreCase(closedValue)) {
                        if (Integer.parseInt(cell.getRow().getCell(19).toString()) < 2) {

                            index++;

                        } else {
                            if (sev3Value.equalsIgnoreCase("y")) {
                                if (cell.getRow().getCell(7).toString().equalsIgnoreCase("3")) {
                                    if (Integer.parseInt(cell.getRow().getCell(19).toString()) == 0) {
                                        index++;

                                    } else {
                                        index++;
                                        output_data.put(index, new Object[]{cell.getRow().getCell(0).toString(), cell.getRow().getCell(1).toString(), btagData + " \n " + cell.getRow().getCell(2).toString() + "\n" + etagData, cell.getRow().getCell(3).toString(), cell.getRow().getCell(4).toString(), cell.getRow().getCell(5).toString(), cell.getRow().getCell(6).toString(), cell.getRow().getCell(7).toString(), cell.getRow().getCell(8).toString(), cell.getRow().getCell(9).toString(), cell.getRow().getCell(10).toString(), cell.getRow().getCell(11).toString(), cell.getRow().getCell(12).toString(), cell.getRow().getCell(13).toString(), cell.getRow().getCell(14).toString(), cell.getRow().getCell(15).toString(), cell.getRow().getCell(16).toString(), cell.getRow().getCell(17).toString(), cell.getRow().getCell(18).toString(), cell.getRow().getCell(19).toString(), cell.getRow().getCell(20).toString(), cell.getRow().getCell(21).toString(), cell.getRow().getCell(22).toString(), cell.getRow().getCell(23).toString(), cell.getRow().getCell(24).toString(), cell.getRow().getCell(25).toString(), cell.getRow().getCell(26).toString(), cell.getRow().getCell(27).toString(), cell.getRow().getCell(28).toString(), cell.getRow().getCell(29).toString(), cell.getRow().getCell(30).toString(), cell.getRow().getCell(31).toString(), cell.getRow().getCell(32).toString(), cell.getRow().getCell(33).toString(), cell.getRow().getCell(34).toString(), cell.getRow().getCell(35).toString(), cell.getRow().getCell(36).toString(), cell.getRow().getCell(37).toString(), cell.getRow().getCell(38).toString(), cell.getRow().getCell(39).toString()

                                        });
                                    }

                                } else {
                                    if (!releaseName.equalsIgnoreCase("")) {
                                        intgrList = new StringTokenizer(cell.getRow().getCell(11).toString(), ",");
                                        int count = 0;
                                        while (intgrList.hasMoreTokens()) {
                                            xcelintRls = intgrList.nextToken();

                                            if (xcelintRls.equalsIgnoreCase(releaseName)) {
                                                //write logic
                                                System.out.println("IR is :" + xcelintRls);
                                                index++;

                                                count++;
                                                break;
                                            }

                                        }
                                        if (count == 0) {
                                            index++;
                                            output_data.put(index, new Object[]{cell.getRow().getCell(0).toString(), cell.getRow().getCell(1).toString(), btagData + " \n " + cell.getRow().getCell(2).toString() + "\n" + etagData, cell.getRow().getCell(3).toString(), cell.getRow().getCell(4).toString(), cell.getRow().getCell(5).toString(), cell.getRow().getCell(6).toString(), cell.getRow().getCell(7).toString(), cell.getRow().getCell(8).toString(), cell.getRow().getCell(9).toString(), cell.getRow().getCell(10).toString(), cell.getRow().getCell(11).toString(), cell.getRow().getCell(12).toString(), cell.getRow().getCell(13).toString(), cell.getRow().getCell(14).toString(), cell.getRow().getCell(15).toString(), cell.getRow().getCell(16).toString(), cell.getRow().getCell(17).toString(), cell.getRow().getCell(18).toString(), cell.getRow().getCell(19).toString(), cell.getRow().getCell(20).toString(), cell.getRow().getCell(21).toString(), cell.getRow().getCell(22).toString(), cell.getRow().getCell(23).toString(), cell.getRow().getCell(24).toString(), cell.getRow().getCell(25).toString(), cell.getRow().getCell(26).toString(), cell.getRow().getCell(27).toString(), cell.getRow().getCell(28).toString(), cell.getRow().getCell(29).toString(), cell.getRow().getCell(30).toString(), cell.getRow().getCell(31).toString(), cell.getRow().getCell(32).toString(), cell.getRow().getCell(33).toString(), cell.getRow().getCell(34).toString(), cell.getRow().getCell(35).toString(), cell.getRow().getCell(36).toString(), cell.getRow().getCell(37).toString(), cell.getRow().getCell(38).toString(), cell.getRow().getCell(39).toString()

                                            });
                                        }

                                    }

                                }
                            }
                            if (sev3Value.equalsIgnoreCase("na")) {

                                if (!releaseName.equalsIgnoreCase("")) {
                                    intgrList = new StringTokenizer(cell.getRow().getCell(11).toString(), ",");
                                    int count = 0;
                                    while (intgrList.hasMoreTokens()) {
                                        xcelintRls = intgrList.nextToken();

                                        if (xcelintRls.equalsIgnoreCase(releaseName)) {
                                            //write logic
                                            System.out.println("IR is :" + xcelintRls);
                                            index++;

                                            count++;
                                            break;
                                        }
                                    }
                                    if (count == 0) {
                                        index++;
                                        output_data.put(index, new Object[]{cell.getRow().getCell(0).toString(), cell.getRow().getCell(1).toString(), btagData + " \n " + cell.getRow().getCell(2).toString() + "\n" + etagData, cell.getRow().getCell(3).toString(), cell.getRow().getCell(4).toString(), cell.getRow().getCell(5).toString(), cell.getRow().getCell(6).toString(), cell.getRow().getCell(7).toString(), cell.getRow().getCell(8).toString(), cell.getRow().getCell(9).toString(), cell.getRow().getCell(10).toString(), cell.getRow().getCell(11).toString(), cell.getRow().getCell(12).toString(), cell.getRow().getCell(13).toString(), cell.getRow().getCell(14).toString(), cell.getRow().getCell(15).toString(), cell.getRow().getCell(16).toString(), cell.getRow().getCell(17).toString(), cell.getRow().getCell(18).toString(), cell.getRow().getCell(19).toString(), cell.getRow().getCell(20).toString(), cell.getRow().getCell(21).toString(), cell.getRow().getCell(22).toString(), cell.getRow().getCell(23).toString(), cell.getRow().getCell(24).toString(), cell.getRow().getCell(25).toString(), cell.getRow().getCell(26).toString(), cell.getRow().getCell(27).toString(), cell.getRow().getCell(28).toString(), cell.getRow().getCell(29).toString(), cell.getRow().getCell(30).toString(), cell.getRow().getCell(31).toString(), cell.getRow().getCell(32).toString(), cell.getRow().getCell(33).toString(), cell.getRow().getCell(34).toString(), cell.getRow().getCell(35).toString(), cell.getRow().getCell(36).toString(), cell.getRow().getCell(37).toString(), cell.getRow().getCell(38).toString(), cell.getRow().getCell(39).toString()

                                        });
                                    }
                                }

                            }

                        }

                    }
                    //Junked issue logic
                    if (cell.getRow().getCell(6).toString().equalsIgnoreCase(junkedValue)) {

                        if (Integer.parseInt(cell.getRow().getCell(19).toString()) < 2) {
                            index++;

                        } else {
                            if (sev3Value.equalsIgnoreCase("y")) {
                                if (cell.getRow().getCell(7).toString().equalsIgnoreCase("3")) {
                                    if (Integer.parseInt(cell.getRow().getCell(19).toString()) == 0) {
                                        index++;

                                    } else {
                                        index++;
                                        output_data.put(index, new Object[]{cell.getRow().getCell(0).toString(), cell.getRow().getCell(1).toString(), btagData + " \n " + cell.getRow().getCell(2).toString() + "\n" + etagData, cell.getRow().getCell(3).toString(), cell.getRow().getCell(4).toString(), cell.getRow().getCell(5).toString(), cell.getRow().getCell(6).toString(), cell.getRow().getCell(7).toString(), cell.getRow().getCell(8).toString(), cell.getRow().getCell(9).toString(), cell.getRow().getCell(10).toString(), cell.getRow().getCell(11).toString(), cell.getRow().getCell(12).toString(), cell.getRow().getCell(13).toString(), cell.getRow().getCell(14).toString(), cell.getRow().getCell(15).toString(), cell.getRow().getCell(16).toString(), cell.getRow().getCell(17).toString(), cell.getRow().getCell(18).toString(), cell.getRow().getCell(19).toString(), cell.getRow().getCell(20).toString(), cell.getRow().getCell(21).toString(), cell.getRow().getCell(22).toString(), cell.getRow().getCell(23).toString(), cell.getRow().getCell(24).toString(), cell.getRow().getCell(25).toString(), cell.getRow().getCell(26).toString(), cell.getRow().getCell(27).toString(), cell.getRow().getCell(28).toString(), cell.getRow().getCell(29).toString(), cell.getRow().getCell(30).toString(), cell.getRow().getCell(31).toString(), cell.getRow().getCell(32).toString(), cell.getRow().getCell(33).toString(), cell.getRow().getCell(34).toString(), cell.getRow().getCell(35).toString(), cell.getRow().getCell(36).toString(), cell.getRow().getCell(37).toString(), cell.getRow().getCell(38).toString(), cell.getRow().getCell(39).toString()

                                        });
                                    }

                                } else {
                                    if (!releaseName.equalsIgnoreCase("")) {
                                        intgrList = new StringTokenizer(cell.getRow().getCell(11).toString(), ",");
                                        int count = 0;
                                        while (intgrList.hasMoreTokens()) {
                                            xcelintRls = intgrList.nextToken();

                                            if (xcelintRls.equalsIgnoreCase(releaseName)) {
                                                //write logic
                                                System.out.println("IR is :" + xcelintRls);
                                                index++;

                                                count++;
                                                break;
                                            }
                                        }
                                        if (count == 0) {
                                            index++;
                                            output_data.put(index, new Object[]{cell.getRow().getCell(0).toString(), cell.getRow().getCell(1).toString(), btagData + " \n " + cell.getRow().getCell(2).toString() + "\n" + etagData, cell.getRow().getCell(3).toString(), cell.getRow().getCell(4).toString(), cell.getRow().getCell(5).toString(), cell.getRow().getCell(6).toString(), cell.getRow().getCell(7).toString(), cell.getRow().getCell(8).toString(), cell.getRow().getCell(9).toString(), cell.getRow().getCell(10).toString(), cell.getRow().getCell(11).toString(), cell.getRow().getCell(12).toString(), cell.getRow().getCell(13).toString(), cell.getRow().getCell(14).toString(), cell.getRow().getCell(15).toString(), cell.getRow().getCell(16).toString(), cell.getRow().getCell(17).toString(), cell.getRow().getCell(18).toString(), cell.getRow().getCell(19).toString(), cell.getRow().getCell(20).toString(), cell.getRow().getCell(21).toString(), cell.getRow().getCell(22).toString(), cell.getRow().getCell(23).toString(), cell.getRow().getCell(24).toString(), cell.getRow().getCell(25).toString(), cell.getRow().getCell(26).toString(), cell.getRow().getCell(27).toString(), cell.getRow().getCell(28).toString(), cell.getRow().getCell(29).toString(), cell.getRow().getCell(30).toString(), cell.getRow().getCell(31).toString(), cell.getRow().getCell(32).toString(), cell.getRow().getCell(33).toString(), cell.getRow().getCell(34).toString(), cell.getRow().getCell(35).toString(), cell.getRow().getCell(36).toString(), cell.getRow().getCell(37).toString(), cell.getRow().getCell(38).toString(), cell.getRow().getCell(39).toString()

                                            });
                                        }
                                    }

                                }
                            }
                            if (sev3Value.equalsIgnoreCase("na")) {

                                if (!releaseName.equalsIgnoreCase("")) {
                                    intgrList = new StringTokenizer(cell.getRow().getCell(11).toString(), ",");
                                    int count = 0;
                                    while (intgrList.hasMoreTokens()) {
                                        xcelintRls = intgrList.nextToken();

                                        if (xcelintRls.equalsIgnoreCase(releaseName)) {
                                            //write logic
                                            System.out.println("IR is :" + xcelintRls);
                                            index++;

                                            count++;
                                            break;
                                        }
                                    }
                                    if (count == 0) {
                                        index++;
                                        output_data.put(index, new Object[]{cell.getRow().getCell(0).toString(), cell.getRow().getCell(1).toString(), btagData + " \n " + cell.getRow().getCell(2).toString() + "\n" + etagData, cell.getRow().getCell(3).toString(), cell.getRow().getCell(4).toString(), cell.getRow().getCell(5).toString(), cell.getRow().getCell(6).toString(), cell.getRow().getCell(7).toString(), cell.getRow().getCell(8).toString(), cell.getRow().getCell(9).toString(), cell.getRow().getCell(10).toString(), cell.getRow().getCell(11).toString(), cell.getRow().getCell(12).toString(), cell.getRow().getCell(13).toString(), cell.getRow().getCell(14).toString(), cell.getRow().getCell(15).toString(), cell.getRow().getCell(16).toString(), cell.getRow().getCell(17).toString(), cell.getRow().getCell(18).toString(), cell.getRow().getCell(19).toString(), cell.getRow().getCell(20).toString(), cell.getRow().getCell(21).toString(), cell.getRow().getCell(22).toString(), cell.getRow().getCell(23).toString(), cell.getRow().getCell(24).toString(), cell.getRow().getCell(25).toString(), cell.getRow().getCell(26).toString(), cell.getRow().getCell(27).toString(), cell.getRow().getCell(28).toString(), cell.getRow().getCell(29).toString(), cell.getRow().getCell(30).toString(), cell.getRow().getCell(31).toString(), cell.getRow().getCell(32).toString(), cell.getRow().getCell(33).toString(), cell.getRow().getCell(34).toString(), cell.getRow().getCell(35).toString(), cell.getRow().getCell(36).toString(), cell.getRow().getCell(37).toString(), cell.getRow().getCell(38).toString(), cell.getRow().getCell(39).toString()

                                        });
                                    }
                                }

                            }

                        }
                    }
                    //held issue logic

                    if (cell.getRow().getCell(6).toString().equalsIgnoreCase(heldValue)) {
                        if (Integer.parseInt(cell.getRow().getCell(19).toString()) < 2) {
                            index++;

                        } else {
                            if (sev3Value.equalsIgnoreCase("y")) {
                                if (cell.getRow().getCell(7).toString().equalsIgnoreCase("3")) {
                                    if (Integer.parseInt(cell.getRow().getCell(19).toString()) == 0) {
                                        index++;

                                    } else {
                                        index++;
                                        output_data.put(index, new Object[]{cell.getRow().getCell(0).toString(), cell.getRow().getCell(1).toString(), btagData + " \n " + cell.getRow().getCell(2).toString() + "\n" + etagData, cell.getRow().getCell(3).toString(), cell.getRow().getCell(4).toString(), cell.getRow().getCell(5).toString(), cell.getRow().getCell(6).toString(), cell.getRow().getCell(7).toString(), cell.getRow().getCell(8).toString(), cell.getRow().getCell(9).toString(), cell.getRow().getCell(10).toString(), cell.getRow().getCell(11).toString(), cell.getRow().getCell(12).toString(), cell.getRow().getCell(13).toString(), cell.getRow().getCell(14).toString(), cell.getRow().getCell(15).toString(), cell.getRow().getCell(16).toString(), cell.getRow().getCell(17).toString(), cell.getRow().getCell(18).toString(), cell.getRow().getCell(19).toString(), cell.getRow().getCell(20).toString(), cell.getRow().getCell(21).toString(), cell.getRow().getCell(22).toString(), cell.getRow().getCell(23).toString(), cell.getRow().getCell(24).toString(), cell.getRow().getCell(25).toString(), cell.getRow().getCell(26).toString(), cell.getRow().getCell(27).toString(), cell.getRow().getCell(28).toString(), cell.getRow().getCell(29).toString(), cell.getRow().getCell(30).toString(), cell.getRow().getCell(31).toString(), cell.getRow().getCell(32).toString(), cell.getRow().getCell(33).toString(), cell.getRow().getCell(34).toString(), cell.getRow().getCell(35).toString(), cell.getRow().getCell(36).toString(), cell.getRow().getCell(37).toString(), cell.getRow().getCell(38).toString(), cell.getRow().getCell(39).toString()

                                        });
                                    }

                                } else {
                                    if (!releaseName.equalsIgnoreCase("")) {
                                        intgrList = new StringTokenizer(cell.getRow().getCell(11).toString(), ",");
                                        int count = 0;
                                        while (intgrList.hasMoreTokens()) {
                                            xcelintRls = intgrList.nextToken();

                                            if (xcelintRls.equalsIgnoreCase(releaseName)) {
                                                //write logic
                                                System.out.println("IR is :" + xcelintRls);
                                                index++;

                                                count++;
                                                break;
                                            }
                                        }
                                        if (count == 0) {
                                            index++;
                                            output_data.put(index, new Object[]{cell.getRow().getCell(0).toString(), cell.getRow().getCell(1).toString(), btagData + " \n " + cell.getRow().getCell(2).toString() + "\n" + etagData, cell.getRow().getCell(3).toString(), cell.getRow().getCell(4).toString(), cell.getRow().getCell(5).toString(), cell.getRow().getCell(6).toString(), cell.getRow().getCell(7).toString(), cell.getRow().getCell(8).toString(), cell.getRow().getCell(9).toString(), cell.getRow().getCell(10).toString(), cell.getRow().getCell(11).toString(), cell.getRow().getCell(12).toString(), cell.getRow().getCell(13).toString(), cell.getRow().getCell(14).toString(), cell.getRow().getCell(15).toString(), cell.getRow().getCell(16).toString(), cell.getRow().getCell(17).toString(), cell.getRow().getCell(18).toString(), cell.getRow().getCell(19).toString(), cell.getRow().getCell(20).toString(), cell.getRow().getCell(21).toString(), cell.getRow().getCell(22).toString(), cell.getRow().getCell(23).toString(), cell.getRow().getCell(24).toString(), cell.getRow().getCell(25).toString(), cell.getRow().getCell(26).toString(), cell.getRow().getCell(27).toString(), cell.getRow().getCell(28).toString(), cell.getRow().getCell(29).toString(), cell.getRow().getCell(30).toString(), cell.getRow().getCell(31).toString(), cell.getRow().getCell(32).toString(), cell.getRow().getCell(33).toString(), cell.getRow().getCell(34).toString(), cell.getRow().getCell(35).toString(), cell.getRow().getCell(36).toString(), cell.getRow().getCell(37).toString(), cell.getRow().getCell(38).toString(), cell.getRow().getCell(39).toString()

                                            });
                                        }
                                    }

                                }
                            }
                            if (sev3Value.equalsIgnoreCase("na")) {

                                if (!releaseName.equalsIgnoreCase("")) {
                                    intgrList = new StringTokenizer(cell.getRow().getCell(11).toString(), ",");
                                    int count = 0;
                                    while (intgrList.hasMoreTokens()) {
                                        xcelintRls = intgrList.nextToken();

                                        if (xcelintRls.equalsIgnoreCase(releaseName)) {
                                            //write logic
                                            System.out.println("IR is :" + xcelintRls);
                                            index++;

                                            count++;
                                            break;
                                        }
                                    }
                                    if (count == 0) {
                                        index++;
                                        output_data.put(index, new Object[]{cell.getRow().getCell(0).toString(), cell.getRow().getCell(1).toString(), btagData + " \n " + cell.getRow().getCell(2).toString() + "\n" + etagData, cell.getRow().getCell(3).toString(), cell.getRow().getCell(4).toString(), cell.getRow().getCell(5).toString(), cell.getRow().getCell(6).toString(), cell.getRow().getCell(7).toString(), cell.getRow().getCell(8).toString(), cell.getRow().getCell(9).toString(), cell.getRow().getCell(10).toString(), cell.getRow().getCell(11).toString(), cell.getRow().getCell(12).toString(), cell.getRow().getCell(13).toString(), cell.getRow().getCell(14).toString(), cell.getRow().getCell(15).toString(), cell.getRow().getCell(16).toString(), cell.getRow().getCell(17).toString(), cell.getRow().getCell(18).toString(), cell.getRow().getCell(19).toString(), cell.getRow().getCell(20).toString(), cell.getRow().getCell(21).toString(), cell.getRow().getCell(22).toString(), cell.getRow().getCell(23).toString(), cell.getRow().getCell(24).toString(), cell.getRow().getCell(25).toString(), cell.getRow().getCell(26).toString(), cell.getRow().getCell(27).toString(), cell.getRow().getCell(28).toString(), cell.getRow().getCell(29).toString(), cell.getRow().getCell(30).toString(), cell.getRow().getCell(31).toString(), cell.getRow().getCell(32).toString(), cell.getRow().getCell(33).toString(), cell.getRow().getCell(34).toString(), cell.getRow().getCell(35).toString(), cell.getRow().getCell(36).toString(), cell.getRow().getCell(37).toString(), cell.getRow().getCell(38).toString(), cell.getRow().getCell(39).toString()

                                        });
                                    }
                                }

                            }

                        }
                    }
                    if (sev3Value.equalsIgnoreCase("y")) {
                        if (!(cell.getRow().getCell(6).toString().equalsIgnoreCase(closedValue) || cell.getRow().getCell(6).toString().equalsIgnoreCase(junkedValue) || cell.getRow().getCell(6).toString().equalsIgnoreCase(heldValue))) {
                            if (cell.getRow().getCell(7).toString().equalsIgnoreCase("3")) {
                                if (Integer.parseInt(cell.getRow().getCell(19).toString()) == 0) {
                                    index++;

                                } else {
                                    //tag n feature logic
                                    int ite = 0;
                                    int countnew = 0;

                                    if (tag != null || f != null) {

                                        for (int i = 0; i < tag.length; i++) {

                                            if (cell.getRow().getCell(32).toString().toLowerCase().contains(tag[i])) {
                                                index++;

                                                ite++;
                                                continue;
                                            }
                                        }

                                        for (int x = 0; x < f.length; x++) {

                                            if ((cell.getRow().getCell(9).toString().toLowerCase().contains(f[x]) && cell.getRow().getCell(14).toString().toLowerCase().matches("(?s)(.*)conditions:(.*)"+f[x]+"(?s)(.*)workaround:(.*)") && !((cell.getRow().getCell(9).toString().toLowerCase().contains("/"+f[x])) || cell.getRow().getCell(9).toString().toLowerCase().contains(f[x]+"/") || (cell.getRow().getCell(9).toString().toLowerCase().contains("/ "+f[x])) || cell.getRow().getCell(9).toString().toLowerCase().contains(f[x]+" /") || cell.getRow().getCell(9).toString().toLowerCase().contains(" or "))) || cell.getRow().getCell(32).toString().toLowerCase().contains(f[x])) {

                                                index++;

                                                countnew++;
                                                continue;

                                            }
                                        }
                                    }

                                    if (countnew == 0 && ite == 0) {
                                        index++;
                                        output_data.put(index, new Object[]{cell.getRow().getCell(0).toString(), cell.getRow().getCell(1).toString(), btagData + " \n " + cell.getRow().getCell(2).toString() + "\n" + etagData, cell.getRow().getCell(3).toString(), cell.getRow().getCell(4).toString(), cell.getRow().getCell(5).toString(), cell.getRow().getCell(6).toString(), cell.getRow().getCell(7).toString(), cell.getRow().getCell(8).toString(), cell.getRow().getCell(9).toString(), cell.getRow().getCell(10).toString(), cell.getRow().getCell(11).toString(), cell.getRow().getCell(12).toString(), cell.getRow().getCell(13).toString(), cell.getRow().getCell(14).toString(), cell.getRow().getCell(15).toString(), cell.getRow().getCell(16).toString(), cell.getRow().getCell(17).toString(), cell.getRow().getCell(18).toString(), cell.getRow().getCell(19).toString(), cell.getRow().getCell(20).toString(), cell.getRow().getCell(21).toString(), cell.getRow().getCell(22).toString(), cell.getRow().getCell(23).toString(), cell.getRow().getCell(24).toString(), cell.getRow().getCell(25).toString(), cell.getRow().getCell(26).toString(), cell.getRow().getCell(27).toString(), cell.getRow().getCell(28).toString(), cell.getRow().getCell(29).toString(), cell.getRow().getCell(30).toString(), cell.getRow().getCell(31).toString(), cell.getRow().getCell(32).toString(), cell.getRow().getCell(33).toString(), cell.getRow().getCell(34).toString(), cell.getRow().getCell(35).toString(), cell.getRow().getCell(36).toString(), cell.getRow().getCell(37).toString(), cell.getRow().getCell(38).toString(), cell.getRow().getCell(39).toString()

                                        });
                                    }
                                }

                            } else {
                                if (!releaseName.equalsIgnoreCase("")) {
                                    intgrList = new StringTokenizer(cell.getRow().getCell(11).toString(), ",");
                                    int count = 0;
                                    while (intgrList.hasMoreTokens()) {
                                        xcelintRls = intgrList.nextToken();

                                        if (xcelintRls.equalsIgnoreCase(releaseName)) {
                                            //write logic
                                            System.out.println("IR is :" + xcelintRls);
                                            index++;

                                            count++;
                                            break;
                                        }
                                    }
                                    int ite = 0;
                                    int countnew = 0;

                                    if (tag != null || f != null) {

                                        for (int i = 0; i < tag.length; i++) {

                                            if (cell.getRow().getCell(32).toString().toLowerCase().contains(tag[i])) {
                                                index++;

                                                ite++;
                                                continue;
                                            }
                                        }

                                        for (int x = 0; x < f.length; x++) {

                                            if ((cell.getRow().getCell(9).toString().toLowerCase().contains(f[x]) && cell.getRow().getCell(14).toString().toLowerCase().matches("(?s)(.*)conditions:(.*)"+f[x]+"(?s)(.*)workaround:(.*)") && !((cell.getRow().getCell(9).toString().toLowerCase().contains("/"+f[x])) || cell.getRow().getCell(9).toString().toLowerCase().contains(f[x]+"/") || (cell.getRow().getCell(9).toString().toLowerCase().contains("/ "+f[x])) || cell.getRow().getCell(9).toString().toLowerCase().contains(f[x]+" /") || cell.getRow().getCell(9).toString().toLowerCase().contains(" or "))) || cell.getRow().getCell(32).toString().toLowerCase().contains(f[x])) {

                                                index++;

                                                countnew++;
                                                continue;

                                            }
                                        }
                                    }

                                    if (count == 0 && countnew == 0 && ite == 0) {
                                        index++;
                                        output_data.put(index, new Object[]{cell.getRow().getCell(0).toString(), cell.getRow().getCell(1).toString(), btagData + " \n " + cell.getRow().getCell(2).toString() + "\n" + etagData, cell.getRow().getCell(3).toString(), cell.getRow().getCell(4).toString(), cell.getRow().getCell(5).toString(), cell.getRow().getCell(6).toString(), cell.getRow().getCell(7).toString(), cell.getRow().getCell(8).toString(), cell.getRow().getCell(9).toString(), cell.getRow().getCell(10).toString(), cell.getRow().getCell(11).toString(), cell.getRow().getCell(12).toString(), cell.getRow().getCell(13).toString(), cell.getRow().getCell(14).toString(), cell.getRow().getCell(15).toString(), cell.getRow().getCell(16).toString(), cell.getRow().getCell(17).toString(), cell.getRow().getCell(18).toString(), cell.getRow().getCell(19).toString(), cell.getRow().getCell(20).toString(), cell.getRow().getCell(21).toString(), cell.getRow().getCell(22).toString(), cell.getRow().getCell(23).toString(), cell.getRow().getCell(24).toString(), cell.getRow().getCell(25).toString(), cell.getRow().getCell(26).toString(), cell.getRow().getCell(27).toString(), cell.getRow().getCell(28).toString(), cell.getRow().getCell(29).toString(), cell.getRow().getCell(30).toString(), cell.getRow().getCell(31).toString(), cell.getRow().getCell(32).toString(), cell.getRow().getCell(33).toString(), cell.getRow().getCell(34).toString(), cell.getRow().getCell(35).toString(), cell.getRow().getCell(36).toString(), cell.getRow().getCell(37).toString(), cell.getRow().getCell(38).toString(), cell.getRow().getCell(39).toString()

                                        });
                                    }
                                }

                            }
                        }

                    }

                    if (sev3Value.equalsIgnoreCase("na")) {

                        if (!(cell.getRow().getCell(6).toString().equalsIgnoreCase(closedValue) || cell.getRow().getCell(6).toString().equalsIgnoreCase(junkedValue) || cell.getRow().getCell(6).toString().equalsIgnoreCase(heldValue))) {

                            if (!releaseName.equalsIgnoreCase("")) {

                                intgrList = new StringTokenizer(cell.getRow().getCell(11).toString(), ",");
                                int count = 0;
                                while (intgrList.hasMoreTokens()) {
                                    xcelintRls = intgrList.nextToken();

                                    if (xcelintRls.equalsIgnoreCase(releaseName)) {
                                        //write logic

                                        System.out.println("IR is :" + xcelintRls);
                                        index++;

                                        count++;
                                        break;
                                    }
                                }

                                int ite = 0;
                                int countnew = 0;

                                if (tag != null || f != null) {

                                    for (int i = 0; i < tag.length; i++) {

                                        if (cell.getRow().getCell(32).toString().toLowerCase().contains(tag[i])) {
                                            index++;

                                            ite++;
                                            continue;
                                        }
                                    }

                                    for (int x = 0; x < f.length; x++) {

                                        if ((cell.getRow().getCell(9).toString().toLowerCase().contains(f[x]) && cell.getRow().getCell(14).toString().toLowerCase().matches("(?s)(.*)conditions:(.*)"+f[x]+"(?s)(.*)workaround:(.*)") && !((cell.getRow().getCell(9).toString().toLowerCase().contains("/"+f[x])) || cell.getRow().getCell(9).toString().toLowerCase().contains(f[x]+"/") || (cell.getRow().getCell(9).toString().toLowerCase().contains("/ "+f[x])) || cell.getRow().getCell(9).toString().toLowerCase().contains(f[x]+" /") || cell.getRow().getCell(9).toString().toLowerCase().contains(" or "))) || cell.getRow().getCell(32).toString().toLowerCase().contains(f[x])) {

                                            index++;

                                            countnew++;
                                            continue;

                                        }
                                    }
                                }
                                if (count == 0 && countnew == 0 && ite == 0) {
                                    index++;
                                    output_data.put(index, new Object[]{cell.getRow().getCell(0).toString(), cell.getRow().getCell(1).toString(), btagData + " \n " + cell.getRow().getCell(2).toString() + "\n" + etagData, cell.getRow().getCell(3).toString(), cell.getRow().getCell(4).toString(), cell.getRow().getCell(5).toString(), cell.getRow().getCell(6).toString(), cell.getRow().getCell(7).toString(), cell.getRow().getCell(8).toString(), cell.getRow().getCell(9).toString(), cell.getRow().getCell(10).toString(), cell.getRow().getCell(11).toString(), cell.getRow().getCell(12).toString(), cell.getRow().getCell(13).toString(), cell.getRow().getCell(14).toString(), cell.getRow().getCell(15).toString(), cell.getRow().getCell(16).toString(), cell.getRow().getCell(17).toString(), cell.getRow().getCell(18).toString(), cell.getRow().getCell(19).toString(), cell.getRow().getCell(20).toString(), cell.getRow().getCell(21).toString(), cell.getRow().getCell(22).toString(), cell.getRow().getCell(23).toString(), cell.getRow().getCell(24).toString(), cell.getRow().getCell(25).toString(), cell.getRow().getCell(26).toString(), cell.getRow().getCell(27).toString(), cell.getRow().getCell(28).toString(), cell.getRow().getCell(29).toString(), cell.getRow().getCell(30).toString(), cell.getRow().getCell(31).toString(), cell.getRow().getCell(32).toString(), cell.getRow().getCell(33).toString(), cell.getRow().getCell(34).toString(), cell.getRow().getCell(35).toString(), cell.getRow().getCell(36).toString(), cell.getRow().getCell(37).toString(), cell.getRow().getCell(38).toString(), cell.getRow().getCell(39).toString()

                                    });
                                }

                                /*        if (count == 0) {
                                 index++;
                                 output_data.put(index, new Object[]{cell.getRow().getCell(0).toString(), cell.getRow().getCell(1).toString(), btagData + " \n " + cell.getRow().getCell(2).toString() + "\n" + etagData, cell.getRow().getCell(3).toString(), cell.getRow().getCell(4).toString(), cell.getRow().getCell(5).toString(), cell.getRow().getCell(6).toString(), cell.getRow().getCell(7).toString(), cell.getRow().getCell(8).toString(), cell.getRow().getCell(9).toString(), cell.getRow().getCell(10).toString(), cell.getRow().getCell(11).toString(), cell.getRow().getCell(12).toString(), cell.getRow().getCell(13).toString(), cell.getRow().getCell(14).toString(), cell.getRow().getCell(15).toString(), cell.getRow().getCell(16).toString(), cell.getRow().getCell(17).toString(), cell.getRow().getCell(18).toString(), cell.getRow().getCell(19).toString(), cell.getRow().getCell(20).toString(), cell.getRow().getCell(21).toString(), cell.getRow().getCell(22).toString(), cell.getRow().getCell(23).toString(), cell.getRow().getCell(24).toString(), cell.getRow().getCell(25).toString(), cell.getRow().getCell(26).toString(), cell.getRow().getCell(27).toString(), cell.getRow().getCell(28).toString(), cell.getRow().getCell(29).toString(), cell.getRow().getCell(30).toString(), cell.getRow().getCell(31).toString(), cell.getRow().getCell(32).toString(), cell.getRow().getCell(33).toString(), cell.getRow().getCell(34).toString(), cell.getRow().getCell(35).toString(), cell.getRow().getCell(36).toString(), cell.getRow().getCell(37).toString(), cell.getRow().getCell(38).toString(), cell.getRow().getCell(39).toString()

                                 });
                                 } */
                            }

                        }

                    }
                
                
            
                }
//                 if (count == 0 && ite == 0 && hel == 0 && clo == 0 && jun == 0 && sevi == 0) {
//                                    index++;
//                                    output_data.put(index, new Object[]{cell.getRow().getCell(0).toString(), cell.getRow().getCell(1).toString(), btagData + " \n " + cell.getRow().getCell(2).toString() + "\n" + etagData, cell.getRow().getCell(3).toString(), cell.getRow().getCell(4).toString(), cell.getRow().getCell(5).toString(), cell.getRow().getCell(6).toString(), cell.getRow().getCell(7).toString(), cell.getRow().getCell(8).toString(), cell.getRow().getCell(9).toString(), cell.getRow().getCell(10).toString(), cell.getRow().getCell(11).toString(), cell.getRow().getCell(12).toString(), cell.getRow().getCell(13).toString(), cell.getRow().getCell(14).toString(), cell.getRow().getCell(15).toString(), cell.getRow().getCell(16).toString(), cell.getRow().getCell(17).toString(), cell.getRow().getCell(18).toString(), cell.getRow().getCell(19).toString(), cell.getRow().getCell(20).toString(), cell.getRow().getCell(21).toString(), cell.getRow().getCell(22).toString(), cell.getRow().getCell(23).toString(), cell.getRow().getCell(24).toString(), cell.getRow().getCell(25).toString(), cell.getRow().getCell(26).toString(), cell.getRow().getCell(27).toString(), cell.getRow().getCell(28).toString(), cell.getRow().getCell(29).toString(), cell.getRow().getCell(30).toString(), cell.getRow().getCell(31).toString(), cell.getRow().getCell(32).toString(), cell.getRow().getCell(33).toString(), cell.getRow().getCell(34).toString(), cell.getRow().getCell(35).toString(), cell.getRow().getCell(36).toString(), cell.getRow().getCell(37).toString(), cell.getRow().getCell(38).toString(), cell.getRow().getCell(39).toString()
//
//                                    });
//                                    
//                                }
                rowCounter++;

            }
            //System.out.println("######## " + output_data.size());
            xlFile.close();

            //write to new file
            XSSFWorkbook wwbook = new XSSFWorkbook();
            XSSFSheet wsheet = wwbook.createSheet("IncludedBugs-" + fileName);
            Set<Integer> keySet = output_data.keySet();
            int rownum = 0;
            for (int key : keySet) {
                row = wsheet.createRow(rownum++);
                Object[] objArr = output_data.get(key);
                int cellnum = 0;
                for (Object obj : objArr) {
                    cell = row.createCell(cellnum++);
                    if (obj instanceof String) {
                        cell.setCellValue((String) obj);
                    }
                }

            }
            String downloadPath = "C:\\Downloads\\";
            File downloadFile = new File(downloadPath);
            if (!downloadFile.exists()) {
                downloadFile.mkdirs();
            }
            FileOutputStream out = new FileOutputStream(new File(downloadPath + "IncludedBugs-" + fileName));
            wwbook.write(out);
            out.close();

        } catch (FileNotFoundException e) {
        } catch (IOException e) {
        }

    }
}
